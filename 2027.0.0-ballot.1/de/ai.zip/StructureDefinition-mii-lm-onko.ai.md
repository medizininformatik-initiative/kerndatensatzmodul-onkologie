# MII LM Onkologie - MII IG Kerndatensatz-Modul Onkologie v2027.0.0-ballot.1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII LM Onkologie**

## Logisches Modell: MII LM Onkologie 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-lm-onko | *Version*:2027.0.0-ballot.1 |
| Active Stand: 2026-09-15 | *Maschinenlesbarer Name*:MII_LM_Onko |

 
MII LogicalModel Modul Onkologie 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/de.medizininformatikinitiative.kerndatensatz.onkologie|current/StructureDefinition/StructureDefinition-mii-lm-onko.json)

### Formale Ansichten des Profilinhalts

 [Beschreibung von Profilen, Differentials, Snapshots und deren Repräsentationen](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Schlüsselelemente-Tabelle](#tabs-key) 
*  [Differential-Tabelle](#tabs-diff) 
*  [Snapshot-Tabelle](#tabs-snap) 
*  [Statistiken/Referenzen](#tabs-summ) 
*  [Alle](#tabs-all) 

#### Constraints

Diese Struktur ist abgeleitet von [Element](http://hl7.org/fhir/R4/datatypes.html#Element) 

#### Constraints

Diese Struktur ist abgeleitet von [Element](http://hl7.org/fhir/R4/datatypes.html#Element) 

** Summary **

Mandatory: 0 element(29 nested mandatory elements)

 **Schlüsselelemente-Ansicht** 

#### Constraints

 **Differential-Ansicht** 

Diese Struktur ist abgeleitet von [Element](http://hl7.org/fhir/R4/datatypes.html#Element) 

 **Snapshot-AnsichtView** 

#### Constraints

Diese Struktur ist abgeleitet von [Element](http://hl7.org/fhir/R4/datatypes.html#Element) 

** Summary **

Mandatory: 0 element(29 nested mandatory elements)

 

Weitere Repräsentationen des Profils: [CSV](../StructureDefinition-mii-lm-onko.csv), [Excel](../StructureDefinition-mii-lm-onko.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "mii-lm-onko",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-license",
      "valueCode" : "CC-BY-4.0"
    },
    {
      "extension" : [{
        "url" : "packageId",
        "valueId" : "de.medizininformatikinitiative.kerndatensatz.onkologie"
      },
      {
        "url" : "version",
        "valueString" : "2027.0.0-ballot.1"
      },
      {
        "url" : "uri",
        "valueUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/package-source"
    }],
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablestructuredefinition",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablestructuredefinition"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-usage",
    "valueMarkdown" : "Use this logical model as the module-specific information model for the Medical Informatics Initiative core dataset. The model describes clinically or administratively relevant information in a domain-oriented form and provides a bridge between the conceptual content specification and the corresponding technical FHIR profiles. It is a pattern for describing the intended content model and is not intended to be exchanged as a concrete FHIR resource instance. Implementers should use it to understand the scope, semantics, and structure of the module before applying the related FHIR profiles and mappings."
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionPolicy",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes",
        "code" : "package",
        "display" : "Package"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-approvalDate",
    "valueDate" : "2026-09-15"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-topic",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
        "code" : "C3262"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-author",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "email",
        "value" : "thomas.debertshaeuser@charite.de"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-editor",
    "valueContactDetail" : {
      "name" : "Taskforce Core Data Set"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2027"
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-lm-onko",
  "version" : "2027.0.0-ballot.1",
  "name" : "MII_LM_Onko",
  "title" : "MII LM Onkologie",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-15T06:26:59+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "MII LogicalModel Modul Onkologie",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "FHIR",
    "name" : "Onkologie LogicalModel FHIR Mapping"
  },
  {
    "identity" : "oBDS",
    "name" : "Onkologie LogicalModel oBDS Mapping"
  }],
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-lm-onko",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Element",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "mii-lm-onko",
      "path" : "mii-lm-onko",
      "short" : "MII LM Onkologie",
      "definition" : "MII LogicalModel Modul Onkologie"
    },
    {
      "id" : "mii-lm-onko.Diagnose",
      "path" : "mii-lm-onko.Diagnose",
      "short" : "Diagnose",
      "definition" : "Diagnose",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Condition"
      },
      {
        "identity" : "oBDS",
        "map" : "5",
        "comment" : "Diagnose - oBDS Kapitel 5. Amtlicher Feldkatalog: https://basisdatensatz.de"
      }]
    },
    {
      "id" : "mii-lm-onko.Diagnose.PrimaertumorTumordiagnoseICDCode",
      "path" : "mii-lm-onko.Diagnose.PrimaertumorTumordiagnoseICDCode",
      "short" : "Primärtumor Tumordiagnose ICD Code",
      "definition" : "Kodierung einer meldepflichtigen Erkrankung nach der aktuellen ICD-GM Version.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Condition.code.coding.where(system='http://fhir.de/CodeSystem/bfarm/icd-10-gm').code"
      },
      {
        "identity" : "oBDS",
        "map" : "5.1",
        "comment" : "Primärtumor Tumordiagnose ICD Code - Kodierung nach aktueller ICD-10-GM"
      }]
    },
    {
      "id" : "mii-lm-onko.Diagnose.PrimaertumorTumordiagnoseICDVersion",
      "path" : "mii-lm-onko.Diagnose.PrimaertumorTumordiagnoseICDVersion",
      "short" : "Primärtumor Tumordiagnose ICD-Version",
      "definition" : "Bezeichnung der zur Kodierung verwendeten ICD-GM Version.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Condition.code.coding.where(system='http://fhir.de/CodeSystem/bfarm/icd-10-gm').version"
      },
      {
        "identity" : "oBDS",
        "map" : "5.2",
        "comment" : "Primärtumor Tumordiagnose ICD-Version"
      }]
    },
    {
      "id" : "mii-lm-onko.Diagnose.PrimaertumorTumordiagnoseText",
      "path" : "mii-lm-onko.Diagnose.PrimaertumorTumordiagnoseText",
      "short" : "Primärtumor Tumordiagnose Text",
      "definition" : "Bezeichnung einer meldepflichtigen Erkrankung.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Condition.code.text"
      },
      {
        "identity" : "oBDS",
        "map" : "5.3",
        "comment" : "Primärtumor Tumordiagnose Text - Klartextbezeichnung der meldepflichtigen Erkrankung"
      }]
    },
    {
      "id" : "mii-lm-onko.Diagnose.PrimaertumorTopographieICDO",
      "path" : "mii-lm-onko.Diagnose.PrimaertumorTopographieICDO",
      "short" : "Primärtumor Topographie ICD-O",
      "definition" : "Bezeichnung der Topographie einer Erkrankung nach der aktuellen ICD-O Version.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Condition.bodySite.coding.where(system='http://terminology.hl7.org/CodeSystem/icd-o-3').code"
      },
      {
        "identity" : "oBDS",
        "map" : "5.4",
        "comment" : "Primärtumor Topographie ICD-O"
      }]
    },
    {
      "id" : "mii-lm-onko.Diagnose.PrimaertumorTopographieICDOVersion",
      "path" : "mii-lm-onko.Diagnose.PrimaertumorTopographieICDOVersion",
      "short" : "Primärtumor Topographie ICD-O-Version",
      "definition" : "Bezeichnung der zur Kodierung verwendeten ICD-O Version.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Condition.bodySite.coding.where(system='http://terminology.hl7.org/CodeSystem/icd-o-3').version"
      },
      {
        "identity" : "oBDS",
        "map" : "5.5",
        "comment" : "Primärtumor Topographie ICD-O-Version"
      }]
    },
    {
      "id" : "mii-lm-onko.Diagnose.PrimaertumorDiagnosedatum",
      "path" : "mii-lm-onko.Diagnose.PrimaertumorDiagnosedatum",
      "short" : "Primärtumor Diagnosedatum",
      "definition" : "Datum, angegeben in Tag, Monat und Jahr, an dem die meldepflichtige Diagnose erstmals durch einen Arzt klinisch oder mikroskopisch diagnostiziert wurde.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Condition.assertedDate"
      },
      {
        "identity" : "oBDS",
        "map" : "5.6",
        "comment" : "Primärtumor Diagnosedatum - Datum der Erstdiagnose"
      }]
    },
    {
      "id" : "mii-lm-onko.Diagnose.PrimaertumorDiagnosesicherung",
      "path" : "mii-lm-onko.Diagnose.PrimaertumorDiagnosesicherung",
      "short" : "Primärtumor Diagnosesicherung",
      "definition" : "Höchste erreichte Diagnosesicherheit der Diagnose.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Condition.verificationStatus.coding.where(system='https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung').code"
      },
      {
        "identity" : "oBDS",
        "map" : "5.7",
        "comment" : "Primärtumor Diagnosesicherung - höchste erreichte Diagnosesicherheit"
      }]
    },
    {
      "id" : "mii-lm-onko.Diagnose.PrimaertumorSeitenlokalisation",
      "path" : "mii-lm-onko.Diagnose.PrimaertumorSeitenlokalisation",
      "short" : "Primärtumor Seitenlokalisation",
      "definition" : "Organspezifische Angabe der betroffenen Seite.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Condition.bodySite.coding.where(system='https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-seitenlokalisation').code"
      },
      {
        "identity" : "oBDS",
        "map" : "5.8",
        "comment" : "Primärtumor Seitenlokalisation"
      }]
    },
    {
      "id" : "mii-lm-onko.Diagnose.FruehereTumorerkrankungen",
      "path" : "mii-lm-onko.Diagnose.FruehereTumorerkrankungen",
      "short" : "Frühere Tumorerkrankungen",
      "definition" : "Tumorerkrankungen, die in der Anamnese zu einem früheren Zeitpunkt diagnostiziert/behandelt wurden.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Condition"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Condition"
      },
      {
        "identity" : "oBDS",
        "map" : "5.9",
        "comment" : "Frühere Tumorerkrankungen - eigenständig kodierte Vordiagnosen; im Profil MII_PR_Onko_Fruehere_Tumorerkrankung sind alle Detailangaben ebenfalls unter 5.9 geführt"
      }]
    },
    {
      "id" : "mii-lm-onko.Histologie",
      "path" : "mii-lm-onko.Histologie",
      "short" : "Histologie",
      "definition" : "Histologie",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "6",
        "comment" : "Histologie - oBDS Kapitel 6"
      }]
    },
    {
      "id" : "mii-lm-onko.Histologie.TumorHistologiedatum",
      "path" : "mii-lm-onko.Histologie.TumorHistologiedatum",
      "short" : "Tumor Histologiedatum",
      "definition" : "Datum, an dem die Gewebeprobe entnommen wurde.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.collection.collectedDateTime"
      },
      {
        "identity" : "oBDS",
        "map" : "6.1",
        "comment" : "Tumor Histologiedatum - Datum der Probenentnahme"
      }]
    },
    {
      "id" : "mii-lm-onko.Histologie.HistologieEinsendenummer",
      "path" : "mii-lm-onko.Histologie.HistologieEinsendenummer",
      "short" : "Histologie-Einsendenummer",
      "definition" : "Die Histologie-Einsendenummer/Auftragsnummer wird vom Pathologischen Institut beim Eingang des Präparates vergeben.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Specimen.accessionIdentifier"
      },
      {
        "identity" : "oBDS",
        "map" : "6.2",
        "comment" : "Histologie-Einsendenummer bzw. Auftragsnummer des Pathologischen Instituts"
      }]
    },
    {
      "id" : "mii-lm-onko.Histologie.MorphologieCode",
      "path" : "mii-lm-onko.Histologie.MorphologieCode",
      "short" : "Morphologie-Code",
      "definition" : "Gibt an, welche Histologie der Tumor aufweist.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Condition.extension.where(url='https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-histology-morphology-behavior-icdo3').valueCodeableConcept.code"
      },
      {
        "identity" : "oBDS",
        "map" : "6.3",
        "comment" : "Morphologie-Code nach ICD-O-3"
      }]
    },
    {
      "id" : "mii-lm-onko.Histologie.MorphologieICDOBlueBookVersion",
      "path" : "mii-lm-onko.Histologie.MorphologieICDOBlueBookVersion",
      "short" : "Morphologie ICD-O/Blue Book Version",
      "definition" : "Bezeichnung der zur Kodierung verwendeten ICD-O/Blue Book Version.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Condition.extension.where(url='https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-histology-morphology-behavior-icdo3').valueCodeableConcept.version"
      },
      {
        "identity" : "oBDS",
        "map" : "6.4",
        "comment" : "Morphologie ICD-O/Blue Book Version"
      }]
    },
    {
      "id" : "mii-lm-onko.Histologie.MorphologieFreitext",
      "path" : "mii-lm-onko.Histologie.MorphologieFreitext",
      "short" : "Morphologie-Freitext",
      "definition" : "Gibt die Originalbezeichnung der morphologischen Diagnose an.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Condition.code.text"
      },
      {
        "identity" : "oBDS",
        "map" : "6.5",
        "comment" : "Morphologie-Freitext - Originalbezeichnung der morphologischen Diagnose"
      }]
    },
    {
      "id" : "mii-lm-onko.Histologie.Grading",
      "path" : "mii-lm-onko.Histologie.Grading",
      "short" : "Grading",
      "definition" : "Gibt den Differenzierungsgrad des Tumors entsprechend der aktuellen TNM-Auflage an.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.where(system='https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-grading').code"
      },
      {
        "identity" : "oBDS",
        "map" : "6.6",
        "comment" : "Grading - Differenzierungsgrad nach aktueller TNM-Auflage"
      }]
    },
    {
      "id" : "mii-lm-onko.Histologie.AnzahlUntersuchteLymphknoten",
      "path" : "mii-lm-onko.Histologie.AnzahlUntersuchteLymphknoten",
      "short" : "Anzahl der untersuchten Lymphknoten",
      "definition" : "Gibt an, wie viele Lymphknoten untersucht wurden (einschließlich Sentinel).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "decimal"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.code.coding.where(system='http://loinc.org' and code='2708-6').select(%resource.valueQuantity.value)"
      },
      {
        "identity" : "oBDS",
        "map" : "6.7",
        "comment" : "Anzahl der untersuchten Lymphknoten einschließlich Sentinel"
      }]
    },
    {
      "id" : "mii-lm-onko.Histologie.AnzahlBefalleneLymphknoten",
      "path" : "mii-lm-onko.Histologie.AnzahlBefalleneLymphknoten",
      "short" : "Anzahl der befallenen Lymphknoten",
      "definition" : "Gibt an, wie viele Lymphknoten befallen sind (einschließlich Sentinel).",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "decimal"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.code.coding.where(system='http://loinc.org' and code='21893-3').select(%resource.valueQuantity.value)"
      },
      {
        "identity" : "oBDS",
        "map" : "6.8",
        "comment" : "Anzahl der befallenen Lymphknoten einschließlich Sentinel"
      }]
    },
    {
      "id" : "mii-lm-onko.Histologie.AnzahlUntersuchteSentinelLymphknoten",
      "path" : "mii-lm-onko.Histologie.AnzahlUntersuchteSentinelLymphknoten",
      "short" : "Anzahl der untersuchten Sentinel-Lymphknoten",
      "definition" : "Gibt an, wie viele Sentinel-Lymphknoten untersucht wurden.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "decimal"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.code.coding.where(system='http://loinc.org' and code='85347-3').select(%resource.valueQuantity.value)"
      },
      {
        "identity" : "oBDS",
        "map" : "6.9",
        "comment" : "Anzahl der untersuchten Sentinel-Lymphknoten"
      }]
    },
    {
      "id" : "mii-lm-onko.Histologie.AnzahlBefalleneSentinelLymphknoten",
      "path" : "mii-lm-onko.Histologie.AnzahlBefalleneSentinelLymphknoten",
      "short" : "Anzahl der befallenen Sentinel-Lymphknoten",
      "definition" : "Gibt an, wie viele Sentinel-Lymphknoten befallen sind.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "decimal"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.code.coding.where(system='http://loinc.org' and code='92832-5').select(%resource.valueQuantity.value)"
      },
      {
        "identity" : "oBDS",
        "map" : "6.10",
        "comment" : "Anzahl der befallenen Sentinel-Lymphknoten"
      }]
    },
    {
      "id" : "mii-lm-onko.Histologie.Befund",
      "path" : "mii-lm-onko.Histologie.Befund",
      "short" : "Befund",
      "definition" : "Vollständiger Befundbericht des Pathologen.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "DiagnosticReport.code.coding.where(system='http://loinc.org' and code='60568-3').select(%resource.conclusion)"
      },
      {
        "identity" : "oBDS",
        "map" : "6.11",
        "comment" : "Befund - vollständiger Befundbericht des Pathologen"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation",
      "path" : "mii-lm-onko.TNMKlassifikation",
      "short" : "TNM-Klassifikation",
      "definition" : "TNM-Klassifikation",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "8",
        "comment" : "TNM-Klassifikation - oBDS Kapitel 8"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMDatum",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMDatum",
      "short" : "TNM Datum",
      "definition" : "Gibt an, auf welches Datum sich die TNM-Klassifikation bezieht.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.effectiveDateTime"
      },
      {
        "identity" : "oBDS",
        "map" : "8.1",
        "comment" : "TNM Datum - Bezugsdatum der Klassifikation"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMVersion",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMVersion",
      "short" : "TNM Version",
      "definition" : "Gibt an, nach welcher Version des TNM klassifiziert wurde.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.method"
      },
      {
        "identity" : "oBDS",
        "map" : "8.2",
        "comment" : "TNM Version - verwendete TNM-Auflage"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMySymbol",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMySymbol",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "101658-3",
        "display" : "Cancer staging after multimodality therapy"
      }],
      "short" : "TNM y-Symbol",
      "definition" : "Gibt an, ob die Klassifikation während oder nach initialer multimodaler Therapie erfolgte.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.3",
        "comment" : "TNM y-Symbol - Klassifikation während oder nach initialer multimodaler Therapie"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMrSymbol",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMrSymbol",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "101659-1",
        "display" : "Cancer staging after tumor recurrence"
      }],
      "short" : "TNM r-Symbol",
      "definition" : "Gibt an, ob die Klassifikation ein Rezidiv beurteilt.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.4",
        "comment" : "TNM r-Symbol - Klassifikation eines Rezidivs"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMaSymbol",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMaSymbol",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "101660-9",
        "display" : "Cancer staging during autopsy"
      }],
      "short" : "TNM a-Symbol",
      "definition" : "Gibt an, ob die Klassifikation aus Anlass einer Autopsie erfolgte.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.5",
        "comment" : "TNM a-Symbol - Klassifikation aus Anlass einer Autopsie"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMcpuPraefixT",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMcpuPraefixT",
      "short" : "TNM c/p-Präfix T",
      "definition" : "Gibt an, ob die Klassifikation klinisch oder pathologisch erfolgte.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.code.extension.where(url='https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix').value.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.6",
        "comment" : "TNM c/p-Präfix T"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMcpuPraefixN",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMcpuPraefixN",
      "short" : "TNM c/p-Präfix N",
      "definition" : "Gibt an, ob die Klassifikation klinisch oder pathologisch erfolgte.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.code.extension.where(url='https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix').value.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.7",
        "comment" : "TNM c/p-Präfix N"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMcpuPraefixM",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMcpuPraefixM",
      "short" : "TNM c/p-Präfix M",
      "definition" : "Gibt an, ob die Klassifikation klinisch oder pathologisch erfolgte.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.code.extension.where(url='https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix').value.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.8",
        "comment" : "TNM c/p-Präfix M"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMTKategorie",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMTKategorie",
      "short" : "TNM T-Kategorie",
      "definition" : "Ausbreitung des Primärtumors, erfolgt gemäß Tumorentität nach TNM.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.9",
        "comment" : "TNM T-Kategorie - Ausbreitung des Primärtumors"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMmSymbol",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMmSymbol",
      "short" : "TNM m-Symbol",
      "definition" : "Kennzeichnet Vorhandensein multipler Primärtumoren in einem anatomischen Bezirk.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.10",
        "comment" : "TNM m-Symbol - multiple Primärtumoren in einem anatomischen Bezirk"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMMKategorie",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMMKategorie",
      "short" : "TNM M-Kategorie",
      "definition" : "Fehlen oder Vorhandensein von Fernmetastasen, gemäß Tumorentität nach TNM.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.12",
        "comment" : "TNM M-Kategorie - Fehlen oder Vorhandensein von Fernmetastasen"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMNKategorie",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMNKategorie",
      "short" : "TNM N-Kategorie",
      "definition" : "Ausbreitung von regionären Lymphknotenmetastasen, erfolgt gemäß Tumorentität nach TNM.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.11",
        "comment" : "TNM N-Kategorie - regionäre Lymphknotenmetastasen"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMLKategorie",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMLKategorie",
      "code" : [{
        "system" : "http://snomed.info/sct",
        "code" : "395715009",
        "display" : "Status of lymphatic (small vessel) invasion by tumor (observable entity)"
      }],
      "short" : "TNM L-Kategorie",
      "definition" : "Lymphgefäßinvasion.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.13",
        "comment" : "TNM L-Kategorie - Lymphgefäßinvasion"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMVKategorie",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMVKategorie",
      "code" : [{
        "system" : "http://snomed.info/sct",
        "code" : "371493002",
        "display" : "Status of venous (large vessel) invasion by tumor (observable entity)"
      }],
      "short" : "TNM V-Kategorie",
      "definition" : "Veneninvasion.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.14",
        "comment" : "TNM V-Kategorie - Veneninvasion"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMPnKategorie",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMPnKategorie",
      "code" : [{
        "system" : "http://snomed.info/sct",
        "code" : "371513001",
        "display" : "Presence of direct invasion by primary malignant neoplasm to nerve (observable entity)"
      }],
      "short" : "TNM Pn-Kategorie",
      "definition" : "Perineuralinvasion.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.15",
        "comment" : "TNM Pn-Kategorie - Perineuralinvasion"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.TNMSKategorie",
      "path" : "mii-lm-onko.TNMKlassifikation.TNMSKategorie",
      "code" : [{
        "system" : "http://snomed.info/sct",
        "code" : "399424006",
        "display" : "Serum tumor marker category (observable entity)"
      }],
      "short" : "TNM S-Kategorie",
      "definition" : "Serumtumormarker.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.16",
        "comment" : "TNM S-Kategorie - Serumtumormarker"
      }]
    },
    {
      "id" : "mii-lm-onko.TNMKlassifikation.UICCStadium",
      "path" : "mii-lm-onko.TNMKlassifikation.UICCStadium",
      "short" : "UICC Stadium",
      "definition" : "Stadium nach aktuell gültiger TNM-Klassifikation.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "8.17",
        "comment" : "UICC Stadium nach aktuell gültiger TNM-Klassifikation"
      }]
    },
    {
      "id" : "mii-lm-onko.WeitereKlassifikationen",
      "path" : "mii-lm-onko.WeitereKlassifikationen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation"
      },
      {
        "identity" : "oBDS",
        "map" : "9",
        "comment" : "Weitere Klassifikationen - oBDS Kapitel 9; in den Profilen zweistellig als 09 geführt"
      }]
    },
    {
      "id" : "mii-lm-onko.WeitereKlassifikationen.WeitereKlassifikationDatum",
      "path" : "mii-lm-onko.WeitereKlassifikationen.WeitereKlassifikationDatum",
      "short" : "Hämatoonkologische und sonstige Klassifikationen Datum",
      "definition" : "Gibt an, auf welches Datum sich die Klassifikation bezieht.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.effectiveDateTime"
      },
      {
        "identity" : "oBDS",
        "map" : "9.1",
        "comment" : "Hämatoonkologische und sonstige Klassifikationen Datum - im Profil als 09.1 geführt"
      }]
    },
    {
      "id" : "mii-lm-onko.WeitereKlassifikationen.WeitereKlassifikationName",
      "path" : "mii-lm-onko.WeitereKlassifikationen.WeitereKlassifikationName",
      "short" : "Hämatoonkologische und sonstige Klassifikationen Name",
      "definition" : "Name der hämatologischen oder sonstigen Klassifikation. Art der Klassifikation.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.code.text"
      },
      {
        "identity" : "oBDS",
        "map" : "9.2",
        "comment" : "Hämatoonkologische und sonstige Klassifikationen Name - im Profil als 09.2 geführt"
      }]
    },
    {
      "id" : "mii-lm-onko.WeitereKlassifikationen.WeitereKlassifikationEinstufung",
      "path" : "mii-lm-onko.WeitereKlassifikationen.WeitereKlassifikationEinstufung",
      "short" : "Hämatoonkologische und sonstige Klassifikationen Einstufung",
      "definition" : "Einstufung gemäß der verwendeten hämatoonkologischen oder sonstigen Klassifikationen.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.value[x]"
      },
      {
        "identity" : "oBDS",
        "map" : "9.3",
        "comment" : "Hämatoonkologische und sonstige Klassifikationen Einstufung - im Profil als 09.3 geführt"
      }]
    },
    {
      "id" : "mii-lm-onko.Residualstatus",
      "path" : "mii-lm-onko.Residualstatus",
      "short" : "Residualstatus",
      "definition" : "Residualstatus",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "10",
        "comment" : "Residualstatus - oBDS Kapitel 10"
      }]
    },
    {
      "id" : "mii-lm-onko.Residualstatus.LokalerResidualstatus",
      "path" : "mii-lm-onko.Residualstatus.LokalerResidualstatus",
      "short" : "Beurteilung des lokalen Residualstatus nach Abschluss der Operation",
      "definition" : "Lokale Beurteilung der Residualklassifikation nach Resektion, bezieht sich auf das, was reseziert wurde, meist Primärtumor, aber z. B. auch Lebermetastasen.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.outcome"
      },
      {
        "identity" : "oBDS",
        "map" : "10.1",
        "comment" : "Beurteilung des lokalen Residualstatus nach Abschluss der Operation - im Profil MII_PR_Onko_Operation als Procedure.outcome geführt"
      }]
    },
    {
      "id" : "mii-lm-onko.Residualstatus.GlobalerResidualstatus",
      "path" : "mii-lm-onko.Residualstatus.GlobalerResidualstatus",
      "short" : "Gesamtbeurteilung des Residualstatus",
      "definition" : "Gesamtbeurteilung der Residualklassifikation der Erkrankung einschließlich etwaiger Fernmetastasen.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "10.2",
        "comment" : "Gesamtbeurteilung des Residualstatus einschließlich etwaiger Fernmetastasen"
      }]
    },
    {
      "id" : "mii-lm-onko.Fernmetastasen",
      "path" : "mii-lm-onko.Fernmetastasen",
      "short" : "Fernmetastasen",
      "definition" : "Fernmetastasen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "11",
        "comment" : "Fernmetastasen - oBDS Kapitel 11"
      }]
    },
    {
      "id" : "mii-lm-onko.Fernmetastasen.LokalisationFernmetastase",
      "path" : "mii-lm-onko.Fernmetastasen.LokalisationFernmetastase",
      "short" : "Lokalisation von Fernmetastase(n)",
      "definition" : "Lokalisation der Fernmetastase(n).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.bodySite"
      },
      {
        "identity" : "oBDS",
        "map" : "11.1",
        "comment" : "Lokalisation von Fernmetastasen"
      }]
    },
    {
      "id" : "mii-lm-onko.Fernmetastasen.DatumFernmetase",
      "path" : "mii-lm-onko.Fernmetastasen.DatumFernmetase",
      "short" : "Datum der diagnostischen Sicherung von Fernmetastasen",
      "definition" : "Gibt an, wann die Fernmetastase festgestellt wurde.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.effectiveDateTime"
      },
      {
        "identity" : "oBDS",
        "map" : "11.2",
        "comment" : "Datum der diagnostischen Sicherung von Fernmetastasen"
      }]
    },
    {
      "id" : "mii-lm-onko.AllgemeinerLeistungszustand",
      "path" : "mii-lm-onko.AllgemeinerLeistungszustand",
      "short" : "Allgemeiner Leistungszustand",
      "definition" : "Allgemeiner Leistungszustand",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "12",
        "comment" : "Allgemeiner Leistungszustand - oBDS Kapitel 12"
      }]
    },
    {
      "id" : "mii-lm-onko.AllgemeinerLeistungszustand.ECOGKarnofsky",
      "path" : "mii-lm-onko.AllgemeinerLeistungszustand.ECOGKarnofsky",
      "short" : "ECOG oder Karnofsky",
      "definition" : "ECOG oder Karnofsky",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.value[x]"
      },
      {
        "identity" : "oBDS",
        "map" : "12.1",
        "comment" : "Allgemeiner Leistungszustand nach ECOG oder Karnofsky - oBDS führt beide Skalen unter derselben Feldnummer"
      }]
    },
    {
      "id" : "mii-lm-onko.Operation",
      "path" : "mii-lm-onko.Operation",
      "short" : "Operation",
      "definition" : "Operation",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "13",
        "comment" : "Operation - oBDS Kapitel 13"
      }]
    },
    {
      "id" : "mii-lm-onko.Operation.OPIntention",
      "path" : "mii-lm-onko.Operation.OPIntention",
      "short" : "Intention",
      "definition" : "Gibt an, mit welchem Ziel die Operation geplant wurde",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "13.1",
        "comment" : "Intention der Operation"
      }]
    },
    {
      "id" : "mii-lm-onko.Operation.OPDatum",
      "path" : "mii-lm-onko.Operation.OPDatum",
      "short" : "OP Datum",
      "definition" : "Datum der OP",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.performedDateTime"
      },
      {
        "identity" : "oBDS",
        "map" : "13.2",
        "comment" : "OP Datum"
      }]
    },
    {
      "id" : "mii-lm-onko.Operation.OPSCode",
      "path" : "mii-lm-onko.Operation.OPSCode",
      "short" : "OPS Code",
      "definition" : "Gibt an, welche Operation durchgeführ wurde. OPS (5-*), so genau wie möglich. Bei paaringen Organen mit Seitenangabe",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.code.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "13.3",
        "comment" : "OPS - Operationen- und Prozedurenschlüssel"
      }]
    },
    {
      "id" : "mii-lm-onko.Operation.OPSVersion",
      "path" : "mii-lm-onko.Operation.OPSVersion",
      "short" : "OPS Version",
      "definition" : "Gibt an, nach welcher Version (Jahr) des OPS klassifiziert wurde (Gültige Bezeichnung nach BfArM)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.code.coding.version"
      },
      {
        "identity" : "oBDS",
        "map" : "13.4",
        "comment" : "OPS Version - Jahresversion nach BfArM"
      }]
    },
    {
      "id" : "mii-lm-onko.Operation.OPKomplikation",
      "path" : "mii-lm-onko.Operation.OPKomplikation",
      "short" : "OP Komplikationen",
      "definition" : "Gibt an, ob eine oder keine Komplikation aufgetreten ist, bzw. wenn eine aufgetreten ist welche.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.complication.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "13.5",
        "comment" : "OP Komplikationen"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie",
      "path" : "mii-lm-onko.Strahlentherapie",
      "short" : "Strahlentherapie",
      "definition" : "Strahlentherapie",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "14",
        "comment" : "Strahlentherapie - oBDS Kapitel 14"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieIntention",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieIntention",
      "short" : "Intention der Strahlentherapie",
      "definition" : "Gibt an, mit welcher Intention die Strahlentherapie geplant wurde.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension[Intention].valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "14.1",
        "comment" : "Intention der Strahlentherapie"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieStellung",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieStellung",
      "short" : "Strahlentherapie Stellung zu operativer Therapie",
      "definition" : "Gibt an, in welchem Bezug zu einer operativen Therapie die Bestrahlung steht.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension[Stellung].valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "14.2",
        "comment" : "Strahlentherapie Stellung zu operativer Therapie"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieEndeGrund",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieEndeGrund",
      "short" : "Strahlentherapie Ende Grund",
      "definition" : "Gibt den Grund an, warum die Strahlentherapie beendet wurde.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.outcome.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "14.13",
        "comment" : "Strahlentherapie Ende Grund"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung",
      "short" : "Bestrahlung",
      "definition" : "Dieser Abschnitt entspricht einer Bestrahlung mit spezifischem Zielgebiet, Methodik und Dosis ",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension[Bestrahlung]"
      },
      {
        "identity" : "oBDS",
        "map" : "14.3-14.12",
        "comment" : "Bestrahlung - eine Bestrahlung mit spezifischem Zielgebiet Methodik und Dosis; im oBDS keine eigene Feldnummer sondern Gruppierung der Felder 14.3 bis 14.12"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieZielgebiet",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieZielgebiet",
      "short" : "Strahlentherapie Zielgebiet",
      "definition" : "Gibt an, an welcher anatomischen Region die Bestrahlung durchgeführt wurde.",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension[Bestrahlung].extension[Zielgebiet].valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "14.3",
        "comment" : "Strahlentherapie Zielgebiet"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieSeiteZielgebiet",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieSeiteZielgebiet",
      "short" : "Strahlentherapie Seite Zielgebiet",
      "definition" : "Bei Zielgebieten, die durch \"(r, l)\" gekennzeichnet sind, ist eine Seitenangabe Pflicht.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension[Bestrahlung].extension[Zielgebiet_Lateralitaet].valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "14.4",
        "comment" : "Strahlentherapie Seite Zielgebiet - Pflichtangabe bei mit r/l gekennzeichneten Zielgebieten"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieBeginn",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieBeginn",
      "short" : "Strahlentherapie Beginn",
      "definition" : "Gibt an, wann die Strahlentherapie begonnen wurde.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.performedPeriod.start"
      },
      {
        "identity" : "oBDS",
        "map" : "14.5",
        "comment" : "Strahlentherapie Beginn"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieEnde",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieEnde",
      "short" : "Strahlentherapie Ende",
      "definition" : "Gibt an, wann die Strahlentherapie beendet wurde.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.performedPeriod.end"
      },
      {
        "identity" : "oBDS",
        "map" : "14.6",
        "comment" : "Strahlentherapie Ende"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieApplikationsart",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieApplikationsart",
      "short" : "Strahlentherapie Applikationsart",
      "definition" : "Gibt an, mit welcher Technik die Strahlentherapie durchgeführt wurde.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension[Bestrahlung].extension[Applikationsart].valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "14.7",
        "comment" : "Strahlentherapie Applikationsart"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieStrahlenart",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieStrahlenart",
      "short" : "Strahlenart",
      "definition" : "Angewandte Strahlenart (Strahlung oder metabolische Nuklide)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension[Bestrahlung].extension[Strahlenart].valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "14.8",
        "comment" : "Strahlentherapie Strahlenart"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieGesamtdosis",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieGesamtdosis",
      "short" : "Strahlentherapie Gesamtdosis",
      "definition" : "Gibt an, mit welcher Gesamtdosis das Zielgebiet bestrahlt wurde (inklusive Boost).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension[Bestrahlung].extension[Gesamtdosis].valueQuantity.value"
      },
      {
        "identity" : "oBDS",
        "map" : "14.9",
        "comment" : "Strahlentherapie Gesamtdosis inklusive Boost"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieEinzeldosis",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieEinzeldosis",
      "short" : "Strahlentherapie Einzeldosis",
      "definition" : "Strahlentherapie Einzeldosis pro Tag (Dosis)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension[Bestrahlung].extension[Einzeldosis].valueQuantity.value"
      },
      {
        "identity" : "oBDS",
        "map" : "14.10",
        "comment" : "Strahlentherapie Einzeldosis pro Tag"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieEinheit",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieEinheit",
      "short" : "Strahlentherapie Einheit",
      "definition" : "Gibt die Einheit zu der Einzel- oder Gesamtdosis an, mit welcher das Zielgebiet bestrahlt wurde, bzw. bei metabolischer Therapie die Aktivität des verwendeten Radionuklids.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension[Bestrahlung].extension[Einheit].valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "14.11",
        "comment" : "Strahlentherapie Einheit zu Einzel- und Gesamtdosis - in den Profilen als Quantity.unit an 14.9 und 14.10 abgebildet"
      }]
    },
    {
      "id" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieBoost",
      "path" : "mii-lm-onko.Strahlentherapie.StrahlentherapieBestrahlung.StrahlentherapieBoost",
      "short" : "Boost",
      "definition" : "Angabe, ob ein Boost und falls ja, welche Art von Boost appliziert wurde.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension[Bestrahlung].extension[Boost].valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "14.12",
        "comment" : "Strahlentherapie Boost"
      }]
    },
    {
      "id" : "mii-lm-onko.SystemischeTherapie",
      "path" : "mii-lm-onko.SystemischeTherapie",
      "short" : "Systemische Therapie",
      "definition" : "Systemische Therapie",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "16",
        "comment" : "Systemische Therapie - oBDS Kapitel 16"
      }]
    },
    {
      "id" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieIntention",
      "path" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieIntention",
      "short" : "Intention der systemischen Therapie",
      "definition" : "Intention der systemischen Therapie",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension[Intention].valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "16.1",
        "comment" : "Intention der systemischen Therapie"
      }]
    },
    {
      "id" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieStellung",
      "path" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieStellung",
      "short" : "Systemische Therapie Stellung zu operativer Therapie",
      "definition" : "Gibt an, in welchem Bezug zu einer operativen Therapie die systemische Therapie steht.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.extension[Stellung].valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "16.2",
        "comment" : "Systemische Therapie Stellung zu operativer Therapie"
      }]
    },
    {
      "id" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieArtTherapie",
      "path" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieArtTherapie",
      "short" : "Art der systemischen oder abwartenden Therapie",
      "definition" : "Gibt an, welche Art der Therapie bzw. abwartende Strategie durchgeführt wurde.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.code.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "16.3",
        "comment" : "Art der systemischen oder abwartenden Therapie"
      }]
    },
    {
      "id" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieProtokoll",
      "path" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieProtokoll",
      "short" : "Systemische Therapie Protokoll",
      "definition" : "Gibt an, nach welchem Protokoll die Systemtherapie durchgeführt wurde.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.medicationCodeableConcept.text "
      },
      {
        "identity" : "oBDS",
        "map" : "16.4",
        "comment" : "Systemische Therapie Protokoll"
      }]
    },
    {
      "id" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieSubstanz",
      "path" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieSubstanz",
      "short" : "Systemische Therapie Substanz",
      "definition" : "Gibt an, mit welcher Substanz die Systemtherapie durchgeführt wurde. Nach Möglichkeit ATC kodiert. Mehrere Substanzen sind jeweils einzeln zu kodieren. ",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationStatement.medicationCodeableConcept[atcClassDe].coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "16.6",
        "comment" : "Systemische Therapie Substanz - nach Möglichkeit ATC-kodiert"
      }]
    },
    {
      "id" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieBeginn",
      "path" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieBeginn",
      "short" : "Systemische Therapie Beginn",
      "definition" : "Gibt an, wann die systemische Therapie begonnen wurde.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.performedPeriod.start"
      },
      {
        "identity" : "oBDS",
        "map" : "16.5",
        "comment" : "Systemische Therapie Beginn"
      }]
    },
    {
      "id" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieEnde",
      "path" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieEnde",
      "short" : "Systemische Therapie Ende Grund",
      "definition" : "Gibt den Grund an, warum die Systemtherapie beendet wurde.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.performedPeriod.end"
      },
      {
        "identity" : "oBDS",
        "map" : "16.8",
        "comment" : "Systemische Therapie Ende - Enddatum; die Kurzbeschreibung im LM ist mit der von SystemischeTherapieEndeGrund vertauscht"
      }]
    },
    {
      "id" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieEndeGrund",
      "path" : "mii-lm-onko.SystemischeTherapie.SystemischeTherapieEndeGrund",
      "short" : "Systemische Therapie Ende",
      "definition" : "Gibt an, wann die systemische Therapie beendet wurde.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Procedure.outcome.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "16.7",
        "comment" : "Systemische Therapie Ende Grund; die Kurzbeschreibung im LM ist mit der von SystemischeTherapieEnde vertauscht"
      }]
    },
    {
      "id" : "mii-lm-onko.Nebenwirkungen",
      "path" : "mii-lm-onko.Nebenwirkungen",
      "short" : "Nebenwirkungen",
      "definition" : "Nebenwirkungen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "15",
        "comment" : "Nebenwirkungen der Strahlentherapie und systemischen Therapie - oBDS Kapitel 15"
      }]
    },
    {
      "id" : "mii-lm-onko.Nebenwirkungen.NebenwirkungenCTCAEGrad",
      "path" : "mii-lm-onko.Nebenwirkungen.NebenwirkungenCTCAEGrad",
      "short" : "Nebenwirkungen nach CTCAE-Grad",
      "definition" : "Gibt an, zu welchem Schweregrad von Nebenwirkungen es bei der Bestrahlung oder der systemischen Therapie gekommen ist.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "AdverseEvent.seriousness.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "15.1",
        "comment" : "Nebenwirkungen nach CTCAE-Grad"
      }]
    },
    {
      "id" : "mii-lm-onko.Nebenwirkungen.NebenwirkungenCTCAEArt",
      "path" : "mii-lm-onko.Nebenwirkungen.NebenwirkungenCTCAEArt",
      "short" : "Nebenwirkungen nach CTCAE Art",
      "definition" : "Gibt an, zu welcher Nebenwirkung es bei der Bestrahlung oder der systemischen Therapie gekommen ist. Bei der Bestrahlung sind sogenannte akute Nebenwirkungen bis zum 90. Tag nach Bestrahlungsbeginn gemeint.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "AdverseEvent.event.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "15.2",
        "comment" : "Nebenwirkungen nach CTCAE Art"
      }]
    },
    {
      "id" : "mii-lm-onko.Nebenwirkungen.NebenwirkungenCTCAEVersion",
      "path" : "mii-lm-onko.Nebenwirkungen.NebenwirkungenCTCAEVersion",
      "short" : "Nebenwirkungen nach CTCAE Version",
      "definition" : "Für den medizinischen Katalog gültige Versionsbezeichnungen (4, 4.03, 5.0, Sonstige). Gemeint ist die Version des CTCAE-Katalogs, nicht die des MedDRA-Katalogs, aus dem die Codes stammen — CTCAE v4.03 basiert auf MedDRA v12.0.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "AdverseEvent.extension.where(url='https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-nebenwirkung-ctcae-version').valueCodeableConcept"
      },
      {
        "identity" : "oBDS",
        "map" : "15.3",
        "comment" : "Nebenwirkungen nach CTCAE Version"
      }]
    },
    {
      "id" : "mii-lm-onko.Verlauf",
      "path" : "mii-lm-onko.Verlauf",
      "short" : "Verlauf",
      "definition" : "Verlauf",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "17",
        "comment" : "Verlauf - oBDS Kapitel 17"
      }]
    },
    {
      "id" : "mii-lm-onko.Verlauf.VerlaufDatum",
      "path" : "mii-lm-onko.Verlauf.VerlaufDatum",
      "short" : "Untersuchungsdatum Verlauf",
      "definition" : "Datum, an dem die letzte Untersuchung durchgeführt wurde, die zur Einschätzung des Tumorstatus geführt hat.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "date"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "17.1",
        "comment" : "Untersuchungsdatum Verlauf"
      }]
    },
    {
      "id" : "mii-lm-onko.Verlauf.VerlaufBeurteilungTumorstatus",
      "path" : "mii-lm-onko.Verlauf.VerlaufBeurteilungTumorstatus",
      "short" : "Gesamtbeurteilung des Tumorstatus",
      "definition" : "Gesamtbeurteilung der Erkrankung unter Berücksichtigung aller Manifestationen.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "17.2",
        "comment" : "Gesamtbeurteilung des Tumorstatus"
      }]
    },
    {
      "id" : "mii-lm-onko.Verlauf.VerlaufTumorstatusPrimaertumor",
      "path" : "mii-lm-onko.Verlauf.VerlaufTumorstatusPrimaertumor",
      "short" : "Tumorstatus Primärtumor",
      "definition" : "Beurteilung der Situation im Primärtumorbereich.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "17.3",
        "comment" : "Tumorstatus Primärtumor"
      }]
    },
    {
      "id" : "mii-lm-onko.Verlauf.VerlaufTumorstatusLymphknoten",
      "path" : "mii-lm-onko.Verlauf.VerlaufTumorstatusLymphknoten",
      "short" : "Tumorstatus Lymphknoten",
      "definition" : "Beurteilung der Situation im Bereich der regionären Lymphknoten.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "17.4",
        "comment" : "Tumorstatus Lymphknoten"
      }]
    },
    {
      "id" : "mii-lm-onko.Verlauf.VerlaufTumorstatusMetastasen",
      "path" : "mii-lm-onko.Verlauf.VerlaufTumorstatusMetastasen",
      "short" : "Tumorstatus Fernmetastasen",
      "definition" : "Beurteilung der Situation im Bereich der Fernmetastasen.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "17.5",
        "comment" : "Tumorstatus Fernmetastasen"
      }]
    },
    {
      "id" : "mii-lm-onko.Tumorkonferenz",
      "path" : "mii-lm-onko.Tumorkonferenz",
      "short" : "Tumorkonferenz und Therapieempfehlung",
      "definition" : "Tumorkonferenz und Therapieempfehlung",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "18, 19",
        "comment" : "Tumorkonferenz oBDS Kapitel 18 und Therapieempfehlung oBDS Kapitel 19"
      }]
    },
    {
      "id" : "mii-lm-onko.Tumorkonferenz.TumorkonferenzTherapieplanungDatum",
      "path" : "mii-lm-onko.Tumorkonferenz.TumorkonferenzTherapieplanungDatum",
      "short" : "Tumorkonferenz Therapieplanung Datum",
      "definition" : "Datum der Durchführung der Tumorkonferenz bzw. der sonstigen Therapieplanung.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "CarePlan.created"
      },
      {
        "identity" : "oBDS",
        "map" : "18.1",
        "comment" : "Tumorkonferenz Therapieplanung Datum"
      }]
    },
    {
      "id" : "mii-lm-onko.Tumorkonferenz.TumorkonferenzTherapieplanungTyp",
      "path" : "mii-lm-onko.Tumorkonferenz.TumorkonferenzTherapieplanungTyp",
      "short" : "Tumorkonferenz Therapieplanung Typ",
      "definition" : "Typ der Tumorkonferenz bzw. der sonstigen Therapieplanung.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "CarePlan.category"
      },
      {
        "identity" : "oBDS",
        "map" : "18.2",
        "comment" : "Tumorkonferenz Therapieplanung Typ"
      }]
    },
    {
      "id" : "mii-lm-onko.Tumorkonferenz.TumorkonferenzTherapieempfehlungTyp",
      "path" : "mii-lm-onko.Tumorkonferenz.TumorkonferenzTherapieempfehlungTyp",
      "short" : "Tumorkonferenz Therapieempfehlung Typ",
      "definition" : "Typ der Therapieempfehlung der Tumorkonferenz (z.B. CH, OP, ST).",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "RequestGroup.code (Therapy type: CH, OP, ST, etc.)"
      },
      {
        "identity" : "oBDS",
        "map" : "19.1",
        "comment" : "Tumorkonferenz Therapieempfehlung Typ - z.B. CH OP ST"
      }]
    },
    {
      "id" : "mii-lm-onko.Tumorkonferenz.TumorkonferenzTherapieempfehlungProtokoll",
      "path" : "mii-lm-onko.Tumorkonferenz.TumorkonferenzTherapieempfehlungProtokoll",
      "short" : "Tumorkonferenz Therapieempfehlung Protokoll",
      "definition" : "Empfohlenes Therapieprotokoll bei systemischer Therapie (z.B. FOLFOX4, R-CHOP, AC). Optional, insbesondere bei Kombinationstherapien.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "RequestGroup.action.code (Protocol: FOLFOX4, R-CHOP, etc.)"
      },
      {
        "identity" : "oBDS",
        "map" : "19.1 (Erweiterung)",
        "comment" : "Empfohlenes Therapieprotokoll - MII-Erweiterung zu 19.1; der oBDS erfasst in 19.1 nur den Therapietyp ohne Protokollangabe"
      }]
    },
    {
      "id" : "mii-lm-onko.Tumorkonferenz.TumorkonferenzTherapieempfehlungMedikation",
      "path" : "mii-lm-onko.Tumorkonferenz.TumorkonferenzTherapieempfehlungMedikation",
      "short" : "Tumorkonferenz Therapieempfehlung Medikation",
      "definition" : "Einzelne empfohlene Medikamente/Substanzen der Therapie (z.B. ATC-kodiert). Bei Kombinationstherapien werden mehrere Medikamente angegeben.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "MedicationRequest.medicationCodeableConcept (referenced from RequestGroup.action.action.resource)"
      },
      {
        "identity" : "oBDS",
        "map" : "19.1 (Erweiterung)",
        "comment" : "Einzelne empfohlene Substanzen - MII-Erweiterung zu 19.1; der oBDS erfasst in 19.1 nur den Therapietyp ohne Substanzangabe"
      }]
    },
    {
      "id" : "mii-lm-onko.Tumorkonferenz.TumorkonferenzTherapieAbweichungPatientenwunsch",
      "path" : "mii-lm-onko.Tumorkonferenz.TumorkonferenzTherapieAbweichungPatientenwunsch",
      "short" : "Tumorkonferenz/Therapieempfehlung Therapieabweichung auf Wunsch des Patienten",
      "definition" : "Abweichung auf Wunsch des Patienten.",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "CarePlan.activity.detail.status & statusReason"
      },
      {
        "identity" : "oBDS",
        "map" : "19.2",
        "comment" : "Tumorkonferenz bzw. Therapieempfehlung Therapieabweichung auf Wunsch des Patienten"
      }]
    },
    {
      "id" : "mii-lm-onko.Tod",
      "path" : "mii-lm-onko.Tod",
      "short" : "Tod",
      "definition" : "Tod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "20",
        "comment" : "Tod - oBDS Kapitel 20"
      }]
    },
    {
      "id" : "mii-lm-onko.Tod.Sterbedatum",
      "path" : "mii-lm-onko.Tod.Sterbedatum",
      "short" : "Sterbedatum",
      "definition" : "Datum des Todes",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.effectiveDateTime"
      },
      {
        "identity" : "oBDS",
        "map" : "20.1",
        "comment" : "Sterbedatum"
      }]
    },
    {
      "id" : "mii-lm-onko.Tod.TodTumorbedingt",
      "path" : "mii-lm-onko.Tod.TodTumorbedingt",
      "short" : "Tod tumorbedingt",
      "definition" : "Krebs-Tod-Relation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.interpretation.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "20.2",
        "comment" : "Tod tumorbedingt - Krebs-Tod-Relation"
      }]
    },
    {
      "id" : "mii-lm-onko.Tod.TodesursacheICD",
      "path" : "mii-lm-onko.Tod.TodesursacheICD",
      "short" : "Todesursache ICD",
      "definition" : "Todesursache im Sinne des Grundleidens",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "20.3",
        "comment" : "Todesursache ICD im Sinne des Grundleidens"
      }]
    },
    {
      "id" : "mii-lm-onko.Tod.TodesursacheICDVersion",
      "path" : "mii-lm-onko.Tod.TodesursacheICDVersion",
      "short" : "Todesursache ICD Version",
      "definition" : "Bezeichnung der zur Kodierung verwendeten ICD-GM-Version",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.version"
      },
      {
        "identity" : "oBDS",
        "map" : "20.4",
        "comment" : "Todesursache ICD-Version"
      }]
    },
    {
      "id" : "mii-lm-onko.GenetischeVariante",
      "path" : "mii-lm-onko.GenetischeVariante",
      "short" : "Genetische Variante",
      "definition" : "Genetische Variante",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation"
      },
      {
        "identity" : "oBDS",
        "map" : "23",
        "comment" : "Genetische Variante - oBDS Kapitel 23"
      }]
    },
    {
      "id" : "mii-lm-onko.GenetischeVariante.GenetischeVarianteName",
      "path" : "mii-lm-onko.GenetischeVariante.GenetischeVarianteName",
      "short" : "Genetische Variante Name",
      "definition" : "Name der genetischen Variante (z.B. K-ras, BRAFV600, NRAS, C-KIT)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.note"
      },
      {
        "identity" : "oBDS",
        "map" : "23.1",
        "comment" : "Genetische Variante Name - z.B. K-ras BRAFV600 NRAS C-KIT"
      }]
    },
    {
      "id" : "mii-lm-onko.GenetischeVariante.GenetischeVarianteAuspraegung",
      "path" : "mii-lm-onko.GenetischeVariante.GenetischeVarianteAuspraegung",
      "short" : "Genetische Variante Ausprägung",
      "definition" : "Ausprägung der genetischen Variante nach oBDS",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.interpretation"
      },
      {
        "identity" : "oBDS",
        "map" : "23.2",
        "comment" : "Genetische Variante Ausprägung"
      }]
    },
    {
      "id" : "mii-lm-onko.Studienteilnahme",
      "path" : "mii-lm-onko.Studienteilnahme",
      "short" : "Studienteilnahme",
      "definition" : "Studienteilnahme",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation"
      },
      {
        "identity" : "oBDS",
        "map" : "24",
        "comment" : "Studienteilnahme - oBDS Kapitel 24"
      }]
    },
    {
      "id" : "mii-lm-onko.Studienteilnahme.StudienteilnahmeStatus",
      "path" : "mii-lm-onko.Studienteilnahme.StudienteilnahmeStatus",
      "short" : "Studienteilnahme Status",
      "definition" : "Einschluss in eine Studie mit Ethikvotum",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueCodeableConcept.coding.code"
      },
      {
        "identity" : "oBDS",
        "map" : "24.1",
        "comment" : "Studienteilnahme Status - Einschluss in eine Studie mit Ethikvotum"
      }]
    },
    {
      "id" : "mii-lm-onko.Studienteilnahme.StudienteilnahmeDatum",
      "path" : "mii-lm-onko.Studienteilnahme.StudienteilnahmeDatum",
      "short" : "Studienteilnahme Datum",
      "definition" : "Erstes Einschlussdatum einer Studie mit Ethikvotum",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.effectiveDateTime"
      },
      {
        "identity" : "oBDS",
        "map" : "24.2",
        "comment" : "Studienteilnahme Datum - erstes Einschlussdatum"
      }]
    },
    {
      "id" : "mii-lm-onko.Studienteilnahme.StudienteilnahmeStudienreferenz",
      "path" : "mii-lm-onko.Studienteilnahme.StudienteilnahmeStudienreferenz",
      "short" : "Studienteilnahme Studienreferenz",
      "definition" : "Referenz zur konkreten Studie (ResearchStudy)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.focus.where(resolve() is ResearchStudy)"
      },
      {
        "identity" : "oBDS",
        "map" : "kein oBDS-Feld",
        "comment" : "Referenz auf die konkrete Studie als ResearchStudy - MII-Ergänzung; der oBDS benennt Studien nur im pädiatrischen Zusatzmodul DKKR/GPOH mit Studienname und Studiennummer nicht in Kapitel 24"
      }]
    }]
  }
}

```
