# MII CS Onkologie TNM UICC - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII CS Onkologie TNM UICC**

## CodeSystem: MII CS Onkologie TNM UICC 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.uicc.org/resources/tnm | *Version*:2026.0.3 |
| Active Stand: 2026-08-28 | *Maschinenlesbarer Name*:MII_CS_Onko_TNM_UICC |

 
Codes für TNM UICC Ausprägungen. HINWEIS zur Auflagen-Versionierung: Dieses CodeSystem ist bewusst eine auflagen-übergreifende Union (8. Auflage + Ergänzungen der 9. Auflage, z.B. T1b3/M1c1/M1c2); die verwendete Auflage wird als eigenes Datenelement (TNM-Version, oBDS 8.2) dokumentiert. Eine formal strengere, auflagen-versionierte Validierung (je Auflage ein CS-/VS-Stand nach dem Muster der ATC-/ICD-O-Jahresversionen) ist als spätere Ausbaustufe vorgesehen. 

Dieses CodeSystem wird in der Definition der folgenden ValueSets referenziert:

* [MII VS Onkologie TNM c/p/u Praefix](ValueSet-mii-vs-onko-tnm-cp-praefix.md)
* [MII VS Onkologie TNM ITC Suffix](ValueSet-mii-vs-onko-tnm-itc-suffix.md)
* [MII VS Onkologie TNM L Kategorie Werte](ValueSet-mii-vs-onko-tnm-l-kategorie-werte.md)
* [MII VS Onkologie TNM M Kategorie Werte](ValueSet-mii-vs-onko-tnm-m-kategorie-werte.md)
* [MII VS Onkologie TNM m-Symbol](ValueSet-mii-vs-onko-tnm-m-symbol.md)
* [MII VS Onkologie TNM N Kategorie Werte](ValueSet-mii-vs-onko-tnm-n-kategorie-werte.md)
* [MII VS Onkologie TNM Pn Kategorie Werte](ValueSet-mii-vs-onko-tnm-pn-kategorie-werte.md)
* [MII VS Onkologie TNM S Kategorie Werte](ValueSet-mii-vs-onko-tnm-s-kategorie-werte.md)
* [MII VS Onkologie TNM SN Suffix](ValueSet-mii-vs-onko-tnm-sn-suffix.md)
* [MII VS Onkologie TNM T Kategorie Werte](ValueSet-mii-vs-onko-tnm-t-kategorie-werte.md)
* [MII VS Onkologie TNM UICC Stadium](ValueSet-mii-vs-onko-tnm-uicc-stadium.md)
* [MII VS Onkologie TNM V Kategorie Werte](ValueSet-mii-vs-onko-tnm-v-kategorie-werte.md)

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "mii-cs-onko-tnm-uicc",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablecodesystem",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablecodesystem"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionPolicy",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes",
        "code" : "package",
        "display" : "Package"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-approvalDate",
    "valueDate" : "2026-01-03"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-topic",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
        "code" : "C3262"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-author",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "email",
        "value" : "thomas.debertshaeuser@charite.de"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-editor",
    "valueContactDetail" : {
      "name" : "Taskforce Core Data Set"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  }],
  "url" : "https://www.uicc.org/resources/tnm",
  "version" : "2026.0.3",
  "name" : "MII_CS_Onko_TNM_UICC",
  "title" : "MII CS Onkologie TNM UICC",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-28T12:26:30+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Codes für TNM UICC Ausprägungen. HINWEIS zur Auflagen-Versionierung: Dieses CodeSystem ist bewusst eine auflagen-übergreifende Union (8. Auflage + Ergänzungen der 9. Auflage, z.B. T1b3/M1c1/M1c2); die verwendete Auflage wird als eigenes Datenelement (TNM-Version, oBDS 8.2) dokumentiert. Eine formal strengere, auflagen-versionierte Validierung (je Auflage ein CS-/VS-Stand nach dem Muster der ATC-/ICD-O-Jahresversionen) ist als spätere Ausbaustufe vorgesehen.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 138,
  "concept" : [{
    "code" : "y",
    "display" : "y",
    "definition" : "Klassifikation erfolgte während oder nach initialer multimodaler Therapie"
  },
  {
    "code" : "r",
    "display" : "r",
    "definition" : "Klassifikation erfolgte zur Beurteilung eines Rezidivs"
  },
  {
    "code" : "a",
    "display" : "a",
    "definition" : "Klassifikation erfolgte durch Autopsie"
  },
  {
    "code" : "c",
    "display" : "c",
    "definition" : "Kategorie wurde durch klinische Angaben festgestellt."
  },
  {
    "code" : "p",
    "display" : "p",
    "definition" : "Feststellung der Kategorie erfolgte durch eine pathohistologische Untersuchung, mit der auch der höchste Grad der jeweiligen Kategorie hätte festgestellt werden können."
  },
  {
    "code" : "u",
    "display" : "u",
    "definition" : "Feststellung mit Ultraschall"
  },
  {
    "code" : "TX",
    "display" : "TX"
  },
  {
    "code" : "T0",
    "display" : "T0"
  },
  {
    "code" : "Ta",
    "display" : "Ta"
  },
  {
    "code" : "Tis",
    "display" : "Tis"
  },
  {
    "code" : "Tis(LAMN)",
    "display" : "Tis(LAMN)"
  },
  {
    "code" : "Tis(DCIS)",
    "display" : "Tis(DCIS)"
  },
  {
    "code" : "Tis(LCIS)",
    "display" : "Tis(LCIS)"
  },
  {
    "code" : "Tis(Paget)",
    "display" : "Tis(Paget)"
  },
  {
    "code" : "Tis(pu)",
    "display" : "Tis(pu)"
  },
  {
    "code" : "Tis(pd)",
    "display" : "Tis(pd)"
  },
  {
    "code" : "T1",
    "display" : "T1"
  },
  {
    "code" : "T1mi",
    "display" : "T1mi"
  },
  {
    "code" : "T1a",
    "display" : "T1a"
  },
  {
    "code" : "T1a1",
    "display" : "T1a1"
  },
  {
    "code" : "T1a2",
    "display" : "T1a2"
  },
  {
    "code" : "T1b",
    "display" : "T1b"
  },
  {
    "code" : "T1b1",
    "display" : "T1b1"
  },
  {
    "code" : "T1b2",
    "display" : "T1b2"
  },
  {
    "code" : "T1b3",
    "display" : "T1b3"
  },
  {
    "code" : "T1c",
    "display" : "T1c"
  },
  {
    "code" : "T1c1",
    "display" : "T1c1"
  },
  {
    "code" : "T1c2",
    "display" : "T1c2"
  },
  {
    "code" : "T1c3",
    "display" : "T1c3"
  },
  {
    "code" : "T1d",
    "display" : "T1d"
  },
  {
    "code" : "T2",
    "display" : "T2"
  },
  {
    "code" : "T2a",
    "display" : "T2a"
  },
  {
    "code" : "T2a1",
    "display" : "T2a1"
  },
  {
    "code" : "T2a2",
    "display" : "T2a2"
  },
  {
    "code" : "T2b",
    "display" : "T2b"
  },
  {
    "code" : "T2c",
    "display" : "T2c"
  },
  {
    "code" : "T2d",
    "display" : "T2d"
  },
  {
    "code" : "T3",
    "display" : "T3"
  },
  {
    "code" : "T3a",
    "display" : "T3a"
  },
  {
    "code" : "T3b",
    "display" : "T3b"
  },
  {
    "code" : "T3c",
    "display" : "T3c"
  },
  {
    "code" : "T3d",
    "display" : "T3d"
  },
  {
    "code" : "T3e",
    "display" : "T3e"
  },
  {
    "code" : "T4",
    "display" : "T4"
  },
  {
    "code" : "T4a",
    "display" : "T4a"
  },
  {
    "code" : "T4b",
    "display" : "T4b"
  },
  {
    "code" : "T4c",
    "display" : "T4c"
  },
  {
    "code" : "T4d",
    "display" : "T4d"
  },
  {
    "code" : "T4e",
    "display" : "T4e"
  },
  {
    "code" : "m",
    "display" : "(m)"
  },
  {
    "code" : "2",
    "display" : "(2)"
  },
  {
    "code" : "3",
    "display" : "(3)"
  },
  {
    "code" : "4",
    "display" : "(4)"
  },
  {
    "code" : "5",
    "display" : "(5)"
  },
  {
    "code" : "6",
    "display" : "(6)"
  },
  {
    "code" : "7",
    "display" : "(7)"
  },
  {
    "code" : "8",
    "display" : "(8)"
  },
  {
    "code" : "9",
    "display" : "(9)"
  },
  {
    "code" : "10",
    "display" : "(10)"
  },
  {
    "code" : "NX",
    "display" : "Nx"
  },
  {
    "code" : "N0",
    "display" : "N0"
  },
  {
    "code" : "N1",
    "display" : "N1"
  },
  {
    "code" : "N1mi",
    "display" : "N1(mi)"
  },
  {
    "code" : "N1a",
    "display" : "N1a"
  },
  {
    "code" : "N1b",
    "display" : "N1b"
  },
  {
    "code" : "N1c",
    "display" : "N1c"
  },
  {
    "code" : "N2",
    "display" : "N2"
  },
  {
    "code" : "N2a",
    "display" : "N2a"
  },
  {
    "code" : "N2b",
    "display" : "N2b"
  },
  {
    "code" : "N2c",
    "display" : "N2c"
  },
  {
    "code" : "N3",
    "display" : "N3"
  },
  {
    "code" : "N3a",
    "display" : "N3a"
  },
  {
    "code" : "N3b",
    "display" : "N3b"
  },
  {
    "code" : "N3c",
    "display" : "N3c"
  },
  {
    "code" : "M0",
    "display" : "M0"
  },
  {
    "code" : "M1",
    "display" : "M1"
  },
  {
    "code" : "M1a",
    "display" : "M1a"
  },
  {
    "code" : "M1b",
    "display" : "M1b"
  },
  {
    "code" : "M1c",
    "display" : "M1c"
  },
  {
    "code" : "M1c1",
    "display" : "M1c1"
  },
  {
    "code" : "M1c2",
    "display" : "M1c2"
  },
  {
    "code" : "M1d",
    "display" : "M1d"
  },
  {
    "code" : "MX",
    "display" : "MX"
  },
  {
    "code" : "i+",
    "display" : "(i+)"
  },
  {
    "code" : "i-",
    "display" : "(i-)"
  },
  {
    "code" : "mol+",
    "display" : "(mol+)"
  },
  {
    "code" : "mol-",
    "display" : "(mol-)"
  },
  {
    "code" : "sn",
    "display" : "(sn)"
  },
  {
    "code" : "L0",
    "display" : "L0",
    "definition" : "Keine Lymphgefäßinvasion"
  },
  {
    "code" : "L1",
    "display" : "L1",
    "definition" : "Lymphgefäßinvasion"
  },
  {
    "code" : "LX",
    "display" : "LX",
    "definition" : "Lymphgefäßinvasion kann nicht beurteilt werden"
  },
  {
    "code" : "V0",
    "display" : "V0",
    "definition" : "Keine Veneninvasion"
  },
  {
    "code" : "V1",
    "display" : "V1",
    "definition" : "Mikroskopische Veneninvasion"
  },
  {
    "code" : "V2",
    "display" : "V2",
    "definition" : "Makroskopische Veneninvasion"
  },
  {
    "code" : "VX",
    "display" : "VX",
    "definition" : "Veneninvasion kann nicht beurteilt werden"
  },
  {
    "code" : "Pn0",
    "display" : "Pn0",
    "definition" : "Keine perineurale Invasion"
  },
  {
    "code" : "Pn1",
    "display" : "Pn1",
    "definition" : "Perineurale Invasion"
  },
  {
    "code" : "PnX",
    "display" : "PnX",
    "definition" : "Perineurale Invasion kann nicht beurteilt werden"
  },
  {
    "code" : "S0",
    "display" : "S0",
    "definition" : "Serumtumormarker innerhalb der normalen Grenzen"
  },
  {
    "code" : "S1",
    "display" : "S1"
  },
  {
    "code" : "S2",
    "display" : "S2"
  },
  {
    "code" : "S3",
    "display" : "S3"
  },
  {
    "code" : "SX",
    "display" : "SX",
    "definition" : "Werte der Serumtumormarker nicht verfügbar oder entspre- chende Untersuchungen nicht vorgenommen"
  },
  {
    "code" : "okk",
    "display" : "Stadium X"
  },
  {
    "code" : "0",
    "display" : "Stadium 0"
  },
  {
    "code" : "0a",
    "display" : "Stadium 0a"
  },
  {
    "code" : "0is",
    "display" : "Stadium 0is"
  },
  {
    "code" : "I",
    "display" : "Stadium I"
  },
  {
    "code" : "IA",
    "display" : "Stadium IA"
  },
  {
    "code" : "IA1",
    "display" : "Stadium IA1"
  },
  {
    "code" : "IA2",
    "display" : "Stadium IA2"
  },
  {
    "code" : "IA3",
    "display" : "Stadium IA3"
  },
  {
    "code" : "IB",
    "display" : "Stadium IB"
  },
  {
    "code" : "IB1",
    "display" : "Stadium IB1"
  },
  {
    "code" : "IB2",
    "display" : "Stadium IB2"
  },
  {
    "code" : "IC",
    "display" : "Stadium IC"
  },
  {
    "code" : "IS",
    "display" : "Stadium IS"
  },
  {
    "code" : "II",
    "display" : "Stadium II"
  },
  {
    "code" : "IIA",
    "display" : "Stadium IIA"
  },
  {
    "code" : "IIA1",
    "display" : "Stadium IIA1"
  },
  {
    "code" : "IIA2",
    "display" : "Stadium IIA2"
  },
  {
    "code" : "IIB",
    "display" : "Stadium IIB"
  },
  {
    "code" : "IIC",
    "display" : "Stadium IIC"
  },
  {
    "code" : "III",
    "display" : "Stadium III"
  },
  {
    "code" : "IIIA",
    "display" : "Stadium IIIA"
  },
  {
    "code" : "IIIA1",
    "display" : "Stadium IIIA1"
  },
  {
    "code" : "IIIA2",
    "display" : "Stadium IIIA2"
  },
  {
    "code" : "IIIB",
    "display" : "Stadium IIIB"
  },
  {
    "code" : "IIIC",
    "display" : "Stadium IIIC"
  },
  {
    "code" : "IIIC1",
    "display" : "Stadium IIIC1"
  },
  {
    "code" : "IIIC2",
    "display" : "Stadium IIIC2"
  },
  {
    "code" : "IIID",
    "display" : "Stadium IIID"
  },
  {
    "code" : "IV",
    "display" : "Stadium IV"
  },
  {
    "code" : "IVA",
    "display" : "Stadium IVA"
  },
  {
    "code" : "IVA1",
    "display" : "Stadium IVA1"
  },
  {
    "code" : "IVA2",
    "display" : "Stadium IVA2"
  },
  {
    "code" : "IVB",
    "display" : "Stadium IVB"
  },
  {
    "code" : "IVC",
    "display" : "Stadium IVC"
  }]
}

```
