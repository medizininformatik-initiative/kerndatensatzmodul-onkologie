# mii-cm-mii-to-mvgenomseq-condition-diagnose-primaertumor - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **mii-cm-mii-to-mvgenomseq-condition-diagnose-primaertumor**

## ConceptMap: mii-cm-mii-to-mvgenomseq-condition-diagnose-primaertumor 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-mii-to-mvgenomseq-condition-diagnose-primaertumor | *Version*:2026.0.3 |
| Draft Stand: 2026-09-01 | *Maschinenlesbarer Name*: |



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "mii-cm-mii-to-mvgenomseq-condition-diagnose-primaertumor",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-mii-to-mvgenomseq-condition-diagnose-primaertumor",
  "version" : "2026.0.3",
  "status" : "draft",
  "date" : "2026-09-01T19:43:49+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "sourceCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onkologie/StructureDefinition/mii-pr-onko-diagnose-primaertumor",
  "targetUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onkologie/ConceptMap/mii-lm-mvgenomseq-onkologie"
}

```
