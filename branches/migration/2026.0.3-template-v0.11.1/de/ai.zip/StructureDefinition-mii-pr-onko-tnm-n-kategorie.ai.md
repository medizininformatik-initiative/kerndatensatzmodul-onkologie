# MII PR Onkologie TNM N-Kategorie - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII PR Onkologie TNM N-Kategorie**

## Ressourcenprofil: MII PR Onkologie TNM N-Kategorie 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie | *Version*:2026.0.3 |
| Active Stand: 2026-08-28 | *Maschinenlesbarer Name*:MII_PR_Onko_TNM_N_Kategorie |

 
TNM-Klassifikation: TNM N-Kategorie. Ausbreitung von regionären Lymphknotenmetastasen, erfolgt gemäß Tumorentität nach TNM. 

Dieses Profil beschreibt die N-Kategorie der TNM-Klassifikation. Die N-Kategorie kodiert für Fehlen bzw. Vorhandensein von regionären Lymphknotenmetastasen und wird entitätsspezifisch kodiert.

> **UICC-Präfixe y/r/a (modifierExtension):** Die Präfixe y (während/nach multimodaler Therapie), r (Rezidiv) und a (Autopsie) werden auf Kategorie-Ebene als **modifierExtension** abgebildet (`mii-ex-onko-tnm-y-praefix`, `…-r-praefix`, `…-a-praefix`), da sie die Interpretation des Kategorie-Wertes verändern — ypT2 ist prognostisch nicht mit pT2 vergleichbar. Verarbeitende Systeme müssen diese Extensions kennen. Das c/p/u-Präfix bleibt eine normale Extension auf `code`, da diese Information redundant im Observable-Code und im SNOMED-CT-Wert enthalten ist. Die Symbol-Observations (y-/r-/a-Symbol) auf Ebene der TNM-Klassifikation bleiben für das oBDS-Mapping (8.3–8.5) erhalten; gemischte Präfix-Situationen (z. B. ypT2 cN0) werden über die Kategorie-Präfixe abgebildet.

-------

**Beispiele**

[mii-exa-onko-tnm-n-kategorie-N0](Observation-mii-exa-onko-tnm-n-kategorie-N0.md)

[mii-exa-onko-tnm-n-kategorie-pN0i-sn](Observation-mii-exa-onko-tnm-n-kategorie-pN0i-sn.md)

**Usages:**

* Refer to this Profile: [MII PR Onkologie TNM-Klassifikation](StructureDefinition-mii-pr-onko-tnm-klassifikation.md)
* Examples for this Profile: [Observation/mii-exa-onko-ascending-colon-tnm-n](Observation-mii-exa-onko-ascending-colon-tnm-n.md), [Observation/mii-exa-onko-colorectal-tnm-n](Observation-mii-exa-onko-colorectal-tnm-n.md), [Observation/mii-exa-onko-cup-tnm-n-cNX](Observation-mii-exa-onko-cup-tnm-n-cNX.md), [Observation/mii-exa-onko-kim-klass1-cN1](Observation-mii-exa-onko-kim-klass1-cN1.md)... Show 11 more, [Observation/mii-exa-onko-kim-klass2-ycN1](Observation-mii-exa-onko-kim-klass2-ycN1.md), [Observation/mii-exa-onko-tnm-bundle-legacy-n-cN3](Observation-mii-exa-onko-tnm-bundle-legacy-n-cN3.md), [Observation/mii-exa-onko-tnm-bundle-n-kategorie-cN3](Observation-mii-exa-onko-tnm-bundle-n-kategorie-cN3.md), [Observation/mii-exa-onko-tnm-n-kategorie-N0](Observation-mii-exa-onko-tnm-n-kategorie-N0.md), [Observation/mii-exa-onko-tnm-n-kategorie-cN1](Observation-mii-exa-onko-tnm-n-kategorie-cN1.md), [Observation/mii-exa-onko-tnm-n-kategorie-pN0i-sn](Observation-mii-exa-onko-tnm-n-kategorie-pN0i-sn.md), [Observation/mii-exa-onko-tnm-n-kategorie-rcN1](Observation-mii-exa-onko-tnm-n-kategorie-rcN1.md), [Observation/mii-exa-onko-tnm-n-kategorie-ycN0](Observation-mii-exa-onko-tnm-n-kategorie-ycN0.md), [Observation/mii-exa-onko-tnm-n-kategorie-ypN0](Observation-mii-exa-onko-tnm-n-kategorie-ypN0.md), [Observation/mii-exa-onko-tnm-synth-meldung1-n-cN2](Observation-mii-exa-onko-tnm-synth-meldung1-n-cN2.md) and [Observation/mii-exa-onko-tnm-synth-meldung2-n-pN1](Observation-mii-exa-onko-tnm-synth-meldung2-n-pN1.md)
* CapabilityStatements using this Profile: [MII CPS Onkology CapabilityStatement](CapabilityStatement-mii-cps-onko-capabilitystatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/de.medizininformatikinitiative.kerndatensatz.onkologie|current/StructureDefinition/StructureDefinition-mii-pr-onko-tnm-n-kategorie.json)

### Formale Ansichten des Profilinhalts

 [Beschreibung von Profilen, Differentials, Snapshots und deren Repräsentationen](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Schlüsselelemente-Tabelle](#tabs-key) 
*  [Differential-Tabelle](#tabs-diff) 
*  [Snapshot-Tabelle](#tabs-snap) 
*  [Statistiken/Referenzen](#tabs-summ) 
*  [Alle](#tabs-all) 

#### Terminology Bindings

#### Constraints

Diese Struktur ist abgeleitet von [Observation](http://hl7.org/fhir/R4/observation.html) 

#### Terminology Bindings (Differential)

#### Constraints

#### Terminology Bindings

#### Constraints

Diese Struktur ist abgeleitet von [Observation](http://hl7.org/fhir/R4/observation.html) 

** Summary **

Mandatory: 1 element(8 nested mandatory elements)
 Must-Support: 25 elements

**Structures**

This structure refers to these other structures:

* [MII PR Onkologie Diagnose Primärtumor (https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor)](StructureDefinition-mii-pr-onko-diagnose-primaertumor.md)
* [MII PR Onkologie Anzahl der befallenen Lymphknoten (https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-befallene-lymphknoten)](StructureDefinition-mii-pr-onko-anzahl-befallene-lymphknoten.md)
* [MII PR Onkologie Anzahl der untersuchten Lymphknoten (https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-untersuchte-lymphknoten)](StructureDefinition-mii-pr-onko-anzahl-untersuchte-lymphknoten.md)
* [MII PR Onkologie Anzahl der befallenen Sentinel-Lymphknoten (https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-befallene-sentinel-lymphknoten)](StructureDefinition-mii-pr-onko-anzahl-befallene-sentinel-lymphknoten.md)
* [MII PR Onkologie Anzahl der untersuchten Sentinel-Lymphknoten (https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-untersuchte-sentinel-lymphknoten)](StructureDefinition-mii-pr-onko-anzahl-untersuchte-sentinel-lymphknoten.md)

**Extensions**

This structure refers to these extensions:

* [https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-y-praefix](StructureDefinition-mii-ex-onko-tnm-y-praefix.md) (**Modifier**) 
* [https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-r-praefix](StructureDefinition-mii-ex-onko-tnm-r-praefix.md) (**Modifier**) 
* [https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-a-praefix](StructureDefinition-mii-ex-onko-tnm-a-praefix.md) (**Modifier**) 
* [https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix](StructureDefinition-mii-ex-onko-tnm-cp-praefix.md)
* [https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-itc-suffix](StructureDefinition-mii-ex-onko-tnm-itc-suffix.md)
* [https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-sn-suffix](StructureDefinition-mii-ex-onko-tnm-sn-suffix.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.value[x].coding

 **Schlüsselelemente-Ansicht** 

#### Terminology Bindings

#### Constraints

 **Differential-Ansicht** 

Diese Struktur ist abgeleitet von [Observation](http://hl7.org/fhir/R4/observation.html) 

#### Terminology Bindings (Differential)

#### Constraints

 **Snapshot-AnsichtView** 

#### Terminology Bindings

#### Constraints

Diese Struktur ist abgeleitet von [Observation](http://hl7.org/fhir/R4/observation.html) 

** Summary **

Mandatory: 1 element(8 nested mandatory elements)
 Must-Support: 25 elements

**Structures**

This structure refers to these other structures:

* [MII PR Onkologie Diagnose Primärtumor (https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor)](StructureDefinition-mii-pr-onko-diagnose-primaertumor.md)
* [MII PR Onkologie Anzahl der befallenen Lymphknoten (https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-befallene-lymphknoten)](StructureDefinition-mii-pr-onko-anzahl-befallene-lymphknoten.md)
* [MII PR Onkologie Anzahl der untersuchten Lymphknoten (https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-untersuchte-lymphknoten)](StructureDefinition-mii-pr-onko-anzahl-untersuchte-lymphknoten.md)
* [MII PR Onkologie Anzahl der befallenen Sentinel-Lymphknoten (https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-befallene-sentinel-lymphknoten)](StructureDefinition-mii-pr-onko-anzahl-befallene-sentinel-lymphknoten.md)
* [MII PR Onkologie Anzahl der untersuchten Sentinel-Lymphknoten (https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-untersuchte-sentinel-lymphknoten)](StructureDefinition-mii-pr-onko-anzahl-untersuchte-sentinel-lymphknoten.md)

**Extensions**

This structure refers to these extensions:

* [https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-y-praefix](StructureDefinition-mii-ex-onko-tnm-y-praefix.md) (**Modifier**) 
* [https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-r-praefix](StructureDefinition-mii-ex-onko-tnm-r-praefix.md) (**Modifier**) 
* [https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-a-praefix](StructureDefinition-mii-ex-onko-tnm-a-praefix.md) (**Modifier**) 
* [https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix](StructureDefinition-mii-ex-onko-tnm-cp-praefix.md)
* [https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-itc-suffix](StructureDefinition-mii-ex-onko-tnm-itc-suffix.md)
* [https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-sn-suffix](StructureDefinition-mii-ex-onko-tnm-sn-suffix.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Observation.value[x].coding

 

Weitere Repräsentationen des Profils: [CSV](../StructureDefinition-mii-pr-onko-tnm-n-kategorie.csv), [Excel](../StructureDefinition-mii-pr-onko-tnm-n-kategorie.xlsx), [Schematron](../StructureDefinition-mii-pr-onko-tnm-n-kategorie.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "mii-pr-onko-tnm-n-kategorie",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie",
  "version" : "2026.0.3",
  "name" : "MII_PR_Onko_TNM_N_Kategorie",
  "title" : "MII PR Onkologie TNM N-Kategorie",
  "status" : "active",
  "date" : "2026-08-28T07:24:31+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "TNM-Klassifikation: TNM N-Kategorie. Ausbreitung von regionären Lymphknotenmetastasen, erfolgt gemäß Tumorentität nach TNM.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "oBDS",
    "name" : "Mapping FHIR zu oBDS"
  },
  {
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation",
      "constraint" : [{
        "key" : "tnm-sct-uicc-konsistenz",
        "severity" : "error",
        "human" : "Wenn ein SNOMED CT Code auf valueCodeableConcept vorhanden ist, muss dessen Display den c/p-Präfix und den UICC-Code enthalten (z.B. 'cT3' bei Präfix 'c' und Code 'T3').",
        "expression" : "valueCodeableConcept.coding.where(system = 'http://snomed.info/sct').empty() or valueCodeableConcept.coding.where(system = 'http://snomed.info/sct').display.contains(iif(code.extension('https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix').exists(), code.extension('https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix').value.coding.code.first(), '') + valueCodeableConcept.coding.where(system = 'https://www.uicc.org/resources/tnm').code.first() + ' ')",
        "source" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie"
      }]
    },
    {
      "id" : "Observation.meta.profile",
      "path" : "Observation.meta.profile",
      "mustSupport" : true
    },
    {
      "id" : "Observation.modifierExtension",
      "path" : "Observation.modifierExtension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Observation.modifierExtension:yPraefix",
      "path" : "Observation.modifierExtension",
      "sliceName" : "yPraefix",
      "short" : "TNM y-Präfix (während/nach multimodaler Therapie)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-y-praefix"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.modifierExtension:yPraefix.value[x].coding.code",
      "path" : "Observation.modifierExtension.value[x].coding.code",
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "8.3",
        "comment" : "TNM y-Symbol"
      }]
    },
    {
      "id" : "Observation.modifierExtension:rPraefix",
      "path" : "Observation.modifierExtension",
      "sliceName" : "rPraefix",
      "short" : "TNM r-Präfix (Rezidiv)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-r-praefix"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.modifierExtension:rPraefix.value[x].coding.code",
      "path" : "Observation.modifierExtension.value[x].coding.code",
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "8.4",
        "comment" : "TNM r-Symbol"
      }]
    },
    {
      "id" : "Observation.modifierExtension:aPraefix",
      "path" : "Observation.modifierExtension",
      "sliceName" : "aPraefix",
      "short" : "TNM a-Präfix (Autopsie)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-a-praefix"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.modifierExtension:aPraefix.value[x].coding.code",
      "path" : "Observation.modifierExtension.value[x].coding.code",
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "8.5",
        "comment" : "TNM a-Symbol"
      }]
    },
    {
      "id" : "Observation.status",
      "path" : "Observation.status",
      "mustSupport" : true
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "mustSupport" : true,
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-tnm-n-kategorie"
      }
    },
    {
      "id" : "Observation.code.extension:cpPraefix",
      "path" : "Observation.code.extension",
      "sliceName" : "cpPraefix",
      "short" : "TNM c/p-Präfix N",
      "definition" : "Gibt an, ob die Klassifikation klinisch oder pathologisch erfolgte.",
      "comment" : "c oder (leer) = Kategorie wurde durch klinische Angaben festgestellt, bzw. erfüllt die Kriterien für p nicht. p = Feststellung der Kategorie erfolgte durch eine pathohistologische Untersuchung, mit der auch der höchste Grad der jeweiligen Kategorie hätte festgestellt werden können. u (Feststellung mit Ultraschall) ist unter c zu übermitteln.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.code.extension:cpPraefix.value[x].coding.code",
      "path" : "Observation.code.extension.value[x].coding.code",
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "8.7",
        "comment" : "TNM c/p-Präfix N"
      }]
    },
    {
      "id" : "Observation.code.coding.system",
      "path" : "Observation.code.coding.system",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.code.coding.code",
      "path" : "Observation.code.coding.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.subject",
      "path" : "Observation.subject",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.focus",
      "path" : "Observation.focus",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.encounter",
      "path" : "Observation.encounter",
      "mustSupport" : true
    },
    {
      "id" : "Observation.effective[x]",
      "path" : "Observation.effective[x]",
      "short" : "TNM-Datum",
      "_short" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de-DE"
          },
          {
            "url" : "content",
            "valueString" : "TNM-Datum"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "definition" : "Datum der TNM-Klassifikation nach 8.1 oBDS 2021",
      "_definition" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de-DE"
          },
          {
            "url" : "content",
            "valueString" : "Datum der TNM-Klassifikation nach 8.1 oBDS 2021"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : [{
        "code" : "dateTime"
      }],
      "constraint" : [{
        "key" : "tnm-datum",
        "severity" : "error",
        "human" : "TNM Datum: Ein exaktes (taggenaues) Datum ist anzugeben.",
        "expression" : "$this.toString().length() >= 8",
        "source" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie"
      }],
      "mustSupport" : true,
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "8.1",
        "comment" : "TNM Datum"
      }]
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x].extension:itcSuffix",
      "path" : "Observation.value[x].extension",
      "sliceName" : "itcSuffix",
      "short" : "isolierte Tumorzellen (ITC) Suffix",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-itc-suffix"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x].extension:snSuffix",
      "path" : "Observation.value[x].extension",
      "sliceName" : "snSuffix",
      "short" : "Schildwächterlymphknoten (Sentinel Lymph Node) Suffix",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-sn-suffix"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x].coding",
      "path" : "Observation.value[x].coding",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "short" : "TNM N-Kategorie",
      "_short" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de-DE"
          },
          {
            "url" : "content",
            "valueString" : "TNM N-Kategorie"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "definition" : "Ausbreitung von regionären Lymphknotenmetastasen, erfolgt gemäß Tumorentität nach TNM.",
      "_definition" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de-DE"
          },
          {
            "url" : "content",
            "valueString" : "TNM Lymphknotenbefall nach 8.11 oBDS 2021"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "comment" : "Entitätsspezifisch, siehe auch allgemeine Bemerkungen zu TNM.",
      "min" : 1
    },
    {
      "id" : "Observation.value[x].coding.code",
      "path" : "Observation.value[x].coding.code",
      "mapping" : [{
        "identity" : "oBDS",
        "map" : "8.11",
        "comment" : "TNM N-Kategorie"
      }]
    },
    {
      "id" : "Observation.value[x].coding:uicc",
      "path" : "Observation.value[x].coding",
      "sliceName" : "uicc",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-tnm-n-kategorie-werte"
      }
    },
    {
      "id" : "Observation.value[x].coding:uicc.system",
      "path" : "Observation.value[x].coding.system",
      "min" : 1,
      "patternUri" : "https://www.uicc.org/resources/tnm",
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x].coding:uicc.code",
      "path" : "Observation.value[x].coding.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x].coding:snomed-ct",
      "path" : "Observation.value[x].coding",
      "sliceName" : "snomed-ct",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-tnm-n-kategorie-werte-sct"
      }
    },
    {
      "id" : "Observation.value[x].coding:snomed-ct.system",
      "path" : "Observation.value[x].coding.system",
      "min" : 1,
      "patternUri" : "http://snomed.info/sct",
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x].coding:snomed-ct.code",
      "path" : "Observation.value[x].coding.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.method",
      "path" : "Observation.method",
      "mustSupport" : true
    },
    {
      "id" : "Observation.method.coding",
      "path" : "Observation.method.coding",
      "short" : "TNM Version",
      "_short" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de-DE"
          },
          {
            "url" : "content",
            "valueString" : "TNM Version"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "definition" : "Gibt an, nach welcher Version des TNM klassifiziert wurde.",
      "_definition" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de-DE"
          },
          {
            "url" : "content",
            "valueString" : "Version nach 8.2 oBDS 2021"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-tnm-version"
      }
    },
    {
      "id" : "Observation.hasMember",
      "path" : "Observation.hasMember",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-befallene-lymphknoten",
        "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-untersuchte-lymphknoten",
        "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-befallene-sentinel-lymphknoten",
        "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-untersuchte-sentinel-lymphknoten"]
      }],
      "mustSupport" : true
    }]
  }
}

```
