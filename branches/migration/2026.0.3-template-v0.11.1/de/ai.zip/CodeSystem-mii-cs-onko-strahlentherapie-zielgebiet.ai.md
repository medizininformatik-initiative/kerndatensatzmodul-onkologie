# MII CS Onkologie Strahlentherapie Zielgebiet - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII CS Onkologie Strahlentherapie Zielgebiet**

## CodeSystem: MII CS Onkologie Strahlentherapie Zielgebiet 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-zielgebiet | *Version*:2026.0.3 |
| Active Stand: 2026-08-31 | *Maschinenlesbarer Name*:MII_CS_Onko_Strahlentherapie_Zielgebiet |

 
oBDS-spezifisches Codesystem für Klassifikation von Zielgebiet von Strahlentherapie 

Dieses CodeSystem wird in der Definition der folgenden ValueSets referenziert:

* [MII VS Onkologie Strahlentherapie Zielgebiet](ValueSet-mii-vs-onko-strahlentherapie-zielgebiet.md)

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "mii-cs-onko-strahlentherapie-zielgebiet",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablecodesystem",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablecodesystem"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionPolicy",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes",
        "code" : "package",
        "display" : "Package"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-approvalDate",
    "valueDate" : "2026-01-03"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-topic",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
        "code" : "C3262"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-author",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "email",
        "value" : "thomas.debertshaeuser@charite.de"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-editor",
    "valueContactDetail" : {
      "name" : "Taskforce Core Data Set"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-zielgebiet",
  "version" : "2026.0.3",
  "name" : "MII_CS_Onko_Strahlentherapie_Zielgebiet",
  "title" : "MII CS Onkologie Strahlentherapie Zielgebiet",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-31T15:22:09+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "oBDS-spezifisches Codesystem für Klassifikation von Zielgebiet von Strahlentherapie",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "caseSensitive" : true,
  "valueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-strahlentherapie-zielgebiet",
  "content" : "complete",
  "count" : 98,
  "concept" : [{
    "code" : "1.1",
    "display" : "Ganzhirn (Neurokranium, inklusive Meningen)"
  },
  {
    "code" : "1.2",
    "display" : "Teilhirn (frontal/parietal/occipital/temporal/Kleinhirn)"
  },
  {
    "code" : "1.3",
    "display" : "Neuroachse/Rückenmark"
  },
  {
    "code" : "1.4",
    "display" : "Hypophyse"
  },
  {
    "code" : "1.5",
    "display" : "Hirn sonstiges"
  },
  {
    "code" : "2.1",
    "display" : "Auge (r, l)"
  },
  {
    "code" : "2.2",
    "display" : "Nase/Nasennebenhöhle"
  },
  {
    "code" : "2.3",
    "display" : "Mundhöhle inklusive Mundhöhlenvorhof"
  },
  {
    "code" : "2.4",
    "display" : "Ohr (r, l)"
  },
  {
    "code" : "2.5",
    "display" : "Speicheldrüse (r, l)"
  },
  {
    "code" : "2.6",
    "display" : "Pharynx"
  },
  {
    "code" : "2.7",
    "display" : "Nasopharynx"
  },
  {
    "code" : "2.8",
    "display" : "Oropharynx"
  },
  {
    "code" : "2.9",
    "display" : "Hypopharynx"
  },
  {
    "code" : "2.10",
    "display" : "Larynx"
  },
  {
    "code" : "2.11",
    "display" : "Schilddrüse"
  },
  {
    "code" : "2.12",
    "display" : "Kopf-Hals sonstige"
  },
  {
    "code" : "3.1",
    "display" : "Mamma als Ganzbrust (r, l)"
  },
  {
    "code" : "3.2",
    "display" : "Mamma als Teilbrust (r, l)"
  },
  {
    "code" : "3.3",
    "display" : "Thoraxwand, gegebenenfalls r, l"
  },
  {
    "code" : "3.4",
    "display" : "Lunge (r, l)"
  },
  {
    "code" : "3.5",
    "display" : "Ösophagus"
  },
  {
    "code" : "3.6",
    "display" : "Mediastinum (mediastinaler Lymphabfluss ist in Nummer 9 zu kodieren)"
  },
  {
    "code" : "3.7",
    "display" : "Thymus"
  },
  {
    "code" : "3.8",
    "display" : "Thorax sonstige"
  },
  {
    "code" : "4.1",
    "display" : "Magen"
  },
  {
    "code" : "4.2",
    "display" : "Pankreas"
  },
  {
    "code" : "4.3",
    "display" : "Leber, auch bei Teilbestrahlung"
  },
  {
    "code" : "4.4",
    "display" : "Milz"
  },
  {
    "code" : "4.5",
    "display" : "Niere (r, l)"
  },
  {
    "code" : "4.6",
    "display" : "Nebenniere (r, l)"
  },
  {
    "code" : "4.7",
    "display" : "Retroperitoneum (z. B. Sarkome)"
  },
  {
    "code" : "4.8",
    "display" : "Ureter (r, l)"
  },
  {
    "code" : "4.9",
    "display" : "Bauchwand (z. B. Sarkome)"
  },
  {
    "code" : "4.10",
    "display" : "Oberbauch"
  },
  {
    "code" : "4.11",
    "display" : "Gallengänge"
  },
  {
    "code" : "4.12",
    "display" : "Gallenblase"
  },
  {
    "code" : "4.13",
    "display" : "Abdomen sonstige"
  },
  {
    "code" : "5.1",
    "display" : "Rektum"
  },
  {
    "code" : "5.2",
    "display" : "Analbereich"
  },
  {
    "code" : "5.3",
    "display" : "Harnblase"
  },
  {
    "code" : "5.4",
    "display" : "Prostata"
  },
  {
    "code" : "5.5",
    "display" : "Hoden (r, l)"
  },
  {
    "code" : "5.6",
    "display" : "Penis"
  },
  {
    "code" : "5.7",
    "display" : "Uterus"
  },
  {
    "code" : "5.8",
    "display" : "Zervix"
  },
  {
    "code" : "5.9",
    "display" : "Vulva"
  },
  {
    "code" : "5.10",
    "display" : "Vagina"
  },
  {
    "code" : "5.11",
    "display" : "Beckenwand"
  },
  {
    "code" : "5.12",
    "display" : "Becken sonstige"
  },
  {
    "code" : "6.1",
    "display" : "Schädel"
  },
  {
    "code" : "6.2",
    "display" : "Schädelbasis"
  },
  {
    "code" : "6.3",
    "display" : "Orbita (r, l)"
  },
  {
    "code" : "6.4",
    "display" : "Halswirbelsäule"
  },
  {
    "code" : "6.5",
    "display" : "Brustwirbelsäule"
  },
  {
    "code" : "6.6",
    "display" : "Lendenwirbelsäule"
  },
  {
    "code" : "6.7",
    "display" : "Sacrum /Coccygeum"
  },
  {
    "code" : "6.8",
    "display" : "Rippen (r, l)"
  },
  {
    "code" : "6.9",
    "display" : "Sternum"
  },
  {
    "code" : "6.10",
    "display" : "Schulter (r, l)"
  },
  {
    "code" : "6.11",
    "display" : "Oberarm (r, l)"
  },
  {
    "code" : "6.12",
    "display" : "Unterarm (r, l)"
  },
  {
    "code" : "6.13",
    "display" : "Hand (r, l)"
  },
  {
    "code" : "6.14",
    "display" : "Becken (r, l)"
  },
  {
    "code" : "6.15",
    "display" : "Hüfte (r, l)"
  },
  {
    "code" : "6.16",
    "display" : "Oberschenkel (r, l)"
  },
  {
    "code" : "6.17",
    "display" : "Unterschenkel (r, l)"
  },
  {
    "code" : "6.18",
    "display" : "Fuß (r, l)"
  },
  {
    "code" : "6.19",
    "display" : "Knochen sonstige"
  },
  {
    "code" : "7.1",
    "display" : "Kopf, Gesicht, Hals"
  },
  {
    "code" : "7.2",
    "display" : "obere Extremität ink* #lusive Schulter (r, l)"
  },
  {
    "code" : "7.3",
    "display" : "untere Extremität und Hüfte (r, l)"
  },
  {
    "code" : "7.4",
    "display" : "Thorax"
  },
  {
    "code" : "7.5",
    "display" : "Abdomen"
  },
  {
    "code" : "7.6",
    "display" : "Becken"
  },
  {
    "code" : "7.7",
    "display" : "Stammes o. n. A."
  },
  {
    "code" : "7.8",
    "display" : "mehrere Bereiche überlappend"
  },
  {
    "code" : "7.9",
    "display" : "sonstige Weichteile o. n. A."
  },
  {
    "code" : "8.1",
    "display" : "Ganzhaut"
  },
  {
    "code" : "8.2",
    "display" : "Teilbereiche"
  },
  {
    "code" : "9.1",
    "display" : "Cervikale Lymphknoten (r, l)"
  },
  {
    "code" : "9.2",
    "display" : "Supra-/infraclavikuläre Lymphknoten (r, l)"
  },
  {
    "code" : "9.3",
    "display" : "Axilläre Lymphknoten (r, l)"
  },
  {
    "code" : "9.4",
    "display" : "Retrosternale/sternale/Mammaria interna Lymphknoten"
  },
  {
    "code" : "9.5",
    "display" : "Mediastinale Lymphknoten"
  },
  {
    "code" : "9.6",
    "display" : "Hiläre Lymphknoten"
  },
  {
    "code" : "9.7",
    "display" : "Intraabdominale Lymphknoten (z. B. subphrenisch, perigastrisch, peripankreatisch, Leber-, Milzhilus)"
  },
  {
    "code" : "9.8",
    "display" : "Paraaortale/paracavale Lymphknoten"
  },
  {
    "code" : "9.9",
    "display" : "Retroperitoneale Lymphknoten"
  },
  {
    "code" : "9.10",
    "display" : "Beckenlymphabfluss (r, l) (Iliakal commun, extern, intern, obturatorisch, präsakral)"
  },
  {
    "code" : "9.11",
    "display" : "Inguinale Lymphknoten (r, l)"
  },
  {
    "code" : "9.12",
    "display" : "Involved Node"
  },
  {
    "code" : "9.13",
    "display" : "Involved Site"
  },
  {
    "code" : "9.14",
    "display" : "Involved Field"
  },
  {
    "code" : "9.15",
    "display" : "Sonstige Lymphknoten"
  },
  {
    "code" : "10.1",
    "display" : "Ganzkörperbestrahlung bei allogener Stammzelltransplantation"
  },
  {
    "code" : "10.2",
    "display" : "operative Zugangswege"
  },
  {
    "code" : "10.3",
    "display" : "Sonstige, nicht genannte Zielgebiete"
  }]
}

```
