# MII VS Onkologie Allgemeiner Leistungszustand ECOG LOINC - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII VS Onkologie Allgemeiner Leistungszustand ECOG LOINC**

## ValueSet: MII VS Onkologie Allgemeiner Leistungszustand ECOG LOINC 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-allgemeiner-leistungszustand-ecog-loinc | *Version*:2026.0.3 |
| Active as of 2026-08-28 | *Computable Name*:MII_VS_Onko_Allgemeiner_Leistungszustand_ECOG_LOINC |

 
LOINC-Answer-Codes für den ECOG Performance Status. Enumerierte Fassung der LOINC-Answer-List LL529-9. 

 **References** 

* [MII PR Onkologie Allgemeiner Leistungszustand ECOG](StructureDefinition-mii-pr-onko-allgemeiner-leistungszustand-ecog.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-onko-allgemeiner-leistungszustand-ecog-loinc",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-allgemeiner-leistungszustand-ecog-loinc",
  "version" : "2026.0.3",
  "name" : "MII_VS_Onko_Allgemeiner_Leistungszustand_ECOG_LOINC",
  "title" : "MII VS Onkologie Allgemeiner Leistungszustand ECOG LOINC",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-28T06:12:02+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "LOINC-Answer-Codes für den ECOG Performance Status. Enumerierte Fassung der LOINC-Answer-List LL529-9.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "LA9622-7",
        "display" : "Fully active, able to carry on all pre-disease performance without restriction"
      },
      {
        "code" : "LA9623-5",
        "display" : "Restricted in physically strenuous activity but ambulatory and able to carry out work of a light or sedentary nature, e.g., light house work, office work"
      },
      {
        "code" : "LA9624-3",
        "display" : "Ambulatory and capable of all selfcare but unable to carry out any work activities. Up and about more than 50% of waking hours"
      },
      {
        "code" : "LA9625-0",
        "display" : "Capable of only limited selfcare, confined to bed or chair more than 50% of waking hours"
      },
      {
        "code" : "LA9626-8",
        "display" : "Completely disabled. Cannot carry on any selfcare. Totally confined to bed or chair"
      },
      {
        "code" : "LA9627-6",
        "display" : "Dead"
      }]
    }]
  }
}

```
