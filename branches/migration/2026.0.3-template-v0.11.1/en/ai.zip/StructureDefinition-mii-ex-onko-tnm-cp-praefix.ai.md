# MII EX Onkologie TNM c/p Präfix - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII EX Onkologie TNM c/p Präfix**

## Extension: MII EX Onkologie TNM c/p Präfix 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix | *Version*:2026.0.3 |
| Active as of 2026-08-27 | *Computable Name*:MII_EX_Onko_TNM_cp_Praefix |

Die Extension verleiht einer TNM T-, N- oder M-Kategorie ein c, p oder u Präfix zur Angabe der Klassifikationsmethode: 'c' = klinische Klassifikation (basierend auf klinischen Angaben), 'p' = pathologische Klassifikation (basierend auf pathohistologischer Untersuchung), 'u' = Ultraschall-basierte Klassifikation.

**Context of Use**

The c/p/u prefix is used in the TNM classification to indicate the method of classification:

* **c** (clinical): clinical classification, based on clinical findings before the start of therapy
* **p** (pathological): pathological classification, based on histopathological examination after surgical removal
* **u** (ultrasound): classification by ultrasound (e.g. endoscopic ultrasound)

In the present profiling, the profiles for the T, N and M categories all use the same extension.

> The profiles concerned are described in the artefact view: [MII PR Onkologie TNM T-Kategorie](StructureDefinition-mii-pr-onko-tnm-t-kategorie.md), [MII PR Onkologie TNM N-Kategorie](StructureDefinition-mii-pr-onko-tnm-n-kategorie.md) and [MII PR Onkologie TNM M-Kategorie](StructureDefinition-mii-pr-onko-tnm-m-kategorie.md).

**Usage info**

**Usages:**

* Use this Extension: [MII PR Onkologie TNM M-Kategorie](StructureDefinition-mii-pr-onko-tnm-m-kategorie.md), [MII PR Onkologie TNM N-Kategorie](StructureDefinition-mii-pr-onko-tnm-n-kategorie.md) and [MII PR Onkologie TNM T-Kategorie](StructureDefinition-mii-pr-onko-tnm-t-kategorie.md)
* Examples for this Extension: [Bundle/mii-exa-onko-cup-bundle](Bundle-mii-exa-onko-cup-bundle.md), [Bundle/mii-exa-onko-folfox-workflow-bundle](Bundle-mii-exa-onko-folfox-workflow-bundle.md), [Bundle/mii-exa-onko-kim-musterperson-synthesized](Bundle-mii-exa-onko-kim-musterperson-synthesized.md), [Bundle/mii-exa-onko-tnm-bundle-legacy](Bundle-mii-exa-onko-tnm-bundle-legacy.md)... Show 46 more, [Bundle/mii-exa-onko-tnm-bundle-synthesized](Bundle-mii-exa-onko-tnm-bundle-synthesized.md), [Bundle/mii-exa-onko-tnm-bundle](Bundle-mii-exa-onko-tnm-bundle.md), [Observation/TNM-M-Observation-2](Observation-TNM-M-Observation-2.md), [Observation/TNM-T-Observation-2](Observation-TNM-T-Observation-2.md), [Observation/mii-exa-onko-ascending-colon-tnm-m](Observation-mii-exa-onko-ascending-colon-tnm-m.md), [Observation/mii-exa-onko-ascending-colon-tnm-n](Observation-mii-exa-onko-ascending-colon-tnm-n.md), [Observation/mii-exa-onko-ascending-colon-tnm-t](Observation-mii-exa-onko-ascending-colon-tnm-t.md), [Observation/mii-exa-onko-colorectal-tnm-m](Observation-mii-exa-onko-colorectal-tnm-m.md), [Observation/mii-exa-onko-colorectal-tnm-n](Observation-mii-exa-onko-colorectal-tnm-n.md), [Observation/mii-exa-onko-colorectal-tnm-t](Observation-mii-exa-onko-colorectal-tnm-t.md), [Observation/mii-exa-onko-cup-tnm-m-cM1](Observation-mii-exa-onko-cup-tnm-m-cM1.md), [Observation/mii-exa-onko-cup-tnm-n-cNX](Observation-mii-exa-onko-cup-tnm-n-cNX.md), [Observation/mii-exa-onko-cup-tnm-t-cTX](Observation-mii-exa-onko-cup-tnm-t-cTX.md), [Observation/mii-exa-onko-kim-klass1-cM1](Observation-mii-exa-onko-kim-klass1-cM1.md), [Observation/mii-exa-onko-kim-klass1-cN1](Observation-mii-exa-onko-kim-klass1-cN1.md), [Observation/mii-exa-onko-kim-klass1-cT3c](Observation-mii-exa-onko-kim-klass1-cT3c.md), [Observation/mii-exa-onko-kim-klass2-ycM1b](Observation-mii-exa-onko-kim-klass2-ycM1b.md), [Observation/mii-exa-onko-kim-klass2-ycN1](Observation-mii-exa-onko-kim-klass2-ycN1.md), [Observation/mii-exa-onko-kim-klass2-ycT3c](Observation-mii-exa-onko-kim-klass2-ycT3c.md), [Observation/mii-exa-onko-kim-klass3-ypM1b](Observation-mii-exa-onko-kim-klass3-ypM1b.md), [Observation/mii-exa-onko-kim-klass3-ypT3c](Observation-mii-exa-onko-kim-klass3-ypT3c.md), [Observation/mii-exa-onko-tnm-bundle-legacy-m-cM0](Observation-mii-exa-onko-tnm-bundle-legacy-m-cM0.md), [Observation/mii-exa-onko-tnm-bundle-legacy-n-cN3](Observation-mii-exa-onko-tnm-bundle-legacy-n-cN3.md), [Observation/mii-exa-onko-tnm-bundle-legacy-t-cT2](Observation-mii-exa-onko-tnm-bundle-legacy-t-cT2.md), [Observation/mii-exa-onko-tnm-bundle-m-kategorie-cM0](Observation-mii-exa-onko-tnm-bundle-m-kategorie-cM0.md), [Observation/mii-exa-onko-tnm-bundle-n-kategorie-cN3](Observation-mii-exa-onko-tnm-bundle-n-kategorie-cN3.md), [Observation/mii-exa-onko-tnm-bundle-t-kategorie-cT2](Observation-mii-exa-onko-tnm-bundle-t-kategorie-cT2.md), [Observation/mii-exa-onko-tnm-m-kategorie-M0](Observation-mii-exa-onko-tnm-m-kategorie-M0.md), [Observation/mii-exa-onko-tnm-m-kategorie-cM0](Observation-mii-exa-onko-tnm-m-kategorie-cM0.md), [Observation/mii-exa-onko-tnm-m-kategorie-cM1](Observation-mii-exa-onko-tnm-m-kategorie-cM1.md), [Observation/mii-exa-onko-tnm-m-kategorie-rcM1](Observation-mii-exa-onko-tnm-m-kategorie-rcM1.md), [Observation/mii-exa-onko-tnm-n-kategorie-N0](Observation-mii-exa-onko-tnm-n-kategorie-N0.md), [Observation/mii-exa-onko-tnm-n-kategorie-cN1](Observation-mii-exa-onko-tnm-n-kategorie-cN1.md), [Observation/mii-exa-onko-tnm-n-kategorie-pN0i-sn](Observation-mii-exa-onko-tnm-n-kategorie-pN0i-sn.md), [Observation/mii-exa-onko-tnm-n-kategorie-rcN1](Observation-mii-exa-onko-tnm-n-kategorie-rcN1.md), [Observation/mii-exa-onko-tnm-n-kategorie-ycN0](Observation-mii-exa-onko-tnm-n-kategorie-ycN0.md), [Observation/mii-exa-onko-tnm-n-kategorie-ypN0](Observation-mii-exa-onko-tnm-n-kategorie-ypN0.md), [Observation/mii-exa-onko-tnm-synth-meldung1-m-cM0](Observation-mii-exa-onko-tnm-synth-meldung1-m-cM0.md), [Observation/mii-exa-onko-tnm-synth-meldung1-n-cN2](Observation-mii-exa-onko-tnm-synth-meldung1-n-cN2.md), [Observation/mii-exa-onko-tnm-synth-meldung1-t-cT3](Observation-mii-exa-onko-tnm-synth-meldung1-t-cT3.md), [Observation/mii-exa-onko-tnm-synth-meldung2-n-pN1](Observation-mii-exa-onko-tnm-synth-meldung2-n-pN1.md), [Observation/mii-exa-onko-tnm-synth-meldung2-t-pT2](Observation-mii-exa-onko-tnm-synth-meldung2-t-pT2.md), [Observation/mii-exa-onko-tnm-t-kategorie-Tis](Observation-mii-exa-onko-tnm-t-kategorie-Tis.md), [Observation/mii-exa-onko-tnm-t-kategorie-cT3](Observation-mii-exa-onko-tnm-t-kategorie-cT3.md), [Observation/mii-exa-onko-tnm-t-kategorie-cT4](Observation-mii-exa-onko-tnm-t-kategorie-cT4.md) and [Observation/mii-exa-onko-tnm-t-kategorie-rcT2](Observation-mii-exa-onko-tnm-t-kategorie-rcT2.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/de.medizininformatikinitiative.kerndatensatz.onkologie|current/StructureDefinition/StructureDefinition-mii-ex-onko-tnm-cp-praefix.json)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and their representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-mii-ex-onko-tnm-cp-praefix.csv), [Excel](../StructureDefinition-mii-ex-onko-tnm-cp-praefix.xlsx), [Schematron](../StructureDefinition-mii-ex-onko-tnm-cp-praefix.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "mii-ex-onko-tnm-cp-praefix",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix",
  "version" : "2026.0.3",
  "name" : "MII_EX_Onko_TNM_cp_Praefix",
  "title" : "MII EX Onkologie TNM c/p Präfix",
  "status" : "active",
  "date" : "2026-08-27T10:41:09+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Die Extension verleiht einer TNM T-, N- oder M-Kategorie ein c, p oder u Präfix zur Angabe der Klassifikationsmethode: 'c' = klinische Klassifikation (basierend auf klinischen Angaben), 'p' = pathologische Klassifikation (basierend auf pathohistologischer Untersuchung), 'u' = Ultraschall-basierte Klassifikation.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "CodeableConcept"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "MII EX Onkologie TNM c/p Präfix",
      "definition" : "Die Extension verleiht einer TNM T-, N- oder M-Kategorie ein c, p oder u Präfix zur Angabe der Klassifikationsmethode: 'c' = klinische Klassifikation (basierend auf klinischen Angaben), 'p' = pathologische Klassifikation (basierend auf pathohistologischer Untersuchung), 'u' = Ultraschall-basierte Klassifikation."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-ex-onko-tnm-cp-praefix"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-tnm-cp-praefix"
      }
    },
    {
      "id" : "Extension.value[x].coding.system",
      "path" : "Extension.value[x].coding.system",
      "mustSupport" : true
    },
    {
      "id" : "Extension.value[x].coding.code",
      "path" : "Extension.value[x].coding.code",
      "mustSupport" : true
    }]
  }
}

```
