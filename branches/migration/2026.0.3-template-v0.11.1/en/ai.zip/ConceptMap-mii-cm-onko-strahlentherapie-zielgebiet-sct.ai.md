# MII CM Onko Strahlentherapie Zielgebiet SNOMED Mapping - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII CM Onko Strahlentherapie Zielgebiet SNOMED Mapping**

## ConceptMap: MII CM Onko Strahlentherapie Zielgebiet SNOMED Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-strahlentherapie-zielgebiet-sct | *Version*:2026.0.3 |
| Active as of 2024-04-11 | *Computable Name*:MII CM Onko Strahlentherapie Zielstellung SCT Mapping |
| **Copyright/Legal**: This material includes SNOMED Clinical Terms® (SNOMED CT®) which is used by permission of SNOMED International. All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. SNOMED and SNOMED CT are registered trademarks of SNOMED International. Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license. | |

 
Mapping Strahlentherapie Zielgebiet Codes zu SNOMED-CT 

The anatomical structures can be represented well via SNOMED. For some data fields the side is to be specified.

For many data points, fully defined SNOMED concepts for left and right already exist. For the sake of simplicity, mainly the non-side-specific concepts are listed here.

> The complete mapping table is generated from the ConceptMap below this introduction.



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "mii-cm-onko-strahlentherapie-zielgebiet-sct",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-strahlentherapie-zielgebiet-sct",
  "version" : "2026.0.3",
  "name" : "MII CM Onko Strahlentherapie Zielstellung SCT Mapping",
  "title" : "MII CM Onko Strahlentherapie Zielgebiet SNOMED Mapping",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-04-11",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Mapping Strahlentherapie Zielgebiet Codes zu SNOMED-CT",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "purpose" : "Technical mapping to transform oBDS-Data into SNOMED",
  "copyright" : "This material includes SNOMED Clinical Terms® (SNOMED CT®) which is used by permission of SNOMED International. All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. SNOMED and SNOMED CT are registered trademarks of SNOMED International. Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license.",
  "sourceUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/",
  "targetUri" : "http://snomed.info/sct/900000000000207008/version/20240401",
  "group" : [{
    "source" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-zielgebiet",
    "target" : "http://snomed.info/sct/900000000000207008/version/20240401",
    "element" : [{
      "code" : "1.1",
      "display" : "Ganzhirn (Neurokranium, inklusive Meningen)",
      "target" : [{
        "code" : "258335003",
        "display" : "Entire brain (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "1.2",
      "display" : "Teilhirn (frontal/parietal/occipital/temporal/Kleinhirn)",
      "target" : [{
        "code" : "119235005",
        "display" : "Brain part (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "1.3",
      "display" : "Neuroachse/Rückenmark",
      "target" : [{
        "code" : "389079005",
        "display" : "Brain and spinal cord structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "1.4",
      "display" : "Hypophyse",
      "target" : [{
        "code" : "56329008",
        "display" : "Pituitary structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "1.5",
      "display" : "Hirn sonstiges",
      "target" : [{
        "code" : "74964007",
        "display" : "Other (qualifier value)",
        "equivalence" : "equivalent",
        "comment" : "ggfs. über Postkoordination besser darstellbar"
      }]
    },
    {
      "code" : "2.1",
      "display" : "Auge (r, l)",
      "target" : [{
        "code" : "81745001",
        "display" : "Structure of eye proper (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "2.2",
      "display" : "Nase/Nasennebenhöhle",
      "target" : [{
        "code" : "1286894002",
        "display" : "Structure of nasal cavity and/or nasal sinus (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "2.3",
      "display" : "Mundhöhle inklusive Mundhöhlenvorhof",
      "target" : [{
        "code" : "74262004",
        "display" : "Oral cavity structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "2.4",
      "display" : "Ohr (r, l)",
      "target" : [{
        "code" : "117590005",
        "display" : "Ear structure (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "2.5",
      "display" : "Speicheldrüse (r, l)",
      "target" : [{
        "code" : "385294005",
        "display" : "Salivary gland structure (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "2.6",
      "display" : "Pharynx",
      "target" : [{
        "code" : "54066008",
        "display" : "Pharyngeal structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "2.7",
      "display" : "Nasopharynx",
      "target" : [{
        "code" : "71836000",
        "display" : "Nasopharyngeal structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "2.8",
      "display" : "Oropharynx",
      "target" : [{
        "code" : "31389004",
        "display" : "Oropharyngeal structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "2.9",
      "display" : "Hypopharynx",
      "target" : [{
        "code" : "81502006",
        "display" : "Hypopharyngeal structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "2.10",
      "display" : "Larynx",
      "target" : [{
        "code" : "4596009",
        "display" : "Laryngeal structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "2.11",
      "display" : "Schilddrüse",
      "target" : [{
        "code" : "69748006",
        "display" : "Thyroid structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "2.12",
      "display" : "Kopf-Hals sonstige",
      "target" : [{
        "code" : "774007",
        "display" : "Structure of head and/or neck (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "3.1",
      "display" : "Mamma als Ganzbrust (r, l)",
      "target" : [{
        "code" : "181131000",
        "display" : "Entire breast (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "3.2",
      "display" : "Mamma als Teilbrust (r, l)",
      "target" : [{
        "code" : "119184005",
        "display" : "Breast part (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "3.3",
      "display" : "Thoraxwand, gegebenenfalls r, l",
      "target" : [{
        "code" : "78904004",
        "display" : "Chest wall structure (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "3.4",
      "display" : "Lunge (r, l)",
      "target" : [{
        "code" : "39607008",
        "display" : "Lung structure (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "3.5",
      "display" : "Ösophagus",
      "target" : [{
        "code" : "32849002",
        "display" : "Esophageal structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "3.6",
      "display" : "Mediastinum (mediastinaler Lymphabfluss ist in Nummer 9 zu kodieren)",
      "target" : [{
        "code" : "72410000",
        "display" : "Mediastinal structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "3.7",
      "display" : "Thymus",
      "target" : [{
        "code" : "9875009",
        "display" : "Thymus gland structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "3.8",
      "display" : "Thorax sonstige",
      "target" : [{
        "code" : "51185008",
        "display" : "Thoracic structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "4.1",
      "display" : "Magen",
      "target" : [{
        "code" : "69695003",
        "display" : "Stomach structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "4.2",
      "display" : "Pankreas",
      "target" : [{
        "code" : "15776009",
        "display" : "Pancreatic structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "4.3",
      "display" : "Leber, auch bei Teilbestrahlung",
      "target" : [{
        "code" : "10200004",
        "display" : "Liver structure (body structure)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "4.4",
      "display" : "Milz",
      "target" : [{
        "code" : "78961009",
        "display" : "Splenic structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "4.5",
      "display" : "Niere (r, l)",
      "target" : [{
        "code" : "64033007",
        "display" : "Kidney structure (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "4.6",
      "display" : "Nebenniere (r, l)",
      "target" : [{
        "code" : "23451007",
        "display" : "Adrenal structure (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "4.7",
      "display" : "Retroperitoneum (z. B. Sarkome)",
      "target" : [{
        "code" : "82849001",
        "display" : "Retroperitoneal compartment structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "4.8",
      "display" : "Ureter (r, l)",
      "target" : [{
        "code" : "87953007",
        "display" : "Ureteric structure (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "4.9",
      "display" : "Bauchwand (z. B. Sarkome)",
      "target" : [{
        "code" : "822992007",
        "display" : "Structure of wall of abdominal proper segment of trunk (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "4.10",
      "display" : "Oberbauch",
      "target" : [{
        "code" : "80581009",
        "display" : "Upper abdomen structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "4.11",
      "display" : "Gallengänge",
      "target" : [{
        "code" : "28273000",
        "display" : "Bile duct structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "4.12",
      "display" : "Gallenblase",
      "target" : [{
        "code" : "28231008",
        "display" : "Gallbladder structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "4.13",
      "display" : "Abdomen sonstige",
      "target" : [{
        "code" : "818983003",
        "display" : "Structure of abdominopelvic cavity and/or content of abdominopelvic cavity and/or anterior abdominal wall (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "5.1",
      "display" : "Rektum",
      "target" : [{
        "code" : "34402009",
        "display" : "Rectum structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "5.2",
      "display" : "Analbereich",
      "target" : [{
        "code" : "53505006",
        "display" : "Anal structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "5.3",
      "display" : "Harnblase",
      "target" : [{
        "code" : "89837001",
        "display" : "Urinary bladder structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "5.4",
      "display" : "Prostata",
      "target" : [{
        "code" : "41216001",
        "display" : "Prostatic structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "5.5",
      "display" : "Hoden (r, l)",
      "target" : [{
        "code" : "40689003",
        "display" : "Testis structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "5.6",
      "display" : "Penis",
      "target" : [{
        "code" : "18911002",
        "display" : "Penile structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "5.7",
      "display" : "Uterus",
      "target" : [{
        "code" : "35039007",
        "display" : "Uterine structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "5.8",
      "display" : "Zervix",
      "target" : [{
        "code" : "71252005",
        "display" : "Cervix uteri structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "5.9",
      "display" : "Vulva",
      "target" : [{
        "code" : "45292006",
        "display" : "Vulval structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "5.10",
      "display" : "Vagina",
      "target" : [{
        "code" : "76784001",
        "display" : "Vaginal structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "5.11",
      "display" : "Beckenwand",
      "target" : [{
        "code" : "3665003",
        "display" : "Pelvic wall structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "5.12",
      "display" : "Becken sonstige",
      "target" : [{
        "code" : "826984001",
        "display" : "Structure of cavity and/or content of true pelvis (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "6.1",
      "display" : "Schädel",
      "target" : [{
        "code" : "89546000",
        "display" : "Bone structure of cranium (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "6.2",
      "display" : "Schädelbasis",
      "target" : [{
        "code" : "31467002",
        "display" : "Base of skull structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "6.3",
      "display" : "Orbita (r, l)",
      "target" : [{
        "code" : "363654007",
        "display" : "Structure of orbit proper (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "6.4",
      "display" : "Halswirbelsäule",
      "target" : [{
        "code" : "84667006",
        "display" : "Bone structure of cervical vertebra (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "6.5",
      "display" : "Brustwirbelsäule",
      "target" : [{
        "code" : "35769007",
        "display" : "Bone structure of thoracic vertebra (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "6.6",
      "display" : "Lendenwirbelsäule",
      "target" : [{
        "code" : "73903008",
        "display" : "Bone structure of lumbar vertebra (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "6.7",
      "display" : "Sacrum /Coccygeum",
      "target" : [{
        "code" : "699698002",
        "display" : "Structure of sacral vertebral column (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "6.8",
      "display" : "Rippen (r, l)",
      "target" : [{
        "code" : "113197003",
        "display" : "Bone structure of rib (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "6.9",
      "display" : "Sternum",
      "target" : [{
        "code" : "56873002",
        "display" : "Bone structure of sternum (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "6.10",
      "display" : "Schulter (r, l)",
      "target" : [{
        "code" : "896747000",
        "display" : "Bone structure of shoulder girdle and/or proximal humerus (body structure)",
        "equivalence" : "wider",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "6.11",
      "display" : "Oberarm (r, l)",
      "target" : [{
        "code" : "85050009",
        "display" : "Bone structure of humerus (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "6.12",
      "display" : "Unterarm (r, l)",
      "target" : [{
        "code" : "299701004",
        "display" : "Structure of bone of forearm (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "6.13",
      "display" : "Hand (r, l)",
      "target" : [{
        "code" : "24097009",
        "display" : "Bone structure of hand (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "6.14",
      "display" : "Becken (r, l)",
      "target" : [{
        "code" : "12921003",
        "display" : "Structure of pelvis (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "6.15",
      "display" : "Hüfte (r, l)",
      "target" : [{
        "code" : "28254004",
        "display" : "Innominate bone structure (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "6.16",
      "display" : "Oberschenkel (r, l)",
      "target" : [{
        "code" : "71341001",
        "display" : "Bone structure of femur (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "6.17",
      "display" : "Unterschenkel (r, l)",
      "target" : [{
        "code" : "702468001",
        "display" : "Bone structure of lower leg (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "6.18",
      "display" : "Fuß (r, l)",
      "target" : [{
        "code" : "84167007",
        "display" : "Bone structure of foot (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "6.19",
      "display" : "Knochen sonstige",
      "target" : [{
        "code" : "74964007",
        "display" : "Other (qualifier value)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "7.1",
      "display" : "Kopf, Gesicht, Hals",
      "target" : [{
        "code" : "774007",
        "display" : "Structure of head and/or neck (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "7.2",
      "display" : "obere Extremität ink* #lusive Schulter (r, l)",
      "target" : [{
        "code" : "53120007",
        "display" : "Upper limb structure (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "7.3",
      "display" : "untere Extremität und Hüfte (r, l)",
      "target" : [{
        "code" : "61685007",
        "display" : "Lower limb structure (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "7.4",
      "display" : "Thorax",
      "target" : [{
        "code" : "51185008",
        "display" : "Thoracic structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "7.5",
      "display" : "Abdomen",
      "target" : [{
        "code" : "302553009",
        "display" : "Entire abdomen (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "7.6",
      "display" : "Becken",
      "target" : [{
        "code" : "12921003",
        "display" : "Structure of pelvis (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "7.7",
      "display" : "Stammes o. n. A.",
      "target" : [{
        "code" : "1490004",
        "display" : "Structure of soft tissue of trunk (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "7.8",
      "display" : "mehrere Bereiche überlappend",
      "target" : [{
        "code" : "276825009",
        "display" : "Overlapping sites (qualifier value)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "7.9",
      "display" : "sonstige Weichteile o. n. A.",
      "target" : [{
        "code" : "74964007",
        "display" : "Other (qualifier value)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "8.1",
      "display" : "Ganzhaut",
      "target" : [{
        "code" : "181469002",
        "display" : "Entire skin (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "8.2",
      "display" : "Teilbereiche",
      "target" : [{
        "code" : "119181002",
        "display" : "Skin part (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "9.1",
      "display" : "Cervikale Lymphknoten (r, l)",
      "target" : [{
        "code" : "81105003",
        "display" : "Cervical lymph node structure (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "9.2",
      "display" : "Supra-/infraclavikuläre Lymphknoten (r, l)",
      "target" : [{
        "code" : "9659009",
        "display" : "Structure of infraclavicular lymph node (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "9.3",
      "display" : "Axilläre Lymphknoten (r, l)",
      "target" : [{
        "code" : "245269009",
        "display" : "Axillary lymph node group (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "9.4",
      "display" : "Retrosternale/sternale/Mammaria interna Lymphknoten",
      "target" : [{
        "code" : "245282001",
        "display" : "Internal mammary lymph node group (body structure)",
        "equivalence" : "narrower",
        "comment" : "Mapping umfasst nur Mammaria-interna-Lokalisation der Lymphknoten."
      }]
    },
    {
      "code" : "9.5",
      "display" : "Mediastinale Lymphknoten",
      "target" : [{
        "code" : "62683002",
        "display" : "Mediastinal lymph node structure (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "9.6",
      "display" : "Hiläre Lymphknoten",
      "target" : [{
        "code" : "264016003",
        "display" : "Hilar lymph node group (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "9.7",
      "display" : "Intraabdominale Lymphknoten (z. B. subphrenisch, perigastrisch, peripankreatisch, Leber-, Milzhilus)",
      "target" : [{
        "code" : "818991007",
        "display" : "Structure of abdominal lymph node (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "9.8",
      "display" : "Paraaortale/paracavale Lymphknoten",
      "target" : [{
        "code" : "245285004",
        "display" : "Para-aortic lymph node group (body structure)",
        "equivalence" : "narrower",
        "comment" : "Mapping umfasst nur para-aortale Lokalisation der Lymphknoten."
      }]
    },
    {
      "code" : "9.9",
      "display" : "Retroperitoneale Lymphknoten",
      "target" : [{
        "code" : "91394001",
        "display" : "Structure of retroperitoneal lymph node (body structure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "9.10",
      "display" : "Beckenlymphabfluss (r, l) (Iliakal commun, extern, intern, obturatorisch, präsakral)",
      "target" : [{
        "code" : "54268001",
        "display" : "Pelvic lymph node structure (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "9.11",
      "display" : "Inguinale Lymphknoten (r, l)",
      "target" : [{
        "code" : "8928004",
        "display" : "Inguinal lymph node structure (body structure)",
        "equivalence" : "equivalent",
        "comment" : "Lateralität über Postkoordination darstellbar"
      }]
    },
    {
      "code" : "9.12",
      "display" : "Involved Node",
      "target" : [{
        "equivalence" : "unmatched"
      }]
    },
    {
      "code" : "9.13",
      "display" : "Involved Site",
      "target" : [{
        "code" : "397440000",
        "display" : "Anatomic location of excised lymph node containing metastatic neoplasm (observable entity)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "9.14",
      "display" : "Involved Field",
      "target" : [{
        "equivalence" : "unmatched"
      }]
    },
    {
      "code" : "9.15",
      "display" : "Sonstige Lymphknoten",
      "target" : [{
        "code" : "59441001",
        "display" : "Structure of lymph node (body structure)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "10.1",
      "display" : "Ganzkörperbestrahlung bei allogener Stammzelltransplantation",
      "target" : [{
        "code" : "38266002",
        "display" : "Entire body as a whole (body structure)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "10.2",
      "display" : "operative Zugangswege",
      "target" : [{
        "code" : "309795001",
        "display" : "Surgical access values (qualifier value)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "10.3",
      "display" : "Sonstige, nicht genannte Zielgebiete",
      "target" : [{
        "code" : "74964007",
        "display" : "Other (qualifier value)",
        "equivalence" : "equivalent"
      }]
    }]
  }]
}

```
