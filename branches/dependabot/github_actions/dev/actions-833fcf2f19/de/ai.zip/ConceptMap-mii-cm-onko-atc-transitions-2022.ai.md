# MII CM Onko ATC Code Changes 2021 to 2022 - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII CM Onko ATC Code Changes 2021 to 2022**

## ConceptMap: MII CM Onko ATC Code Changes 2021 to 2022 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-atc-transitions-2022 | *Version*:2026.0.3 |
| Active Stand: 2026-08-25 | *Maschinenlesbarer Name*:MII_CM_Onko_ATC_Transitions_2022 |

 
Diese ConceptMap dokumentiert die ATC-Code-Änderungen von 2021 zu 2022. In diesem Jahr erfolgte die größte Reklassifikation der onkologischen ATC-Systematik: die monoklonalen Antikörper wurden aus der Sammelgruppe L01XC in die neue, nach Zielstruktur gegliederte Gruppe L01F überführt. 



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "mii-cm-onko-atc-transitions-2022",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-license",
      "valueCode" : "CC-BY-4.0"
    },
    {
      "extension" : [{
        "url" : "packageId",
        "valueId" : "de.medizininformatikinitiative.kerndatensatz.onkologie"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/package-source"
    },
    {
      "url" : "version",
      "valueString" : "2026.0.3"
    }],
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareableconceptmap",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishableconceptmap"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionPolicy",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes",
        "code" : "package",
        "display" : "Package"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-approvalDate",
    "valueDate" : "2026-01-03"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-topic",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
        "code" : "C3262"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-author",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "email",
        "value" : "thomas.debertshaeuser@charite.de"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-editor",
    "valueContactDetail" : {
      "name" : "Taskforce Core Data Set"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2026"
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-atc-transitions-2022",
  "version" : "2026.0.3",
  "name" : "MII_CM_Onko_ATC_Transitions_2022",
  "title" : "MII CM Onko ATC Code Changes 2021 to 2022",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-25",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Diese ConceptMap dokumentiert die ATC-Code-Änderungen von 2021 zu 2022. In diesem Jahr erfolgte die größte Reklassifikation der onkologischen ATC-Systematik: die monoklonalen Antikörper wurden aus der Sammelgruppe L01XC in die neue, nach Zielstruktur gegliederte Gruppe L01F überführt.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "purpose" : "Migration von ATC-Codes für monoklonale Antikörper, die 2022 von L01XC nach L01F umkodiert wurden.",
  "sourceCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-systemische-therapie-substanzen-2021",
  "targetCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-systemische-therapie-substanzen-2022",
  "group" : [{
    "source" : "http://fhir.de/CodeSystem/bfarm/atc",
    "target" : "http://fhir.de/CodeSystem/bfarm/atc",
    "element" : [{
      "code" : "L01XC02",
      "display" : "Rituximab",
      "target" : [{
        "code" : "L01FA01",
        "display" : "Rituximab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu CD20-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC15",
      "display" : "Obinutuzumab",
      "target" : [{
        "code" : "L01FA03",
        "display" : "Obinutuzumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu CD20-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC26",
      "display" : "Inotuzumab ozogamicin",
      "target" : [{
        "code" : "L01FB01",
        "display" : "Inotuzumab ozogamicin",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu CD22-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC24",
      "display" : "Daratumumab",
      "target" : [{
        "code" : "L01FC01",
        "display" : "Daratumumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu CD38-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC03",
      "display" : "Trastuzumab",
      "target" : [{
        "code" : "L01FD01",
        "display" : "Trastuzumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu HER2-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC13",
      "display" : "Pertuzumab",
      "target" : [{
        "code" : "L01FD02",
        "display" : "Pertuzumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu HER2-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC14",
      "display" : "Trastuzumab emtansin",
      "target" : [{
        "code" : "L01FD03",
        "display" : "Trastuzumab emtansin",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu HER2-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC06",
      "display" : "Cetuximab",
      "target" : [{
        "code" : "L01FE01",
        "display" : "Cetuximab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu EGFR-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC08",
      "display" : "Panitumumab",
      "target" : [{
        "code" : "L01FE02",
        "display" : "Panitumumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu EGFR-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC17",
      "display" : "Nivolumab",
      "target" : [{
        "code" : "L01FF01",
        "display" : "Nivolumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu PD-1-/PD-L1-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC18",
      "display" : "Pembrolizumab",
      "target" : [{
        "code" : "L01FF02",
        "display" : "Pembrolizumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu PD-1-/PD-L1-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC28",
      "display" : "Durvalumab",
      "target" : [{
        "code" : "L01FF03",
        "display" : "Durvalumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu PD-1-/PD-L1-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC31",
      "display" : "Avelumab",
      "target" : [{
        "code" : "L01FF04",
        "display" : "Avelumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu PD-1-/PD-L1-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC32",
      "display" : "Atezolizumab",
      "target" : [{
        "code" : "L01FF05",
        "display" : "Atezolizumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu PD-1-/PD-L1-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC07",
      "display" : "Bevacizumab",
      "target" : [{
        "code" : "L01FG01",
        "display" : "Bevacizumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu VEGF-/VEGFR-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC21",
      "display" : "Ramucirumab",
      "target" : [{
        "code" : "L01FG02",
        "display" : "Ramucirumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu VEGF-/VEGFR-Inhibitoren"
      }]
    },
    {
      "code" : "L01XC11",
      "display" : "Ipilimumab",
      "target" : [{
        "code" : "L01FX04",
        "display" : "Ipilimumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu andere monoklonale Antikörper"
      }]
    },
    {
      "code" : "L01XC12",
      "display" : "Brentuximab vedotin",
      "target" : [{
        "code" : "L01FX05",
        "display" : "Brentuximab vedotin",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu andere monoklonale Antikörper"
      }]
    },
    {
      "code" : "L01XC19",
      "display" : "Blinatumomab",
      "target" : [{
        "code" : "L01FX07",
        "display" : "Blinatumomab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu andere monoklonale Antikörper"
      }]
    },
    {
      "code" : "L01XC27",
      "display" : "Olaratumab",
      "target" : [{
        "code" : "L01FX10",
        "display" : "Olaratumab",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu andere monoklonale Antikörper"
      }]
    }]
  }]
}

```
