# MII VS Onkologie Nebenwirkung nach CTCAE Art - MII IG Kerndatensatz-Modul Onkologie v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII VS Onkologie Nebenwirkung nach CTCAE Art**

## ValueSet: MII VS Onkologie Nebenwirkung nach CTCAE Art 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-nebenwirkung-art | *Version*:2027.0.0-ballot |
| Active Stand: 2026-09-14 | *Maschinenlesbarer Name*:MII_VS_Onko_Nebenwirkung_Art |

 
Alle MedDRA-Codes der CTCAE v4.03 (Art der Nebenwirkung). Deutsche/englische Displays via CodeSystem-Supplements mii-cs-onko-nebenwirkung-meddra-de/-en. 

 **References** 

* [MII PR Onkologie Nebenwirkung von Strahlentherapie und systemische Therapie](StructureDefinition-mii-pr-onko-nebenwirkung-adverse-event.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-onko-nebenwirkung-art",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-license",
      "valueCode" : "CC-BY-4.0"
    },
    {
      "extension" : [{
        "url" : "packageId",
        "valueId" : "de.medizininformatikinitiative.kerndatensatz.onkologie"
      },
      {
        "url" : "version",
        "valueString" : "2027.0.0-ballot"
      },
      {
        "url" : "uri",
        "valueUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/package-source"
    }],
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablevalueset",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-computablevalueset"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionPolicy",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes",
        "code" : "package",
        "display" : "Package"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-approvalDate",
    "valueDate" : "2026-09-15"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-topic",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
        "code" : "C3262"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-author",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "email",
        "value" : "thomas.debertshaeuser@charite.de"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-editor",
    "valueContactDetail" : {
      "name" : "Taskforce Core Data Set"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2027"
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-nebenwirkung-art",
  "version" : "2027.0.0-ballot",
  "name" : "MII_VS_Onko_Nebenwirkung_Art",
  "title" : "MII VS Onkologie Nebenwirkung nach CTCAE Art",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-14T13:55:39+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Alle MedDRA-Codes der CTCAE v4.03 (Art der Nebenwirkung). Deutsche/englische Displays via CodeSystem-Supplements mii-cs-onko-nebenwirkung-meddra-de/-en.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://www.meddra.org",
      "concept" : [{
        "code" : "10000060"
      },
      {
        "code" : "10000081"
      },
      {
        "code" : "10000486"
      },
      {
        "code" : "10000521"
      },
      {
        "code" : "10000636"
      },
      {
        "code" : "10001367"
      },
      {
        "code" : "10001409"
      },
      {
        "code" : "10001497"
      },
      {
        "code" : "10001540"
      },
      {
        "code" : "10001551"
      },
      {
        "code" : "10001598"
      },
      {
        "code" : "10001675"
      },
      {
        "code" : "10001680"
      },
      {
        "code" : "10001718"
      },
      {
        "code" : "10001723"
      },
      {
        "code" : "10001760"
      },
      {
        "code" : "10001949"
      },
      {
        "code" : "10002156"
      },
      {
        "code" : "10002167"
      },
      {
        "code" : "10002176"
      },
      {
        "code" : "10002180"
      },
      {
        "code" : "10002218"
      },
      {
        "code" : "10002272"
      },
      {
        "code" : "10002544"
      },
      {
        "code" : "10002646"
      },
      {
        "code" : "10002652"
      },
      {
        "code" : "10002855"
      },
      {
        "code" : "10002899"
      },
      {
        "code" : "10002953"
      },
      {
        "code" : "10002972"
      },
      {
        "code" : "10003011"
      },
      {
        "code" : "10003012"
      },
      {
        "code" : "10003074"
      },
      {
        "code" : "10003162"
      },
      {
        "code" : "10003239"
      },
      {
        "code" : "10003246"
      },
      {
        "code" : "10003445"
      },
      {
        "code" : "10003481"
      },
      {
        "code" : "10003504"
      },
      {
        "code" : "10003586"
      },
      {
        "code" : "10003591"
      },
      {
        "code" : "10003598"
      },
      {
        "code" : "10003658"
      },
      {
        "code" : "10003662"
      },
      {
        "code" : "10003673"
      },
      {
        "code" : "10003674"
      },
      {
        "code" : "10003883"
      },
      {
        "code" : "10003988"
      },
      {
        "code" : "10004665"
      },
      {
        "code" : "10005047"
      },
      {
        "code" : "10005265"
      },
      {
        "code" : "10005329"
      },
      {
        "code" : "10005332"
      },
      {
        "code" : "10005364"
      },
      {
        "code" : "10005452"
      },
      {
        "code" : "10005561"
      },
      {
        "code" : "10005778"
      },
      {
        "code" : "10005886"
      },
      {
        "code" : "10005901"
      },
      {
        "code" : "10006002"
      },
      {
        "code" : "10006179"
      },
      {
        "code" : "10006259"
      },
      {
        "code" : "10006298"
      },
      {
        "code" : "10006437"
      },
      {
        "code" : "10006440"
      },
      {
        "code" : "10006482"
      },
      {
        "code" : "10006504"
      },
      {
        "code" : "10006556"
      },
      {
        "code" : "10006634"
      },
      {
        "code" : "10007196"
      },
      {
        "code" : "10007515"
      },
      {
        "code" : "10007541"
      },
      {
        "code" : "10007612"
      },
      {
        "code" : "10007613"
      },
      {
        "code" : "10007739"
      },
      {
        "code" : "10007810"
      },
      {
        "code" : "10007839"
      },
      {
        "code" : "10008164"
      },
      {
        "code" : "10008330"
      },
      {
        "code" : "10008417"
      },
      {
        "code" : "10008481"
      },
      {
        "code" : "10008496"
      },
      {
        "code" : "10008531"
      },
      {
        "code" : "10008612"
      },
      {
        "code" : "10008661"
      },
      {
        "code" : "10009845"
      },
      {
        "code" : "10009887"
      },
      {
        "code" : "10009995"
      },
      {
        "code" : "10009998"
      },
      {
        "code" : "10010000"
      },
      {
        "code" : "10010001"
      },
      {
        "code" : "10010004"
      },
      {
        "code" : "10010006"
      },
      {
        "code" : "10010250"
      },
      {
        "code" : "10010276"
      },
      {
        "code" : "10010300"
      },
      {
        "code" : "10010331"
      },
      {
        "code" : "10010741"
      },
      {
        "code" : "10010742"
      },
      {
        "code" : "10010774"
      },
      {
        "code" : "10010783"
      },
      {
        "code" : "10011224"
      },
      {
        "code" : "10011268"
      },
      {
        "code" : "10011368"
      },
      {
        "code" : "10011655"
      },
      {
        "code" : "10011912"
      },
      {
        "code" : "10011914"
      },
      {
        "code" : "10012174"
      },
      {
        "code" : "10012205"
      },
      {
        "code" : "10012218"
      },
      {
        "code" : "10012260"
      },
      {
        "code" : "10012318"
      },
      {
        "code" : "10012373"
      },
      {
        "code" : "10012378"
      },
      {
        "code" : "10012727"
      },
      {
        "code" : "10013442"
      },
      {
        "code" : "10013573"
      },
      {
        "code" : "10013774"
      },
      {
        "code" : "10013781"
      },
      {
        "code" : "10013786"
      },
      {
        "code" : "10013828"
      },
      {
        "code" : "10013830"
      },
      {
        "code" : "10013832"
      },
      {
        "code" : "10013836"
      },
      {
        "code" : "10013887"
      },
      {
        "code" : "10013911"
      },
      {
        "code" : "10013934"
      },
      {
        "code" : "10013941"
      },
      {
        "code" : "10013946"
      },
      {
        "code" : "10013950"
      },
      {
        "code" : "10013951"
      },
      {
        "code" : "10013963"
      },
      {
        "code" : "10013993"
      },
      {
        "code" : "10014020"
      },
      {
        "code" : "10014217"
      },
      {
        "code" : "10014222"
      },
      {
        "code" : "10014326"
      },
      {
        "code" : "10014383"
      },
      {
        "code" : "10014594"
      },
      {
        "code" : "10014621"
      },
      {
        "code" : "10014625"
      },
      {
        "code" : "10014678"
      },
      {
        "code" : "10014698"
      },
      {
        "code" : "10014801"
      },
      {
        "code" : "10014893"
      },
      {
        "code" : "10015090"
      },
      {
        "code" : "10015218"
      },
      {
        "code" : "10015277"
      },
      {
        "code" : "10015384"
      },
      {
        "code" : "10015387"
      },
      {
        "code" : "10015388"
      },
      {
        "code" : "10015448"
      },
      {
        "code" : "10015451"
      },
      {
        "code" : "10015453"
      },
      {
        "code" : "10015461"
      },
      {
        "code" : "10015533"
      },
      {
        "code" : "10015688"
      },
      {
        "code" : "10015829"
      },
      {
        "code" : "10015832"
      },
      {
        "code" : "10015919"
      },
      {
        "code" : "10015929"
      },
      {
        "code" : "10015958"
      },
      {
        "code" : "10016059"
      },
      {
        "code" : "10016173"
      },
      {
        "code" : "10016241"
      },
      {
        "code" : "10016256"
      },
      {
        "code" : "10016288"
      },
      {
        "code" : "10016296"
      },
      {
        "code" : "10016479"
      },
      {
        "code" : "10016558"
      },
      {
        "code" : "10016596"
      },
      {
        "code" : "10016750"
      },
      {
        "code" : "10016757"
      },
      {
        "code" : "10016766"
      },
      {
        "code" : "10016778"
      },
      {
        "code" : "10016791"
      },
      {
        "code" : "10016825"
      },
      {
        "code" : "10016987"
      },
      {
        "code" : "10017076"
      },
      {
        "code" : "10017577"
      },
      {
        "code" : "10017631"
      },
      {
        "code" : "10017636"
      },
      {
        "code" : "10017638"
      },
      {
        "code" : "10017639"
      },
      {
        "code" : "10017789"
      },
      {
        "code" : "10017815"
      },
      {
        "code" : "10017822"
      },
      {
        "code" : "10017853"
      },
      {
        "code" : "10017877"
      },
      {
        "code" : "10017947"
      },
      {
        "code" : "10017999"
      },
      {
        "code" : "10018043"
      },
      {
        "code" : "10018065"
      },
      {
        "code" : "10018146"
      },
      {
        "code" : "10018286"
      },
      {
        "code" : "10018304"
      },
      {
        "code" : "10018746"
      },
      {
        "code" : "10018748"
      },
      {
        "code" : "10018761"
      },
      {
        "code" : "10018784"
      },
      {
        "code" : "10018801"
      },
      {
        "code" : "10019077"
      },
      {
        "code" : "10019150"
      },
      {
        "code" : "10019211"
      },
      {
        "code" : "10019245"
      },
      {
        "code" : "10019279"
      },
      {
        "code" : "10019428"
      },
      {
        "code" : "10019450"
      },
      {
        "code" : "10019489"
      },
      {
        "code" : "10019491"
      },
      {
        "code" : "10019515"
      },
      {
        "code" : "10019611"
      },
      {
        "code" : "10019663"
      },
      {
        "code" : "10019678"
      },
      {
        "code" : "10019692"
      },
      {
        "code" : "10019705"
      },
      {
        "code" : "10019799"
      },
      {
        "code" : "10019805"
      },
      {
        "code" : "10020039"
      },
      {
        "code" : "10020100"
      },
      {
        "code" : "10020112"
      },
      {
        "code" : "10020201"
      },
      {
        "code" : "10020407"
      },
      {
        "code" : "10020508"
      },
      {
        "code" : "10020587"
      },
      {
        "code" : "10020639"
      },
      {
        "code" : "10020642"
      },
      {
        "code" : "10020647"
      },
      {
        "code" : "10020670"
      },
      {
        "code" : "10020680"
      },
      {
        "code" : "10020705"
      },
      {
        "code" : "10020765"
      },
      {
        "code" : "10020772"
      },
      {
        "code" : "10020850"
      },
      {
        "code" : "10020864"
      },
      {
        "code" : "10020870"
      },
      {
        "code" : "10020907"
      },
      {
        "code" : "10020943"
      },
      {
        "code" : "10020949"
      },
      {
        "code" : "10021005"
      },
      {
        "code" : "10021013"
      },
      {
        "code" : "10021018"
      },
      {
        "code" : "10021028"
      },
      {
        "code" : "10021038"
      },
      {
        "code" : "10021041"
      },
      {
        "code" : "10021059"
      },
      {
        "code" : "10021097"
      },
      {
        "code" : "10021113"
      },
      {
        "code" : "10021114"
      },
      {
        "code" : "10021143"
      },
      {
        "code" : "10021305"
      },
      {
        "code" : "10021307"
      },
      {
        "code" : "10021309"
      },
      {
        "code" : "10021328"
      },
      {
        "code" : "10021428"
      },
      {
        "code" : "10021881"
      },
      {
        "code" : "10021918"
      },
      {
        "code" : "10022095"
      },
      {
        "code" : "10022117"
      },
      {
        "code" : "10022161"
      },
      {
        "code" : "10022213"
      },
      {
        "code" : "10022356"
      },
      {
        "code" : "10022402"
      },
      {
        "code" : "10022437"
      },
      {
        "code" : "10022763"
      },
      {
        "code" : "10022891"
      },
      {
        "code" : "10022992"
      },
      {
        "code" : "10022998"
      },
      {
        "code" : "10023030"
      },
      {
        "code" : "10023174"
      },
      {
        "code" : "10023176"
      },
      {
        "code" : "10023177"
      },
      {
        "code" : "10023215"
      },
      {
        "code" : "10023216"
      },
      {
        "code" : "10023332"
      },
      {
        "code" : "10023424"
      },
      {
        "code" : "10023509"
      },
      {
        "code" : "10023838"
      },
      {
        "code" : "10023862"
      },
      {
        "code" : "10023874"
      },
      {
        "code" : "10023891"
      },
      {
        "code" : "10024264"
      },
      {
        "code" : "10024378"
      },
      {
        "code" : "10024382"
      },
      {
        "code" : "10024419"
      },
      {
        "code" : "10024421"
      },
      {
        "code" : "10024561"
      },
      {
        "code" : "10024574"
      },
      {
        "code" : "10024842"
      },
      {
        "code" : "10025182"
      },
      {
        "code" : "10025233"
      },
      {
        "code" : "10025256"
      },
      {
        "code" : "10025258"
      },
      {
        "code" : "10025476"
      },
      {
        "code" : "10025482"
      },
      {
        "code" : "10026749"
      },
      {
        "code" : "10027175"
      },
      {
        "code" : "10027198"
      },
      {
        "code" : "10027199"
      },
      {
        "code" : "10027308"
      },
      {
        "code" : "10027313"
      },
      {
        "code" : "10027433"
      },
      {
        "code" : "10027786"
      },
      {
        "code" : "10027787"
      },
      {
        "code" : "10028041"
      },
      {
        "code" : "10028130"
      },
      {
        "code" : "10028154"
      },
      {
        "code" : "10028395"
      },
      {
        "code" : "10028411"
      },
      {
        "code" : "10028524"
      },
      {
        "code" : "10028533"
      },
      {
        "code" : "10028596"
      },
      {
        "code" : "10028606"
      },
      {
        "code" : "10028653"
      },
      {
        "code" : "10028691"
      },
      {
        "code" : "10028735"
      },
      {
        "code" : "10028813"
      },
      {
        "code" : "10028836"
      },
      {
        "code" : "10029104"
      },
      {
        "code" : "10029205"
      },
      {
        "code" : "10029223"
      },
      {
        "code" : "10029366"
      },
      {
        "code" : "10029404"
      },
      {
        "code" : "10029864"
      },
      {
        "code" : "10029883"
      },
      {
        "code" : "10029957"
      },
      {
        "code" : "10030300"
      },
      {
        "code" : "10030980"
      },
      {
        "code" : "10031009"
      },
      {
        "code" : "10031282"
      },
      {
        "code" : "10033072"
      },
      {
        "code" : "10033078"
      },
      {
        "code" : "10033279"
      },
      {
        "code" : "10033314"
      },
      {
        "code" : "10033371"
      },
      {
        "code" : "10033425"
      },
      {
        "code" : "10033474"
      },
      {
        "code" : "10033557"
      },
      {
        "code" : "10033626"
      },
      {
        "code" : "10033645"
      },
      {
        "code" : "10033703"
      },
      {
        "code" : "10033987"
      },
      {
        "code" : "10034016"
      },
      {
        "code" : "10034040"
      },
      {
        "code" : "10034263"
      },
      {
        "code" : "10034310"
      },
      {
        "code" : "10034405"
      },
      {
        "code" : "10034474"
      },
      {
        "code" : "10034484"
      },
      {
        "code" : "10034536"
      },
      {
        "code" : "10034578"
      },
      {
        "code" : "10034580"
      },
      {
        "code" : "10034620"
      },
      {
        "code" : "10034719"
      },
      {
        "code" : "10034825"
      },
      {
        "code" : "10034835"
      },
      {
        "code" : "10034844"
      },
      {
        "code" : "10034879"
      },
      {
        "code" : "10034960"
      },
      {
        "code" : "10034966"
      },
      {
        "code" : "10035528"
      },
      {
        "code" : "10035598"
      },
      {
        "code" : "10035623"
      },
      {
        "code" : "10035742"
      },
      {
        "code" : "10035759"
      },
      {
        "code" : "10036200"
      },
      {
        "code" : "10036206"
      },
      {
        "code" : "10036402"
      },
      {
        "code" : "10036585"
      },
      {
        "code" : "10036595"
      },
      {
        "code" : "10036601"
      },
      {
        "code" : "10036653"
      },
      {
        "code" : "10036774"
      },
      {
        "code" : "10036790"
      },
      {
        "code" : "10036968"
      },
      {
        "code" : "10037032"
      },
      {
        "code" : "10037087"
      },
      {
        "code" : "10037175"
      },
      {
        "code" : "10037234"
      },
      {
        "code" : "10037375"
      },
      {
        "code" : "10037383"
      },
      {
        "code" : "10037400"
      },
      {
        "code" : "10037549"
      },
      {
        "code" : "10037767"
      },
      {
        "code" : "10037847"
      },
      {
        "code" : "10037868"
      },
      {
        "code" : "10037888"
      },
      {
        "code" : "10038062"
      },
      {
        "code" : "10038064"
      },
      {
        "code" : "10038072"
      },
      {
        "code" : "10038073"
      },
      {
        "code" : "10038079"
      },
      {
        "code" : "10038080"
      },
      {
        "code" : "10038130"
      },
      {
        "code" : "10038359"
      },
      {
        "code" : "10038385"
      },
      {
        "code" : "10038419"
      },
      {
        "code" : "10038463"
      },
      {
        "code" : "10038604"
      },
      {
        "code" : "10038695"
      },
      {
        "code" : "10038738"
      },
      {
        "code" : "10038743"
      },
      {
        "code" : "10038748"
      },
      {
        "code" : "10038848"
      },
      {
        "code" : "10038897"
      },
      {
        "code" : "10038901"
      },
      {
        "code" : "10038921"
      },
      {
        "code" : "10038923"
      },
      {
        "code" : "10038981"
      },
      {
        "code" : "10039411"
      },
      {
        "code" : "10039413"
      },
      {
        "code" : "10039722"
      },
      {
        "code" : "10039757"
      },
      {
        "code" : "10039906"
      },
      {
        "code" : "10040047"
      },
      {
        "code" : "10040102"
      },
      {
        "code" : "10040139"
      },
      {
        "code" : "10040400"
      },
      {
        "code" : "10040639"
      },
      {
        "code" : "10040741"
      },
      {
        "code" : "10040747"
      },
      {
        "code" : "10040752"
      },
      {
        "code" : "10040753"
      },
      {
        "code" : "10040785"
      },
      {
        "code" : "10040799"
      },
      {
        "code" : "10040865"
      },
      {
        "code" : "10040868"
      },
      {
        "code" : "10040872"
      },
      {
        "code" : "10040947"
      },
      {
        "code" : "10040975"
      },
      {
        "code" : "10041101"
      },
      {
        "code" : "10041103"
      },
      {
        "code" : "10041133"
      },
      {
        "code" : "10041232"
      },
      {
        "code" : "10041244"
      },
      {
        "code" : "10041349"
      },
      {
        "code" : "10041367"
      },
      {
        "code" : "10041416"
      },
      {
        "code" : "10041569"
      },
      {
        "code" : "10041633"
      },
      {
        "code" : "10042033"
      },
      {
        "code" : "10042112"
      },
      {
        "code" : "10042127"
      },
      {
        "code" : "10042241"
      },
      {
        "code" : "10042244"
      },
      {
        "code" : "10042435"
      },
      {
        "code" : "10042458"
      },
      {
        "code" : "10042464"
      },
      {
        "code" : "10042554"
      },
      {
        "code" : "10042569"
      },
      {
        "code" : "10042604"
      },
      {
        "code" : "10042613"
      },
      {
        "code" : "10042772"
      },
      {
        "code" : "10043189"
      },
      {
        "code" : "10043306"
      },
      {
        "code" : "10043345"
      },
      {
        "code" : "10043565"
      },
      {
        "code" : "10043648"
      },
      {
        "code" : "10043882"
      },
      {
        "code" : "10044030"
      },
      {
        "code" : "10044031"
      },
      {
        "code" : "10044055"
      },
      {
        "code" : "10044223"
      },
      {
        "code" : "10044291"
      },
      {
        "code" : "10044302"
      },
      {
        "code" : "10044391"
      },
      {
        "code" : "10044565"
      },
      {
        "code" : "10044684"
      },
      {
        "code" : "10045152"
      },
      {
        "code" : "10045158"
      },
      {
        "code" : "10045271"
      },
      {
        "code" : "10045542"
      },
      {
        "code" : "10046300"
      },
      {
        "code" : "10046539"
      },
      {
        "code" : "10046543"
      },
      {
        "code" : "10046555"
      },
      {
        "code" : "10046571"
      },
      {
        "code" : "10046593"
      },
      {
        "code" : "10046628"
      },
      {
        "code" : "10046735"
      },
      {
        "code" : "10046789"
      },
      {
        "code" : "10046809"
      },
      {
        "code" : "10046810"
      },
      {
        "code" : "10046851"
      },
      {
        "code" : "10046901"
      },
      {
        "code" : "10046904"
      },
      {
        "code" : "10046912"
      },
      {
        "code" : "10046914"
      },
      {
        "code" : "10046916"
      },
      {
        "code" : "10046937"
      },
      {
        "code" : "10046947"
      },
      {
        "code" : "10047065"
      },
      {
        "code" : "10047115"
      },
      {
        "code" : "10047166"
      },
      {
        "code" : "10047228"
      },
      {
        "code" : "10047281"
      },
      {
        "code" : "10047290"
      },
      {
        "code" : "10047302"
      },
      {
        "code" : "10047340"
      },
      {
        "code" : "10047386"
      },
      {
        "code" : "10047488"
      },
      {
        "code" : "10047580"
      },
      {
        "code" : "10047656"
      },
      {
        "code" : "10047681"
      },
      {
        "code" : "10047700"
      },
      {
        "code" : "10047848"
      },
      {
        "code" : "10047896"
      },
      {
        "code" : "10047900"
      },
      {
        "code" : "10047924"
      },
      {
        "code" : "10048015"
      },
      {
        "code" : "10048031"
      },
      {
        "code" : "10048038"
      },
      {
        "code" : "10048049"
      },
      {
        "code" : "10048293"
      },
      {
        "code" : "10048492"
      },
      {
        "code" : "10048580"
      },
      {
        "code" : "10048642"
      },
      {
        "code" : "10048677"
      },
      {
        "code" : "10048706"
      },
      {
        "code" : "10048762"
      },
      {
        "code" : "10048994"
      },
      {
        "code" : "10049120"
      },
      {
        "code" : "10049182"
      },
      {
        "code" : "10049192"
      },
      {
        "code" : "10049281"
      },
      {
        "code" : "10049468"
      },
      {
        "code" : "10049737"
      },
      {
        "code" : "10050028"
      },
      {
        "code" : "10050068"
      },
      {
        "code" : "10050094"
      },
      {
        "code" : "10050457"
      },
      {
        "code" : "10050458"
      },
      {
        "code" : "10050528"
      },
      {
        "code" : "10050662"
      },
      {
        "code" : "10050816"
      },
      {
        "code" : "10050823"
      },
      {
        "code" : "10051228"
      },
      {
        "code" : "10051272"
      },
      {
        "code" : "10051341"
      },
      {
        "code" : "10051472"
      },
      {
        "code" : "10051592"
      },
      {
        "code" : "10051741"
      },
      {
        "code" : "10051746"
      },
      {
        "code" : "10051792"
      },
      {
        "code" : "10051837"
      },
      {
        "code" : "10051886"
      },
      {
        "code" : "10052015"
      },
      {
        "code" : "10052298"
      },
      {
        "code" : "10052426"
      },
      {
        "code" : "10053481"
      },
      {
        "code" : "10053496"
      },
      {
        "code" : "10053565"
      },
      {
        "code" : "10053661"
      },
      {
        "code" : "10053662"
      },
      {
        "code" : "10053692"
      },
      {
        "code" : "10054382"
      },
      {
        "code" : "10054482"
      },
      {
        "code" : "10054520"
      },
      {
        "code" : "10054524"
      },
      {
        "code" : "10054541"
      },
      {
        "code" : "10054692"
      },
      {
        "code" : "10054746"
      },
      {
        "code" : "10055005"
      },
      {
        "code" : "10055026"
      },
      {
        "code" : "10055078"
      },
      {
        "code" : "10055226"
      },
      {
        "code" : "10055242"
      },
      {
        "code" : "10055287"
      },
      {
        "code" : "10055291"
      },
      {
        "code" : "10055298"
      },
      {
        "code" : "10055300"
      },
      {
        "code" : "10055315"
      },
      {
        "code" : "10055319"
      },
      {
        "code" : "10055322"
      },
      {
        "code" : "10055325"
      },
      {
        "code" : "10055347"
      },
      {
        "code" : "10055356"
      },
      {
        "code" : "10055472"
      },
      {
        "code" : "10055599"
      },
      {
        "code" : "10056238"
      },
      {
        "code" : "10056356"
      },
      {
        "code" : "10056388"
      },
      {
        "code" : "10056519"
      },
      {
        "code" : "10056522"
      },
      {
        "code" : "10056627"
      },
      {
        "code" : "10056681"
      },
      {
        "code" : "10056745"
      },
      {
        "code" : "10056910"
      },
      {
        "code" : "10057066"
      },
      {
        "code" : "10057262"
      },
      {
        "code" : "10057483"
      },
      {
        "code" : "10058084"
      },
      {
        "code" : "10058096"
      },
      {
        "code" : "10058597"
      },
      {
        "code" : "10058674"
      },
      {
        "code" : "10058720"
      },
      {
        "code" : "10058804"
      },
      {
        "code" : "10058838"
      },
      {
        "code" : "10059094"
      },
      {
        "code" : "10059095"
      },
      {
        "code" : "10059446"
      },
      {
        "code" : "10059639"
      },
      {
        "code" : "10059827"
      },
      {
        "code" : "10059895"
      },
      {
        "code" : "10060602"
      },
      {
        "code" : "10060640"
      },
      {
        "code" : "10060890"
      },
      {
        "code" : "10060929"
      },
      {
        "code" : "10061017"
      },
      {
        "code" : "10061103"
      },
      {
        "code" : "10061145"
      },
      {
        "code" : "10061149"
      },
      {
        "code" : "10061185"
      },
      {
        "code" : "10061212"
      },
      {
        "code" : "10061229"
      },
      {
        "code" : "10061261"
      },
      {
        "code" : "10061304"
      },
      {
        "code" : "10061322"
      },
      {
        "code" : "10061339"
      },
      {
        "code" : "10061351"
      },
      {
        "code" : "10061389"
      },
      {
        "code" : "10061403"
      },
      {
        "code" : "10061457"
      },
      {
        "code" : "10061461"
      },
      {
        "code" : "10061510"
      },
      {
        "code" : "10061532"
      },
      {
        "code" : "10061541"
      },
      {
        "code" : "10061574"
      },
      {
        "code" : "10061589"
      },
      {
        "code" : "10061640"
      },
      {
        "code" : "10061664"
      },
      {
        "code" : "10061695"
      },
      {
        "code" : "10061788"
      },
      {
        "code" : "10061912"
      },
      {
        "code" : "10061928"
      },
      {
        "code" : "10061970"
      },
      {
        "code" : "10062112"
      },
      {
        "code" : "10062156"
      },
      {
        "code" : "10062169"
      },
      {
        "code" : "10062225"
      },
      {
        "code" : "10062233"
      },
      {
        "code" : "10062244"
      },
      {
        "code" : "10062255"
      },
      {
        "code" : "10062263"
      },
      {
        "code" : "10062283"
      },
      {
        "code" : "10062315"
      },
      {
        "code" : "10062466"
      },
      {
        "code" : "10062501"
      },
      {
        "code" : "10062548"
      },
      {
        "code" : "10062570"
      },
      {
        "code" : "10062572"
      },
      {
        "code" : "10062632"
      },
      {
        "code" : "10062646"
      },
      {
        "code" : "10062667"
      },
      {
        "code" : "10062872"
      },
      {
        "code" : "10063057"
      },
      {
        "code" : "10063190"
      },
      {
        "code" : "10063524"
      },
      {
        "code" : "10063575"
      },
      {
        "code" : "10063636"
      },
      {
        "code" : "10063761"
      },
      {
        "code" : "10064026"
      },
      {
        "code" : "10064505"
      },
      {
        "code" : "10064658"
      },
      {
        "code" : "10064687"
      },
      {
        "code" : "10064774"
      },
      {
        "code" : "10064848"
      },
      {
        "code" : "10065368"
      },
      {
        "code" : "10065417"
      },
      {
        "code" : "10065703"
      },
      {
        "code" : "10065704"
      },
      {
        "code" : "10065705"
      },
      {
        "code" : "10065706"
      },
      {
        "code" : "10065707"
      },
      {
        "code" : "10065709"
      },
      {
        "code" : "10065710"
      },
      {
        "code" : "10065712"
      },
      {
        "code" : "10065713"
      },
      {
        "code" : "10065719"
      },
      {
        "code" : "10065720"
      },
      {
        "code" : "10065721"
      },
      {
        "code" : "10065722"
      },
      {
        "code" : "10065727"
      },
      {
        "code" : "10065728"
      },
      {
        "code" : "10065730"
      },
      {
        "code" : "10065732"
      },
      {
        "code" : "10065735"
      },
      {
        "code" : "10065738"
      },
      {
        "code" : "10065744"
      },
      {
        "code" : "10065745"
      },
      {
        "code" : "10065746"
      },
      {
        "code" : "10065747"
      },
      {
        "code" : "10065748"
      },
      {
        "code" : "10065749"
      },
      {
        "code" : "10065752"
      },
      {
        "code" : "10065755"
      },
      {
        "code" : "10065759"
      },
      {
        "code" : "10065761"
      },
      {
        "code" : "10065762"
      },
      {
        "code" : "10065763"
      },
      {
        "code" : "10065764"
      },
      {
        "code" : "10065765"
      },
      {
        "code" : "10065766"
      },
      {
        "code" : "10065771"
      },
      {
        "code" : "10065772"
      },
      {
        "code" : "10065773"
      },
      {
        "code" : "10065775"
      },
      {
        "code" : "10065776"
      },
      {
        "code" : "10065777"
      },
      {
        "code" : "10065778"
      },
      {
        "code" : "10065779"
      },
      {
        "code" : "10065780"
      },
      {
        "code" : "10065781"
      },
      {
        "code" : "10065783"
      },
      {
        "code" : "10065784"
      },
      {
        "code" : "10065785"
      },
      {
        "code" : "10065786"
      },
      {
        "code" : "10065787"
      },
      {
        "code" : "10065788"
      },
      {
        "code" : "10065789"
      },
      {
        "code" : "10065790"
      },
      {
        "code" : "10065791"
      },
      {
        "code" : "10065793"
      },
      {
        "code" : "10065794"
      },
      {
        "code" : "10065795"
      },
      {
        "code" : "10065796"
      },
      {
        "code" : "10065798"
      },
      {
        "code" : "10065799"
      },
      {
        "code" : "10065800"
      },
      {
        "code" : "10065802"
      },
      {
        "code" : "10065803"
      },
      {
        "code" : "10065805"
      },
      {
        "code" : "10065811"
      },
      {
        "code" : "10065813"
      },
      {
        "code" : "10065814"
      },
      {
        "code" : "10065815"
      },
      {
        "code" : "10065817"
      },
      {
        "code" : "10065818"
      },
      {
        "code" : "10065822"
      },
      {
        "code" : "10065823"
      },
      {
        "code" : "10065825"
      },
      {
        "code" : "10065826"
      },
      {
        "code" : "10065827"
      },
      {
        "code" : "10065828"
      },
      {
        "code" : "10065829"
      },
      {
        "code" : "10065830"
      },
      {
        "code" : "10065831"
      },
      {
        "code" : "10065832"
      },
      {
        "code" : "10065834"
      },
      {
        "code" : "10065836"
      },
      {
        "code" : "10065837"
      },
      {
        "code" : "10065838"
      },
      {
        "code" : "10065840"
      },
      {
        "code" : "10065841"
      },
      {
        "code" : "10065842"
      },
      {
        "code" : "10065843"
      },
      {
        "code" : "10065844"
      },
      {
        "code" : "10065845"
      },
      {
        "code" : "10065846"
      },
      {
        "code" : "10065847"
      },
      {
        "code" : "10065848"
      },
      {
        "code" : "10065849"
      },
      {
        "code" : "10065851"
      },
      {
        "code" : "10065873"
      },
      {
        "code" : "10065879"
      },
      {
        "code" : "10065880"
      },
      {
        "code" : "10065881"
      },
      {
        "code" : "10065882"
      },
      {
        "code" : "10065883"
      },
      {
        "code" : "10065885"
      },
      {
        "code" : "10065886"
      },
      {
        "code" : "10065887"
      },
      {
        "code" : "10065888"
      },
      {
        "code" : "10065891"
      },
      {
        "code" : "10065892"
      },
      {
        "code" : "10065893"
      },
      {
        "code" : "10065894"
      },
      {
        "code" : "10065895"
      },
      {
        "code" : "10065897"
      },
      {
        "code" : "10065898"
      },
      {
        "code" : "10065900"
      },
      {
        "code" : "10065906"
      },
      {
        "code" : "10065928"
      },
      {
        "code" : "10065961"
      },
      {
        "code" : "10065973"
      },
      {
        "code" : "10066480"
      },
      {
        "code" : "10066874"
      },
      {
        "code" : "10069138"
      },
      {
        "code" : "10069339"
      },
      {
        "code" : "10069501"
      }]
    }]
  }
}

```
