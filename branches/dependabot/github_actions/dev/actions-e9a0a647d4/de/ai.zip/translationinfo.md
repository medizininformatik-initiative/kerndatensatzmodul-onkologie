# Hinweise zur Übersetzung - MII IG Kerndatensatz-Modul Onkologie v2027.0.0-ballot.1

* [**Inhaltsverzeichnis**](toc.md)
* **Hinweise zur Übersetzung**

## Hinweise zur Übersetzung

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

### Übersetzungsinformationen

Dieser Leitfaden ist **englischsprachig** (Standardsprache); **Deutsch** ist die Übersetzung. Englisch ist damit sowohl die Basis-Darstellung des Leitfadens als auch die `/en/`-Darstellung; über den Sprachumschalter oben rechts wechseln Sie zwischen `/en/` und `/de/`.

Übersetzte Seiten liegen unter `input/translations/de/pagecontent/` (gleicher Dateiname wie die englische Seite); Ressourcen-Übersetzungen als `.po`-Dateien unter `input/translations/de/`. Details: [`docs/recipes/add-translation.md`](https://github.com/medizininformatik-initiative/kerndatensatzmodul-onkologie/blob/main/docs/recipes/add-translation.md) in diesem Repository.

**Übersetzungsstand dieses Moduls:** Jede erzählende Seite dieses Leitfadens existiert in beiden Sprachen (englische Quelle, deutscher Spiegel — inklusive der Migrations-, TNM-, Therapieziele- und Forschenden-Seiten). Auf Artefaktebene tragen Profile, Extensions, ValueSets und CodeSysteme deutsche `short`-/`definition`-Übersetzungen über die Translation-RuleSets des Moduls; die ImplementationGuide-Ressource selbst ist über ihre `.po`-Datei übersetzt. Die deutsche Ausgabe ist damit inhaltlich vollständig; sprachlicher Feinschliff maschinell unterstützter Passagen wird als interne Review-Kommentare in den Quellen nachgehalten.

