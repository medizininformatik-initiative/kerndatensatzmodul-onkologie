# MII CM Onko Strahlentherapie Applikationsart SNOMED Mapping - MII IG Kerndatensatz-Modul Onkologie v2027.0.0-ballot.1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII CM Onko Strahlentherapie Applikationsart SNOMED Mapping**

## ConceptMap: MII CM Onko Strahlentherapie Applikationsart SNOMED Mapping (Experimentell) 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-strahlentherapie-applikationsart-sct | *Version*:2027.0.0-ballot.1 |
| Active Stand: 2026-11-04 | *Maschinenlesbarer Name*:MII CM Onko Strahlentherapie Applikationsart SCT Mapping |
| **Copyright/Rechtliches**: This material includes SNOMED Clinical Terms® (SNOMED CT®) which is used by permission of SNOMED International. All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. SNOMED and SNOMED CT are registered trademarks of SNOMED International. Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license. | |

 
Mapping Strahlentherapie Applikationsart Codes zu SNOMED-CT STATUS DIESER ZUORDNUNG: 2024 erstellt gegen SNOMED CT International 20240401; am 2026-11-04 gegen International 20261001 nachkuratiert (alle Zielkonzepte auf Aktivitaet geprueft, inaktivierte Ziele ersetzt, seit 2024 neu veroeffentlichte Konzepte fuer bisher unbesetzte Werte ergaenzt, Ober-/Unterkonzepte mit equivalence wider/narrower nachgetragen). Sie ist WEDER OFFIZIELL ENDORSED NOCH FINAL QUALITAETSGESICHERT - es handelt sich um einen projektseitigen Arbeitsstand, nicht um eine abgestimmte Referenz. Vor einer Nutzung in Produktivsystemen sind fachliche Pruefung und ein Abgleich gegen die eingesetzte SNOMED-Version erforderlich. 

Die verschiedenen Applikationsarten sind teilweise in Kombination aufgeführt und in dieser Form schwer in SNOMED abbildbar. Ebenso zeigt sich, dass manche spezialisierte Methodiken (wie PSMA-Therapie) nicht in SNOMED-CT abgebildet sind.

> Die vollständige Mapping-Tabelle wird unterhalb dieser Einleitung aus der ConceptMap generiert.



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "mii-cm-onko-strahlentherapie-applikationsart-sct",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-license",
      "valueCode" : "CC-BY-4.0"
    },
    {
      "extension" : [{
        "url" : "packageId",
        "valueId" : "de.medizininformatikinitiative.kerndatensatz.onkologie"
      },
      {
        "url" : "version",
        "valueString" : "2027.0.0-ballot.1"
      },
      {
        "url" : "uri",
        "valueUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/package-source"
    }],
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareableconceptmap",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishableconceptmap"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionPolicy",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes",
        "code" : "package",
        "display" : "Package"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-approvalDate",
    "valueDate" : "2026-09-15"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-topic",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
        "code" : "C3262"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-author",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "email",
        "value" : "thomas.debertshaeuser@charite.de"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-editor",
    "valueContactDetail" : {
      "name" : "Taskforce Core Data Set"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2027"
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-strahlentherapie-applikationsart-sct",
  "version" : "2027.0.0-ballot.1",
  "name" : "MII CM Onko Strahlentherapie Applikationsart SCT Mapping",
  "title" : "MII CM Onko Strahlentherapie Applikationsart SNOMED Mapping",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-11-04",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Mapping Strahlentherapie Applikationsart Codes zu SNOMED-CT STATUS DIESER ZUORDNUNG: 2024 erstellt gegen SNOMED CT International 20240401; am 2026-11-04 gegen International 20261001 nachkuratiert (alle Zielkonzepte auf Aktivitaet geprueft, inaktivierte Ziele ersetzt, seit 2024 neu veroeffentlichte Konzepte fuer bisher unbesetzte Werte ergaenzt, Ober-/Unterkonzepte mit equivalence wider/narrower nachgetragen). Sie ist WEDER OFFIZIELL ENDORSED NOCH FINAL QUALITAETSGESICHERT - es handelt sich um einen projektseitigen Arbeitsstand, nicht um eine abgestimmte Referenz. Vor einer Nutzung in Produktivsystemen sind fachliche Pruefung und ein Abgleich gegen die eingesetzte SNOMED-Version erforderlich.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "purpose" : "Technical mapping to transform oBDS-Data into SNOMED",
  "copyright" : "This material includes SNOMED Clinical Terms® (SNOMED CT®) which is used by permission of SNOMED International. All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. SNOMED and SNOMED CT are registered trademarks of SNOMED International. Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license.",
  "sourceUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/",
  "targetUri" : "http://snomed.info/sct/900000000000207008/version/20261001",
  "group" : [{
    "source" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-applikationsart",
    "target" : "http://snomed.info/sct",
    "targetVersion" : "http://snomed.info/sct/900000000000207008/version/20261001",
    "element" : [{
      "code" : "P",
      "display" : "perkutan (Teletherapie)",
      "target" : [{
        "code" : "33195004",
        "display" : "External beam radiation therapy procedure (procedure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "P-ST",
      "display" : "perkutan stereotaktisch",
      "target" : [{
        "code" : "395096001",
        "display" : "Stereotactic radiotherapy (procedure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "P-4D",
      "display" : "perkutan, atemgetriggert",
      "target" : [{
        "code" : "721061000124106",
        "display" : "External beam radiotherapy with respiratory gating (procedure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "P-ST4D",
      "display" : "perkutan, stereotaktisch, atemgetriggert",
      "target" : [{
        "code" : "721061000124106",
        "display" : "External beam radiotherapy with respiratory gating (procedure)",
        "equivalence" : "wider",
        "comment" : "ergaenzt 2026-11-04: stereotaktische Komponente (395096001) nicht abbildbar, nur Atemtriggerung"
      }]
    },
    {
      "code" : "PRCN-ST",
      "display" : "perkutan, stereotaktisch ohne Chemotherapie/Sensitizer",
      "target" : [{
        "code" : "395096001",
        "display" : "Stereotactic radiotherapy (procedure)",
        "equivalence" : "wider",
        "comment" : "ergaenzt 2026-11-04: Qualifikation ohne Chemotherapie/Sensitizer nicht abbildbar"
      }]
    },
    {
      "code" : "PRCN-4D",
      "display" : "perkutan, atemgetriggert, ohne Chemotherapie/Sensitizer",
      "target" : [{
        "code" : "721061000124106",
        "display" : "External beam radiotherapy with respiratory gating (procedure)",
        "equivalence" : "wider",
        "comment" : "ergaenzt 2026-11-04: Qualifikation ohne Chemotherapie/Sensitizer nicht abbildbar"
      }]
    },
    {
      "code" : "PRCN-ST4D",
      "display" : "perkutan, stereotaktisch, atemgetriggert, ohne Chemotherapie/Sensitizer",
      "target" : [{
        "code" : "721061000124106",
        "display" : "External beam radiotherapy with respiratory gating (procedure)",
        "equivalence" : "wider",
        "comment" : "ergaenzt 2026-11-04: stereotaktische Komponente (395096001) und Qualifikation ohne Chemotherapie/Sensitizer nicht abbildbar"
      }]
    },
    {
      "code" : "PRCJ",
      "display" : "perkutan mit Chemotherapie/Sensitizer",
      "target" : [{
        "code" : "703423002",
        "display" : "Combined chemotherapy and radiation therapy (procedure)",
        "equivalence" : "wider",
        "comment" : "ergaenzt 2026-11-04: Applikationsart perkutan (33195004) nicht enthalten"
      }]
    },
    {
      "code" : "PRCJ-4D",
      "display" : "perkutan, atemgetriggert, mit Chemotherapie/Sensitizer",
      "target" : [{
        "code" : "703423002",
        "display" : "Combined chemotherapy and radiation therapy (procedure)",
        "equivalence" : "wider",
        "comment" : "ergaenzt 2026-11-04: Applikationsart perkutan und Atemtriggerung (721061000124106) nicht enthalten"
      }]
    },
    {
      "code" : "K",
      "display" : "endokavitäre Kontakttherapie",
      "target" : [{
        "code" : "384692006",
        "display" : "Intracavitary brachytherapy (procedure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "KHDR",
      "display" : "endokavitäre Kontakttherapie, high dose rate therapy",
      "target" : [{
        "code" : "384692006",
        "display" : "Intracavitary brachytherapy (procedure)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "KLDR",
      "display" : "endokavitäre Kontakttherapie, low dose rate therapy",
      "target" : [{
        "code" : "384692006",
        "display" : "Intracavitary brachytherapy (procedure)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "KPDR",
      "display" : "endokavitäre Kontakttherapie, pulsed dose rate therapy",
      "target" : [{
        "code" : "384692006",
        "display" : "Intracavitary brachytherapy (procedure)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "I",
      "display" : "intersitielle Kontakttherapie",
      "target" : [{
        "code" : "113120007",
        "display" : "Interstitial brachytherapy (procedure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "IHDR",
      "display" : "intersitielle Kontakttherapie, high dose rate therapy",
      "target" : [{
        "code" : "113120007",
        "display" : "Interstitial brachytherapy (procedure)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "ILDR",
      "display" : "intersitielle Kontakttherapie, low dose rate therapy",
      "target" : [{
        "code" : "113120007",
        "display" : "Interstitial brachytherapy (procedure)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "IPDR",
      "display" : "intersitielle Kontakttherapie, pulsed dose rate therapy",
      "target" : [{
        "code" : "113120007",
        "display" : "Interstitial brachytherapy (procedure)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "MSIRT",
      "display" : "selektive interne Radio-Therapie",
      "target" : [{
        "code" : "722183007",
        "display" : "Embolization of hepatic artery using selective internal radiation therapy (procedure)",
        "equivalence" : "narrower",
        "comment" : "ergaenzt 2026-11-04: nur hepatische SIRT; allgemeines SIRT-Konzept fehlt"
      }]
    },
    {
      "code" : "MPRRT",
      "display" : "Peptid-Radio-Rezeptor-Therapie",
      "target" : [{
        "code" : "1103661000000108",
        "display" : "Radioligand therapy using lutetium (177-Lu) labeled somatostatin analog (procedure)",
        "equivalence" : "narrower",
        "comment" : "ergaenzt 2026-11-04: Konzept seit SNOMED CT International 20241001; Lu-177-spezifisch, PRRT mit Y-90 nicht erfasst; alternativ 1356887006 (NET, Lu-177-Dotatate, 20250201)"
      }]
    },
    {
      "code" : "MPSMA",
      "display" : "PSMA-Therapie",
      "target" : [{
        "code" : "1263784000",
        "display" : "Radioligand therapy using lutetium (177-Lu) vipivotide tetraxetan (procedure)",
        "equivalence" : "narrower",
        "comment" : "ergaenzt 2026-11-04: Konzept seit SNOMED CT International 20241001; Lu-177-spezifisch, Ac-225-PSMA nicht erfasst"
      }]
    },
    {
      "code" : "MRJT",
      "display" : "Radiojod-Therapie",
      "target" : [{
        "code" : "64291000052106",
        "display" : "Radioactive iodine therapy (procedure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "MRIT",
      "display" : "Radioimmun-Therapie",
      "target" : [{
        "code" : "118640001",
        "display" : "Radioimmunotherapy (procedure)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "M",
      "display" : "sonstige metabolische Radionuklidtherapie",
      "target" : [{
        "code" : "399315003",
        "display" : "Radionuclide therapy (procedure)",
        "equivalence" : "wider"
      }]
    },
    {
      "code" : "S",
      "display" : "Sonstiges",
      "target" : [{
        "code" : "74964007",
        "display" : "Other (qualifier value)",
        "equivalence" : "equivalent"
      }]
    }]
  }]
}

```
