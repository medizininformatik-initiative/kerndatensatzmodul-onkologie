# MII CM Onko Genetische Variante Auspraegung SNOMED Mapping - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII CM Onko Genetische Variante Auspraegung SNOMED Mapping**

## ConceptMap: MII CM Onko Genetische Variante Auspraegung SNOMED Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-genetische-variante-auspraegung-sct | *Version*:2026.0.3 |
| Active as of 2024-04-10 | *Computable Name*:MII CM Onko Genetische Variante Auspraegung SCT Mapping |

 
Mapping Therapieabweichung Codes zu SNOMED-CT 

 
Technical mapping to transform oBDS-Data into SNOMED 



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "mii-cm-onko-genetische-variante-auspraegung-sct",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-genetische-variante-auspraegung-sct",
  "version" : "2026.0.3",
  "name" : "MII CM Onko Genetische Variante Auspraegung SCT Mapping",
  "title" : "MII CM Onko Genetische Variante Auspraegung SNOMED Mapping",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-04-10",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Mapping Therapieabweichung Codes zu SNOMED-CT",
  "purpose" : "Technical mapping to transform oBDS-Data into SNOMED",
  "sourceUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/",
  "targetUri" : "http://snomed.info/sct/900000000000207008/version/20240401",
  "group" : [{
    "source" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-genetische-variante-auspraegung",
    "target" : "http://snomed.info/sct/900000000000207008/version/20240401",
    "element" : [{
      "code" : "M",
      "display" : "Mutation/positiv",
      "target" : [{
        "code" : "55446002",
        "display" : "Genetic mutation (finding)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "W",
      "display" : "Wildtyp/nicht mutiert/ negativ",
      "target" : [{
        "code" : "412730000",
        "display" : "Genetic finding not detected (finding)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "P",
      "display" : "Polymorphismus",
      "target" : [{
        "code" : "50334000",
        "display" : "Genetic polymorphism (finding)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "S",
      "display" : "Sonstiges",
      "target" : [{
        "code" : "74964007",
        "display" : "Other (qualifier value)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "N",
      "display" : "Nicht bestimmbar",
      "target" : [{
        "code" : "1156316003",
        "display" : "Cannot be determined (qualifier value)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "U",
      "display" : "Unbekannt",
      "target" : [{
        "code" : "261665006",
        "display" : "Unknown (qualifier value)",
        "equivalence" : "equivalent"
      }]
    }]
  }]
}

```
