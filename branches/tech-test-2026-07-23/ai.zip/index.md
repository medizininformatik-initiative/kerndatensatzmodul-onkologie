# Home - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ImplementationGuide/mii-ig-onko-de-v2026 | *Version*:2026.0.3 |
| Active as of 2026-07-23 | *Computable Name*:MII_IG_Onko_DE |

# MII IG Modul Onkologie

Feel free to modify this index page with your own awesome content!

