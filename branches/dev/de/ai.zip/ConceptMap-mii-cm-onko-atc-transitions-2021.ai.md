# MII CM Onko ATC Code Changes 2020 to 2021 - MII IG Kerndatensatz-Modul Onkologie v2027.0.0-ballot.rc3

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII CM Onko ATC Code Changes 2020 to 2021**

## ConceptMap: MII CM Onko ATC Code Changes 2020 to 2021 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-atc-transitions-2021 | *Version*:2027.0.0-ballot.rc3 |
| Active Stand: 2024-12-12 | *Maschinenlesbarer Name*:MII_CM_Onko_ATC_Transitions_2021 |

 
Diese ConceptMap dokumentiert ausschließlich die ATC-Code-Änderungen von 2020 zu 2021. Im Jahr 2021 erfolgte eine umfassende Reorganisation der ATC-Klassifikation für onkologische Substanzen mit Umkodierung von über 60 Wirkstoffen. 



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "mii-cm-onko-atc-transitions-2021",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-license",
      "valueCode" : "CC-BY-4.0"
    },
    {
      "extension" : [{
        "url" : "packageId",
        "valueId" : "de.medizininformatikinitiative.kerndatensatz.onkologie"
      },
      {
        "url" : "version",
        "valueString" : "2027.0.0-ballot.rc3"
      },
      {
        "url" : "uri",
        "valueUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/package-source"
    }],
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareableconceptmap",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishableconceptmap"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionPolicy",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes",
        "code" : "package",
        "display" : "Package"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-approvalDate",
    "valueDate" : "2026-09-15"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-topic",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
        "code" : "C3262"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-author",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "email",
        "value" : "thomas.debertshaeuser@charite.de"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-editor",
    "valueContactDetail" : {
      "name" : "Taskforce Core Data Set"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2027"
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-atc-transitions-2021",
  "version" : "2027.0.0-ballot.rc3",
  "name" : "MII_CM_Onko_ATC_Transitions_2021",
  "title" : "MII CM Onko ATC Code Changes 2020 to 2021",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-12-12",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Diese ConceptMap dokumentiert ausschließlich die ATC-Code-Änderungen von 2020 zu 2021. Im Jahr 2021 erfolgte eine umfassende Reorganisation der ATC-Klassifikation für onkologische Substanzen mit Umkodierung von über 60 Wirkstoffen.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "purpose" : "Migration von ATC-Codes für Substanzen, die 2021 umkodiert wurden. Enthält nur geänderte Codes, keine neuen oder unveränderten Einträge.",
  "sourceCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-systemische-therapie-substanzen-2020",
  "targetCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-systemische-therapie-substanzen-2021",
  "group" : [{
    "source" : "http://fhir.de/CodeSystem/bfarm/atc",
    "target" : "http://fhir.de/CodeSystem/bfarm/atc",
    "element" : [{
      "code" : "L01XE01",
      "display" : "Imatinib",
      "target" : [{
        "code" : "L01EA01",
        "display" : "Imatinib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu BCR-ABL Tyrosinkinase-Inhibitoren"
      }]
    },
    {
      "code" : "L01XE06",
      "display" : "Dasatinib",
      "target" : [{
        "code" : "L01EA02",
        "display" : "Dasatinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE08",
      "display" : "Nilotinib",
      "target" : [{
        "code" : "L01EA03",
        "display" : "Nilotinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE14",
      "display" : "Bosutinib",
      "target" : [{
        "code" : "L01EA04",
        "display" : "Bosutinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE24",
      "display" : "Ponatinib",
      "target" : [{
        "code" : "L01EA05",
        "display" : "Ponatinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE02",
      "display" : "Gefitinib",
      "target" : [{
        "code" : "L01EB01",
        "display" : "Gefitinib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu EGFR Tyrosinkinase-Inhibitoren"
      }]
    },
    {
      "code" : "L01XE03",
      "display" : "Erlotinib",
      "target" : [{
        "code" : "L01EB02",
        "display" : "Erlotinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE13",
      "display" : "Afatinib",
      "target" : [{
        "code" : "L01EB03",
        "display" : "Afatinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE35",
      "display" : "Osimertinib",
      "target" : [{
        "code" : "L01EB04",
        "display" : "Osimertinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE15",
      "display" : "Vemurafenib",
      "target" : [{
        "code" : "L01EC01",
        "display" : "Vemurafenib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu BRAF-Inhibitoren"
      }]
    },
    {
      "code" : "L01XE23",
      "display" : "Dabrafenib",
      "target" : [{
        "code" : "L01EC02",
        "display" : "Dabrafenib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE46",
      "display" : "Encorafenib",
      "target" : [{
        "code" : "L01EC03",
        "display" : "Encorafenib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE16",
      "display" : "Crizotinib",
      "target" : [{
        "code" : "L01ED01",
        "display" : "Crizotinib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu ALK-Inhibitoren"
      }]
    },
    {
      "code" : "L01XE28",
      "display" : "Ceritinib",
      "target" : [{
        "code" : "L01ED02",
        "display" : "Ceritinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE36",
      "display" : "Alectinib",
      "target" : [{
        "code" : "L01ED03",
        "display" : "Alectinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE43",
      "display" : "Brigatinib",
      "target" : [{
        "code" : "L01ED04",
        "display" : "Brigatinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE44",
      "display" : "Lorlatinib",
      "target" : [{
        "code" : "L01ED05",
        "display" : "Lorlatinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE25",
      "display" : "Trametinib",
      "target" : [{
        "code" : "L01EE01",
        "display" : "Trametinib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu MEK-Inhibitoren"
      }]
    },
    {
      "code" : "L01XE38",
      "display" : "Cobimetinib",
      "target" : [{
        "code" : "L01EE02",
        "display" : "Cobimetinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE41",
      "display" : "Binimetinib",
      "target" : [{
        "code" : "L01EE03",
        "display" : "Binimetinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE33",
      "display" : "Palbociclib",
      "target" : [{
        "code" : "L01EF01",
        "display" : "Palbociclib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu CDK4/6-Inhibitoren"
      }]
    },
    {
      "code" : "L01XE42",
      "display" : "Ribociclib",
      "target" : [{
        "code" : "L01EF02",
        "display" : "Ribociclib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE50",
      "display" : "Abemaciclib",
      "target" : [{
        "code" : "L01EF03",
        "display" : "Abemaciclib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE09",
      "display" : "Temsirolimus",
      "target" : [{
        "code" : "L01EG01",
        "display" : "Temsirolimus",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu mTOR-Inhibitoren"
      }]
    },
    {
      "code" : "L01XE10",
      "display" : "Everolimus",
      "target" : [{
        "code" : "L01EG02",
        "display" : "Everolimus",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE07",
      "display" : "Lapatinib",
      "target" : [{
        "code" : "L01EH01",
        "display" : "Lapatinib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu HER2-Inhibitoren"
      }]
    },
    {
      "code" : "L01XE45",
      "display" : "Neratinib",
      "target" : [{
        "code" : "L01EH02",
        "display" : "Neratinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE18",
      "display" : "Ruxolitinib",
      "target" : [{
        "code" : "L01EJ01",
        "display" : "Ruxolitinib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu JAK-Inhibitoren"
      }]
    },
    {
      "code" : "L01XE17",
      "display" : "Axitinib",
      "target" : [{
        "code" : "L01EK01",
        "display" : "Axitinib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu VEGFR-Inhibitoren"
      }]
    },
    {
      "code" : "L01XE34",
      "display" : "Tivozanib",
      "target" : [{
        "code" : "L01EK03",
        "display" : "Tivozanib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE27",
      "display" : "Ibrutinib",
      "target" : [{
        "code" : "L01EL01",
        "display" : "Ibrutinib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu BTK-Inhibitoren"
      }]
    },
    {
      "code" : "L01XE51",
      "display" : "Acalabrutinib",
      "target" : [{
        "code" : "L01EL02",
        "display" : "Acalabrutinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XX47",
      "display" : "Idelalisib",
      "target" : [{
        "code" : "L01EM01",
        "display" : "Idelalisib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu PI3K-Inhibitoren"
      }]
    },
    {
      "code" : "L01XX61",
      "display" : "Copanlisib",
      "target" : [{
        "code" : "L01EM02",
        "display" : "Copanlisib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE04",
      "display" : "Sunitinib",
      "target" : [{
        "code" : "L01EX01",
        "display" : "Sunitinib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu andere Proteinkinase-Inhibitoren"
      }]
    },
    {
      "code" : "L01XE05",
      "display" : "Sorafenib",
      "target" : [{
        "code" : "L01EX02",
        "display" : "Sorafenib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE12",
      "display" : "Vandetanib",
      "target" : [{
        "code" : "L01EX04",
        "display" : "Vandetanib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE21",
      "display" : "Regorafenib",
      "target" : [{
        "code" : "L01EX05",
        "display" : "Regorafenib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE26",
      "display" : "Cabozantinib",
      "target" : [{
        "code" : "L01EX07",
        "display" : "Cabozantinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE29",
      "display" : "Lenvatinib",
      "target" : [{
        "code" : "L01EX08",
        "display" : "Lenvatinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE31",
      "display" : "Nintedanib",
      "target" : [{
        "code" : "L01EX09",
        "display" : "Nintedanib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE39",
      "display" : "Midostaurin",
      "target" : [{
        "code" : "L01EX10",
        "display" : "Midostaurin",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE52",
      "display" : "Quizartinib",
      "target" : [{
        "code" : "L01EX11",
        "display" : "Quizartinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE53",
      "display" : "Larotrectinib",
      "target" : [{
        "code" : "L01EX12",
        "display" : "Larotrectinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XE54",
      "display" : "Gilteritinib",
      "target" : [{
        "code" : "L01EX13",
        "display" : "Gilteritinib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XX14",
      "display" : "Tretinoin",
      "target" : [{
        "code" : "L01XF01",
        "display" : "Tretinoin",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu Retinoide"
      }]
    },
    {
      "code" : "L01XX22",
      "display" : "Alitretinoin",
      "target" : [{
        "code" : "L01XF02",
        "display" : "Alitretinoin",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XX25",
      "display" : "Bexaroten",
      "target" : [{
        "code" : "L01XF03",
        "display" : "Bexaroten",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XX32",
      "display" : "Bortezomib",
      "target" : [{
        "code" : "L01XG01",
        "display" : "Bortezomib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu Proteasom-Inhibitoren"
      }]
    },
    {
      "code" : "L01XX45",
      "display" : "Carfilzomib",
      "target" : [{
        "code" : "L01XG02",
        "display" : "Carfilzomib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XX50",
      "display" : "Ixazomib",
      "target" : [{
        "code" : "L01XG03",
        "display" : "Ixazomib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XX38",
      "display" : "Vorinostat",
      "target" : [{
        "code" : "L01XH01",
        "display" : "Vorinostat",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu Histon-Deacetylase-Inhibitoren"
      }]
    },
    {
      "code" : "L01XX39",
      "display" : "Romidepsin",
      "target" : [{
        "code" : "L01XH02",
        "display" : "Romidepsin",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XX42",
      "display" : "Panobinostat",
      "target" : [{
        "code" : "L01XH03",
        "display" : "Panobinostat",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XX49",
      "display" : "Belinostat",
      "target" : [{
        "code" : "L01XH04",
        "display" : "Belinostat",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XX43",
      "display" : "Vismodegib",
      "target" : [{
        "code" : "L01XJ01",
        "display" : "Vismodegib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu Hedgehog-Signalweg-Inhibitoren"
      }]
    },
    {
      "code" : "L01XX63",
      "display" : "Glasdegib",
      "target" : [{
        "code" : "L01XJ03",
        "display" : "Glasdegib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XX46",
      "display" : "Olaparib",
      "target" : [{
        "code" : "L01XK01",
        "display" : "Olaparib",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu PARP-Inhibitoren"
      }]
    },
    {
      "code" : "L01XX54",
      "display" : "Niraparib",
      "target" : [{
        "code" : "L01XK02",
        "display" : "Niraparib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XX60",
      "display" : "Talazoparib",
      "target" : [{
        "code" : "L01XK04",
        "display" : "Talazoparib",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "L01XX17",
      "display" : "Topotecan",
      "target" : [{
        "code" : "L01CE01",
        "display" : "Topotecan",
        "equivalence" : "equivalent",
        "comment" : "Reklassifizierung zu Topoisomerase-I-Inhibitoren"
      }]
    },
    {
      "code" : "L01XX19",
      "display" : "Irinotecan",
      "target" : [{
        "code" : "L01CE02",
        "display" : "Irinotecan",
        "equivalence" : "equivalent"
      }]
    }]
  }]
}

```
