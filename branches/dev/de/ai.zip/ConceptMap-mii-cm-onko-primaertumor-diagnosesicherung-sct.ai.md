# MII CM Onko Primaertumor Diagnosesicherung SNOMED Mapping - MII IG Kerndatensatz-Modul Onkologie v2027.0.0-ballot.rc2

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII CM Onko Primaertumor Diagnosesicherung SNOMED Mapping**

## ConceptMap: MII CM Onko Primaertumor Diagnosesicherung SNOMED Mapping (Experimentell) 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-primaertumor-diagnosesicherung-sct | *Version*:2027.0.0-ballot.rc2 |
| Active Stand: 2024-04-10 | *Maschinenlesbarer Name*:MII CM Onko Primaertumor Diagnosesicherung SCT Mapping |
| **Copyright/Rechtliches**: This material includes SNOMED Clinical Terms® (SNOMED CT®) which is used by permission of SNOMED International. All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. SNOMED and SNOMED CT are registered trademarks of SNOMED International. Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license. | |

 
Mapping Primärtumor Diagnosesicherung Codes zu SNOMED-CT STATUS DIESER ZUORDNUNG: 2024 erstellt, gegen SNOMED CT International 20240401. Sie ist WEDER OFFIZIELL ENDORSED NOCH FINAL QUALITAETSGESICHERT - es handelt sich um einen projektseitigen Arbeitsstand, nicht um eine abgestimmte Referenz. Die Zielcodes sind gegen neuere SNOMED-Releases nicht nachverifiziert; einzelne Konzepte koennen inzwischen inaktiviert oder ersetzt sein. Vor einer Nutzung in Produktivsystemen sind fachliche Pruefung und ein Abgleich gegen die eingesetzte SNOMED-Version erforderlich. 

Die Angabe der Diagnosesicherung ist durch die letzten Änderungen leicht redundant. Die Angaben zur klinischen Diagnostik können genauer spezifiziert werden.

> Die vollständige Mapping-Tabelle wird unterhalb dieser Einleitung aus der ConceptMap generiert.



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "mii-cm-onko-primaertumor-diagnosesicherung-sct",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-license",
      "valueCode" : "CC-BY-4.0"
    },
    {
      "extension" : [{
        "url" : "packageId",
        "valueId" : "de.medizininformatikinitiative.kerndatensatz.onkologie"
      },
      {
        "url" : "version",
        "valueString" : "2027.0.0-ballot.rc2"
      },
      {
        "url" : "uri",
        "valueUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/package-source"
    }],
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareableconceptmap",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishableconceptmap"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionPolicy",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes",
        "code" : "package",
        "display" : "Package"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-approvalDate",
    "valueDate" : "2026-09-15"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-topic",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
        "code" : "C3262"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-author",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "email",
        "value" : "thomas.debertshaeuser@charite.de"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-editor",
    "valueContactDetail" : {
      "name" : "Taskforce Core Data Set"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2027"
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-primaertumor-diagnosesicherung-sct",
  "version" : "2027.0.0-ballot.rc2",
  "name" : "MII CM Onko Primaertumor Diagnosesicherung SCT Mapping",
  "title" : "MII CM Onko Primaertumor Diagnosesicherung SNOMED Mapping",
  "status" : "active",
  "experimental" : true,
  "date" : "2024-04-10",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Mapping Primärtumor Diagnosesicherung Codes zu SNOMED-CT STATUS DIESER ZUORDNUNG: 2024 erstellt, gegen SNOMED CT International 20240401. Sie ist WEDER OFFIZIELL ENDORSED NOCH FINAL QUALITAETSGESICHERT - es handelt sich um einen projektseitigen Arbeitsstand, nicht um eine abgestimmte Referenz. Die Zielcodes sind gegen neuere SNOMED-Releases nicht nachverifiziert; einzelne Konzepte koennen inzwischen inaktiviert oder ersetzt sein. Vor einer Nutzung in Produktivsystemen sind fachliche Pruefung und ein Abgleich gegen die eingesetzte SNOMED-Version erforderlich.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "purpose" : "Technical mapping to transform oBDS-Data into SNOMED",
  "copyright" : "This material includes SNOMED Clinical Terms® (SNOMED CT®) which is used by permission of SNOMED International. All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. SNOMED and SNOMED CT are registered trademarks of SNOMED International. Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license.",
  "sourceUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/",
  "targetUri" : "http://snomed.info/sct/900000000000207008/version/20240401",
  "group" : [{
    "source" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung",
    "target" : "http://snomed.info/sct/900000000000207008/version/20240401",
    "element" : [{
      "code" : "1",
      "display" : "klinisch",
      "target" : [{
        "code" : "373795004",
        "display" : "Cancer diagnosis based on clinical evidence (finding)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "2",
      "display" : "klinische Diagnostik",
      "target" : [{
        "code" : "373796003",
        "display" : "Cancer diagnosis based on investigations, without a tissue diagnosis (finding)",
        "equivalence" : "equivalent",
        "comment" : "übergreifender Begriff, gültig für alle diagnostischen Mittel"
      }]
    },
    {
      "target" : [{
        "code" : "363680008",
        "display" : "Radiographic imaging procedure (procedure)",
        "equivalence" : "narrower",
        "comment" : "Röntgen als Spezifizierung"
      }]
    },
    {
      "target" : [{
        "code" : "423827005",
        "display" : "Endoscopy (procedure)",
        "equivalence" : "narrower",
        "comment" : "Endoskopie als Spezifizierung"
      }]
    },
    {
      "target" : [{
        "code" : "363679005",
        "display" : "Imaging (procedure)",
        "equivalence" : "narrower",
        "comment" : "Imaging als Spezifizierung"
      }]
    },
    {
      "target" : [{
        "code" : "16310003",
        "display" : "Ultrasonography (procedure)",
        "equivalence" : "narrower",
        "comment" : "Ultraschall als Spezifizierung"
      }]
    },
    {
      "target" : [{
        "code" : "122458006",
        "display" : "Exploration procedure (procedure)",
        "equivalence" : "narrower",
        "comment" : "Explorativer Eingriff als Spezifizierung"
      }]
    },
    {
      "code" : "4",
      "display" : "spezifische Tumor-Marker",
      "target" : [{
        "code" : "373797007",
        "display" : "Cancer diagnosis based on specific tumor markers (finding)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "5",
      "display" : "Zytologie",
      "target" : [{
        "code" : "373798002",
        "display" : "Cancer diagnosis based on cytological evidence (finding)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "6",
      "display" : "histologische Untersuchung einer Metastase",
      "target" : [{
        "code" : "373799005",
        "display" : "Cancer diagnosis based on metastatic histological evidence (finding)",
        "equivalence" : "equivalent",
        "comment" : "Auswahlmöglichkeit veraltet, entspricht 7.2"
      }]
    },
    {
      "code" : "7",
      "display" : "histologische Untersuchung eines Primärtumors",
      "target" : [{
        "code" : "373800009",
        "display" : "Cancer diagnosis based on primary site histological evidence (finding)",
        "equivalence" : "equivalent",
        "comment" : "Auswahlmöglichkeit veraltet, entspricht 7.1"
      }]
    },
    {
      "code" : "7.1",
      "display" : "histologische Untersuchung eines Primärtumors",
      "target" : [{
        "code" : "373800009",
        "display" : "Cancer diagnosis based on primary site histological evidence (finding)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "7.2",
      "display" : "histologische Untersuchung einer Metastase",
      "target" : [{
        "code" : "373799005",
        "display" : "Cancer diagnosis based on metastatic histological evidence (finding)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "7.3",
      "display" : "histologische Untersuchung des Gewebes bei Autopsie",
      "target" : [{
        "equivalence" : "unmatched",
        "comment" : "keine direktes Mapping möglich, ggfs. über Postkoordination mit Autopsie -Prozedur"
      }]
    },
    {
      "code" : "8",
      "display" : "Zytogenetisch und/oder molekularer Test",
      "target" : [{
        "code" : "394804000",
        "display" : "Clinical cytogenetics and molecular genetics (qualifier value)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "9",
      "display" : "unbekannt",
      "target" : [{
        "code" : "261665006",
        "display" : "Unknown (qualifier value)",
        "equivalence" : "equivalent"
      }]
    }]
  }]
}

```
