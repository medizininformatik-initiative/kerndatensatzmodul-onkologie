# Downloads - MII IG Kerndatensatz-Modul Onkologie v2027.0.0-ballot.rc3

* [**Inhaltsverzeichnis**](toc.md)
* **Downloads**

## Downloads

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

Diese Seite verlinkt die herunterladbaren Artefakte des Moduls **Onkologie**.

#### Paketdatei

Die Paketdatei ist ein FHIR-Paket im NPM-Format, wie es die meisten FHIR-Werkzeuge verwenden. Sie enthält alle ValueSets, Profile, Extensions sowie die Liste der Seiten und URLs dieses Leitfadens in dieser Version. Sie SOLLTE die erste Wahl sein, wann immer Implementierungsartefakte erzeugt werden, denn sie trägt alle Regeln, die die Profile gültig machen. Implementierende müssen darüber hinaus den Inhalt der Spezifikation und die einschlägigen Profile kennen, um eine konforme Umsetzung zu bauen — siehe die FHIR-Dokumentation zur [Validierung von Profilen und Ressourcen](http://hl7.org/fhir/R4/validation.html).

* [Paket (komprimierter Ordner)](../package.tgz)

#### Herunterladbare Kopie dieses Leitfadens

Eine herunterladbare Fassung des gerenderten Leitfadens für den lokalen Betrieb:

* [Herunterladbare Kopie (komprimierter Ordner)](../full-ig.zip) — **nur CI-Builds und Previews**: In formalen Publikationen überschreitet dieses Archiv GitHubs 100-MB-Dateigrenze und wird daher nicht ausgeliefert; nutzen Sie das [Package](../package.tgz) oder die publizierte Site direkt.

#### Beispiele

Alle Beispiele dieses Leitfadens:

* [XML (komprimierter Ordner)](../examples.xml.zip)
* [JSON (komprimierter Ordner)](../examples.json.zip)

#### Konsolidierte CSV- und Excel-Darstellungen der Profile

Die Profilinformationen des gesamten Leitfadens in einer einzigen CSV- oder Excel-Datei — nützlich für Testende und Analysierende, die Element-Eigenschaften profilübergreifend in einer Tabelle sichten wollen:

* [CSV (komprimierter Ordner)](../csvs.zip)
* [Excel (komprimierter Ordner)](../excels.zip)

#### Schematrons

* [Schematrons (komprimierter Ordner)](../schematrons.zip)

#### ImplementationGuide-Ressource

Die `ImplementationGuide`-Ressource trägt die technischen Details dieser Veröffentlichung einschließlich ihrer Abhängigkeiten und Veröffentlichungsparameter.

Mit Abhängigkeiten und Publikationsparametern gerendert auf der Seite [Abhängigkeiten](ImplementationGuide-mii-ig-onko-de.md); Rohform: [XML](../ImplementationGuide-mii-ig-onko-de.xml) · [JSON](../ImplementationGuide-mii-ig-onko-de.json).

#### Versionshistorie

Frühere Versionen und die ausführliche Änderungshistorie stehen auf den Seiten [Versionierung](version-history.md) und [Änderungshistorie](changes.md).

