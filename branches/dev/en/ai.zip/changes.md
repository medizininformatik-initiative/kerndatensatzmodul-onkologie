# Changelog - MII IG Kerndatensatz-Modul Onkologie v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* **Changelog**

## Changelog

All changes to this module are listed here. The complete, detailed release history is maintained in the German edition of this page; the current release cycle is translated in full below.

### Changes since v2027.0.0-ballot.1 (unreleased)

#### Further Improvements

* **oBDS→SNOMED CT concept maps re-curated against SNOMED CT International 20261001 (5 maps)**: TNM clinical and pathological, surgical complications, radiotherapy application mode, end of therapy. All 318 target concepts verified active; 51 previously unmatched values now have a target: 28 via concepts released since 2024 (UICC L0–LX and V0–VX since 20251101, Pn0–PnX since 20260201, c/p prefix since 20260601, cN1mi since 20250101; bronchial stump fistula 1366730005 since 20250601; PRRT and PSMA radioligand therapy as Lu-177 concepts since 20241001) and 23 via pre-existing broader or narrower concepts with `wider`/`narrower` (serum markers S0–SX as finding concepts, anastomotic and suture dehiscence, stoma disorder, peripheral paresis, combined external-beam application modes, SIRT, change of medication, discontinuation due to adverse effects). Still `unmatched`, each with a reason in `comment`: the count values 2–10 of the m suffix (not a terminology concept; belongs in a numeric element), the markers i±/mol±/sn (available in SNOMED CT only pre-coordinated as category values such as pN0(i+)), u prefix, Tis(pu)/Tis(pd), MX, pM0, pT3e, stage X, Tb-161, involved node/field, R1(is)/R1(cy+) and the registry-specific reasons for end of therapy. Provenance of the five maps now in `group.targetVersion` (20261001) instead of a versioned URI in `group.target`; `description` and `date` updated.
* `fix` **Two inactivated SNOMED CT targets in the surgical-complication map replaced**: 19220005 “Complication of implant” → 1354666001 “Disorder associated with implant” (SAME AS; values KIM, SKI) and 1162567000 “Postoperative paralytic ileus” → 235833007 “Postoperative ileus” (REPLACED BY, `wider`; value PDA). In the application-mode map the display of 113120007 corrected to the FSN “Interstitial brachytherapy” (the code was right, the display said “Intracavitary”).
* `documentation` **ICD-O-4 described on the page [ICD-O Terminology](icd-o-terminologie.md)**: analysis of the IARC tables of 16 July 2026 — five-character, alphanumeric morphology codes (`XXXXY/B`, fifth character `0`–`9` and `A`–`K`), change table against ICD-O-3.2 (109 new stem/behaviour combinations, 1,175 new sub-codes, 29 deleted codes, 19 stem changes, 24 behaviour changes, 935 term changes), transition rule 3.2 → 4 with the 38 codes that cannot be transitioned by appending `0`, optional four-digit topography, consequences for the oBDS XSD and the FHIR artefacts. No ICD-O-4 artefacts, since the German BfArM edition is still pending; adoption in the oBDS is expected only with oBDS 4.0.

### Changes v2027.0.0-ballot.1 (ballot, dependency patch)

* **`kerndatensatz.molgen` raised to `2027.0.0-ballot.1`**: molgen's own dependency-hygiene patch (its ballot still pulled meta rc3 / base rc1 / biobank rc2 transitively; no structural changes — all StructureDefinitions verified identical). The dependency tree of this module is now uniformly on the plain ballot line. No content changes in this module.

### Changes v2027.0.0-ballot (ballot)

* **`kerndatensatz.studie` removed as a hard dependency**: no artefact of this module references a studie canonical — the study-participation profile binds `focus[studie]` to plain `Reference(ResearchStudy)`, with the SHOULD-recommendation to `MII_PR_Studie_Studie` documented in the element definition. studie is the last module still on an rc; without the pin it no longer gates this ballot line.
* **`BREAKING`** **Canonical URLs aligned with the naming convention (10 artefacts)**: seven therapy ValueSets gained the missing `onko-` segment, three logical models lost the Simplifier-era `…/LogicalModel/<Name>` path — complete old→new table and migration guidance in [Migration from v2026](migration-v2026.md), entry 10. Instances are unaffected (they never carry these canonicals); profile bindings follow automatically.
* **Dependencies completed on the 2027 ballot line**: `kerndatensatz.meta`, `.base`, `.biobank`, `.medikation` and `.molgen` now at plain `2027.0.0-ballot`; `kerndatensatz.laborbefund` also at plain `2027.0.0-ballot`. Pre-checked for snapshot/slicing compatibility.
* **SNOMED CT expansion pin raised to International 20260701** (expansion manifest, `$sct` alias, CalVer table): all 166 pin-relevant codes verified active, 19 filter roots expand loss-free, versioned `$lookup`/`$expand` confirmed on the MII terminology server. ConceptMap `targetVersion` deliberately keeps its curation provenance.
* **CRMI governance metadata on the ballot cadence**: `approvalDate` 2026-09-15 and `effectivePeriod` 2027 across all ~330 artifacts (rulesets, Library, IG resource); the genetic-variant profile now carries both topics (Neoplasm C3262 + Genetics C17457); the URL-keyed profile variant completed (license/package-source, versionAlgorithm, effectivePeriod, experimental).
* `fix` **QA slicing groups resolved**: Gleason score/grade-group discriminators (explicit `.system` values), study-participation `focus[studie]` reduced to one resolve() target type, mandatory slices completed in the FOLFOX and tumour-marker examples (12+3+5 QA errors).
* `fix` Known issue documented: the SU terminology server does not host the historical ATC year editions 2018–2026, so the yearly substance ValueSets currently produce non-actionable QA errors (`bfarm/atc version YYYY`).
* **New pages**: [Therapy Goals](therapieziele.md) (relationship to the BIH-CEI Therapieziele specification) and the completed [Guidance for Researchers](researcher-guidance.md) (registry reporting lag, cross-site incompleteness); all template TODO boxes removed (security & privacy, translation info, version history, downloads).
* `chore` IG resource id renamed `mii-ig-onko-de-v2026` → `mii-ig-onko-de` (version lives in the version field); package id and module canonical unchanged.

### Changes v2027.0.0-ballot.rc2 (ballot candidate)

#### ⚠️ Breaking Changes

These changes may require adjustments in existing implementations. Each entry is explained individually on the [Migration from v2026](migration-v2026.md) page — with its effect on stored data, its effect on implementations, and a concrete migration path:

* **`BREAKING`** **UICC prefixes y, r and a as modifierExtension at category level**: The prefixes are no longer carried inside the category value but are represented on the respective T, N or M observation via the new extensions `mii-ex-onko-tnm-y-praefix`, `mii-ex-onko-tnm-r-praefix` and `mii-ex-onko-tnm-a-praefix`. 
* **Why modifierExtension**: The prefixes change the interpretation of the category value — `ypT2` (assessment during or after initial multimodal therapy) is **not** the same as `pT2`. Processing systems MUST know these extensions and must not interpret a category without evaluating the prefix.
* **Distinction**: The c/p/u prefix remains a regular extension `mii-ex-onko-tnm-cp-praefix` on `Observation.code` (it names the method of assessment, not a different interpretation).
 
* **`BREAKING`** **Karnofsky/ECOG LOINC ConceptMaps corrected** (GH #269): The previous target codes were systematically wrong (Karnofsky shifted by ten LA numbers, ECOG with wrong check digits). Systems that adopted the old LA codes from the ConceptMaps must correct their data. In addition, the performance-status profiles now bind `valueCodeableConcept.coding[loinc]` required to new enumerated answer value sets (≙ LL4986-7 and LL529-9, GH #236).
* **`BREAKING`** **Oncology flag on the diagnosis is now mandatory**: `Condition.category` carries a new required slice `onkologie` (1..1) with SNOMED CT `55342001` "Neoplastic disease" on the primary-tumour and prior-tumour profiles, making oncological diagnoses discoverable via `Condition?category=…|55342001`. Existing instances without this category become invalid; the extensible core binding (problem-list-item / encounter-diagnosis) is unaffected.
* **`BREAKING`** **Gleason profiles: `code.coding` is sliced** (GH #259): SNOMED CT is mandatory (1..1), LOINC optional as a secondary coding (0..1) — for grade group, total score and pattern. Verified LOINC codes: `94734-1`, `35266-6`, `44641-9`/`44642-7`/`44643-5`.
* **`BREAKING`** **CTCAE catalogue version moved out of the MedDRA coding** (oBDS 15.3): the version is no longer written to `AdverseEvent.event.coding[meddra].version` but to the new extension `mii-ex-onko-nebenwirkung-ctcae-version`, bound required to the oBDS enumeration (`4`, `4.03`, `5.0`, `Sonstige`, new code system `mii-cs-onko-nebenwirkung-ctcae-version`). Reason: `coding.version` denotes the version of the code system the code was drawn from — that is MedDRA (CTCAE v4.03 is built on MedDRA v12.0), not CTCAE. The conflation made codes unresolvable against the value set. Systems that read the CTCAE version from `coding.version` must be adjusted.
* **`BREAKING`** **Reference types hardened**: previously generic references are now restricted to the clinically valid profiles — `Verlauf.hasMember`, `AdverseEvent.suspectEntity.instance`, `Condition.extension:dueTo.valueReference`, `Residualstatus.partOf`, `TNM-synthesised.device` and `Tumorkonferenz.activity[extended].reference`. Instances with other target types become invalid.
* **`BREAKING`** **TNM symbol profiles deprecated**: `mii-pr-onko-tnm-y-symbol`, `-r-symbol`, `-a-symbol` and `-m-symbol` are `retired`. The y/r/a prefixes are carried as `modifierExtension` on the category profiles, the m suffix as the new `component[multipleTumoren]` on the T category (component code LOINC `42030-7`, value still from the UICC code system). Legacy data remains readable; new implementations should use the extensions and the component.
* **`BREAKING`** **Legacy artefacts removed**: the commented-out radiotherapy "alt" family and the never-activated ECOG/Karnofsky quantity profiles.
* **`BREAKING`** **Dependencies moved to the 2027 ballot line**: `kerndatensatz.meta` 2027.0.0-ballot.rc3, `kerndatensatz.base` 2027.0.0-ballot.rc1, `de.basisprofil.r4` 1.6.0, `kerndatensatz.biobank` and `kerndatensatz.molgen` 2027.0.0-ballot.rc2 each, `kerndatensatz.studie` 2027.0.0-ballot.rc1, `kerndatensatz.medikation` 2027.0.0-ballot.rc5. Newly added: `kerndatensatz.laborbefund` 2027.0.0-ballot.rc3 (for the tumour marker profile) and `hl7.fhir.uv.genomics-reporting` 3.0.0.

#### New profiles and functionality

* `feat` **Synthesized TNM classification finalized** (`mii-pr-onko-tnm-klassifikation-synthetisiert`): merges several report-related TNM classifications into one coherent state at the time of decision (e.g. tumor board). 
* **Code fixed** to SNOMED CT `399703000` "Integrated TNM category"; the type value set `mii-vs-onko-tnm-klassifikation-typ` was extended accordingly (clinical / pathologic / integrated)
* **`value` (UICC stage) now 1..1**: the stage is the purpose of the synthesis; on the report panel `value` remains 0..1
* **New optional `component[tnmFormel]`** (CodeSystem `mii-cs-onko-tnm-formel`) for the generated TNM formula (e.g. "ypT0 ypN0 cM0"); it MUST match the `hasMember` observations including prefixes and SHOULD be generated, not maintained manually
* **Provenance**: `derivedFrom` to the source classifications is REQUIRED (1..*), `device` is MS — for automated derivation the generating system including its version SHOULD be documented; an additional `Provenance` resource MAY be added for audit requirements
 
* `feat` New SearchParameters `tnm-y-praefix` and `tnm-r-praefix` for searching over the new prefix modifierExtensions.
* `feat` **Relationship axes of the diagnosis completed**: In addition to `occurredFollowing` (temporal sequence, oBDS 5.9 — target now also includes previous tumor disease), there is the new extension `mii-ex-onko-transformation-von` (lineage continuity, e.g. MDS → AML, meningioma /0 → /3) and a slice on the HL7 standard extension `condition-dueTo` (causation, e.g. t-AML after chemotherapy, radiogenic angiosarcoma). Three-axes guidance with CUP distinction on the diagnosis page; six new example instances including a CUP example bundle with best-of resolution.
* `feat` **ICD-O revision artifacts** (resolves, among others, the Heidelberg finding on 2014 codes): version-pinned year value sets for topography and morphology (first revision 2014 / second revision 2019), main value set as the union of both states, transition ConceptMap `mii-cm-onko-icdo3-transitions-2019` with the changed morphology codes (56 after the BfArM reconciliation, see below).
* `feat` **ATC year value sets 2018–2026 version-pinned** (3,422 entries) plus transition ConceptMap 2022 (monoclonal antibodies move L01XC → L01F); fixes the version ambiguity of the terminology server for year-versioned code systems.
* `feat` **Reportable-tumor value set + warning invariant for the ICD-10 coding** of the oncological diagnosis (`mii-vs-onko-icd10-meldepflichtige-tumoren`, block codes C00–C97, D00–D09, D32/D33, D35.2–.4, D37–D48): reports non-reportable codes as a warning without forbidding them.
* `feat` **MedicationStatement systemic therapy**: `medicationReference` is now allowed as an alternative to `medicationCodeableConcept` (both 0..1 with `medication[x]` 1..1, GH #288) — eases reuse of existing KDS medication resources.
* `feat` **Curated KDL value set** `mii-vs-onko-kdl-dokumentklassen` (45 document classes along the oncological treatment path) as a non-binding companion artifact for the document level.
* `feat` AdverseEvent: `event.coding` extended by a SNOMED CT slice (MedDRA binding unchanged on the MedDRA slice).
* `feat` Approved community changes: morphology extension `morphology-behavior-icdo3` now 0..* (GH #298), FIGO stages codeable (GH #297), Gleason scores < 6 allowed and pattern titles corrected (GH #260/#261).
* `feat` **ConceptMap MedDRA → SNOMED CT for the CTCAE adverse events** (`mii-cm-onko-nebenwirkung-meddra-sct`): all 790 CTCAE v4.03 terms, 708 mapped (638 equivalent, 28 narrower, 42 wider), 82 deliberately unmapped. Target codes verified against the curation version SNOMED International 20260501.
* `feat` **Tumour-marker profile `mii-pr-onko-tumormarker`**: derived from `MII_PR_Labor_Laboruntersuchung` (CDS module Laboratory Report), binding `Observation.code` extensibly to the new union list `mii-vs-onko-tumormarker-loinc` (48 curated LOINC codes), with `focus` on the diagnosis.
* `feat` **Cancer-predisposition value sets** from the §65c list: `mii-vs-onko-praedispositionssyndrome-orpha` (55 Orphanet codes) and `mii-vs-onko-praedispositionsgene-hgnc` (109 HGNC genes).
* `feat` **Structured gene identity**: `Observation.component:gene-studied` is bound extensibly to `mii-vs-onko-marker-gene-hgnc` (40 HGNC genes). For the IGHV special case `mii-vs-onko-ighv-gensegmente-hgnc` lists all 167 segments; mutated/unmutated remains represented via the oBDS qualifier (M/W).
* `feat` **TNM 9th edition**: codes `T1b3` (cervix) as well as `M1c1` and `M1c2` (lung) added to the UICC code system and the value sets.
* `feat` **CRMI metadata on all conformance resources** (324 of 325), following the pattern of the base module.
* `feat` **ECOG and Karnofsky profiles with `focus`** on the primary-tumour diagnosis.
* `feat` **OPS laterality on the surgery profile** exposed as must-support (the oBDS carries no separate laterality field for surgery).
* `feat` **Link to the CDS module Medical Research Project** (GH #232): `Studienteilnahme.focus[studie]` points to `MII_PR_Studie_Studie`.
* `feat` **oBDS mapping on the logical model**: all 16 areas and 85 sub-elements mapped to their oBDS field numbers.

#### Refactorings

* `refactor` **SearchParameter for the c/p/u prefix consolidated**: The three defective SearchParameters `tnm-t-cppraefix`, `tnm-n-cppraefix` and `tnm-m-cppraefix` were replaced by the shared SearchParameter `mii-sp-onko-observation-tnm-cp-praefix` (code `tnm-cp-praefix`). The extension exists exactly once on `Observation.code`; the distinction between T, N and M category is made via the observation's category code (combination with the `code` SearchParameter).

#### Further improvements

* `note` **Known issue — ~4,100 ATC QA messages are a Publisher bug, not invalid codes**: the IG Publisher validates enumerated value-set codes via a `$batch-validate-code` dialect that omits the `url` parameter per validation; the MII terminology server correctly rejects each request ("must specify either valueSet or url"), which the Publisher then reports as "code not valid in the value set 'null'". The codes are server-verified as valid (e.g. `L01XE01@2020` → Imatinib). Affects the annual substance value sets and ATC transition maps; reproduced unchanged with Publisher 2.3.2 and 2.3.4, upstream issue pending.
* `fix` **CapabilityStatement canonical moved into the module's namespace**: the URL was `…/fhir/modul-onko/CapabilityStatement/metadata` — missing the `ext/` segment, which made it the only resource of this module outside its own canonical base, and ending in `metadata` rather than its `id`. It is now `…/fhir/ext/modul-onko/CapabilityStatement/mii-cps-onko-capabilitystatement`. Formally a canonical change; in practice no profile or instance references a CapabilityStatement canonical, and the old URL pointed nowhere, since nothing is published under `/fhir/modul-onko/`.
* `fix` **SNOMED CT code for pure immunotherapy corrected** (GH #267): in `mii-cm-onko-therapie-typ-sct`, oBDS therapy type `IM` (Immun-/Antikörpertherapie) mapped to `897713009` "Antineoplastic chemoimmunotherapy" — asserting a chemotherapy that does not take place in pure immunotherapy. The target is now `76334006` "Immunotherapy (procedure)". `897713009` remains correct for the combinations `CI` and `CIZ`. The ConceptMap is `experimental`, dates from 2024 and is not referenced by any profile, so no migration is required.
* `documentation` **LOINC-SNOMED anchors for the tumour markers**: verified for 23 of 28 markers (seven newly determined). For gastrin, calcitonin, M-protein, IgA and IgM no "Measurement of …" grouper exists in the ontology.
* `documentation` **UICC code system: cross-edition union documented as a deliberate decision** — the edition in use is carried as a separate data element (TNM version, oBDS 8.2); edition-specific validation is planned as a later stage.
* `fix` **Organ modules aligned with the official oBDS numbering** (basisdatensatz.de and oBDS XSD v3.0.5): the numbers are flat (M1–M8, KR1–KR10, P1–P9, MM1–MM4); the earlier hierarchical entries do not exist officially. Misassignments corrected (PSA was P1, officially P7; Clavien-Dindo P5, officially P9) and missing fields added.
* `fix` **ICD-O transitions ConceptMap reconciled with the official BfArM update list** (2021-01-29): 56 instead of 55 transitions; `8153/1` added.
* `fix` **MVGenomSeq ConceptMap corrected against the actual data set**: 13 of 15 target fields did not exist in `OncologyCase.json`.
* `fix` **Example instances: unresolvable references cleaned up.**
* `fix` **`experimental = false`** on 37 module terminologies.
* `fix` **Curation status of the first-generation oBDS-SNOMED ConceptMaps disclosed**: the 28 maps from 2024 are marked `experimental = true` and are neither officially endorsed nor finally quality-assured.
* `fix` **UICC copyright on the TNM code system** replaces the previous CC-BY-4.0 licence statement.
* `documentation` **Implementation Guide moved to the HL7 IG Publisher** (away from Simplifier, onto the MII CDS module template), built bilingually from the repository.
* `documentation` **New overview page "Concept Mappings"**: all 1,459 mappings in five SQL-generated tables, produced at build time from the package database.
* `documentation` **ENCR Table 4 on the tumour-marker page**, plus the specimen-matrix question for serotonin/5-HIAA, HVA/VMA, catecholamines and the newly added metanephrines.
* `documentation` **KDL document classes with mapping table** (IHE XDS official via the DVMD ConceptMap, SNOMED CT and LOINC curated).
* `documentation` **oBDS diagnostic certainty 16.4 and morphology cardinalities**: the leading system for the therapy protocol is documented (`Procedure.usedCode` is authoritative, `MedicationStatement.note.text` only for schema assignment), as is the deliberate asymmetry of the morphology statements (diagnosis 0..*, histology observation exactly one per finding).
* `documentation` **Toronto classification**: §65c transmission rules added.
* `documentation` **Genetics: transmission notation of the §65c marker list** (two-position model, HGVSp/HGVSc, fusion notation).
* `documentation` **TNM: the three coding mechanisms explained.**
* `documentation` New guidance section "Manifestations of the TNM classification" on the [TNM classification](StructureDefinition-mii-pr-onko-tnm-klassifikation.md) page: describes clinical staging, pathological staging, follow-up and the synthesized classification and how they are distinguished via the code axis and prefix modifiers.

-------

### Changes v2026.0.3 (released 2026-03-27)

Technical maintenance release: packaging fix on macOS (AppleDouble contamination), dependency updates (biobank 2026.0.1, medikation 2026.0.1, studie 2026.0.2), Firely Terminal 3.5.0. Details in the German edition.

### Changes v2026.0.2 (released 2026-03-10)

Terminology release: ATC-DE 2026 value set update (23 new codes, L01EP), 27 ATC display names corrected, ATC transition ConceptMap 2026. Details in the German edition.

### Changes v2026.0.1 (released 2026-02-05) and v2026.0.0 (released 2026-01-03)

First 2026 releases including a breaking canonical-URL typo fix for the radiotherapy application-type value set (HDB-708, GH #219). Full details in the German edition.

### Earlier releases

The release history before v2026 is documented in the German edition of this page.

