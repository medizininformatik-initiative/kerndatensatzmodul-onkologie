# MII CS Onkologie Strahlentherapie Applikationsart - MII IG Kerndatensatz-Modul Onkologie v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII CS Onkologie Strahlentherapie Applikationsart**

## CodeSystem: MII CS Onkologie Strahlentherapie Applikationsart 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-applikationsart | *Version*:2027.0.0-ballot |
| Active Stand: 2026-09-14 | *Maschinenlesbarer Name*:MII_CS_Onko_Strahlentherapie_Applikationsart |

 
oBDS-spezifisches Codesystem für Klassifikation von Intention der OP 

Dieses CodeSystem wird in der Definition der folgenden ValueSets referenziert:

* [MII VS Onkologie Strahlentherapie Applikationsart](ValueSet-mii-vs-onko-strahlentherapie-applikationsart.md)

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "mii-cs-onko-strahlentherapie-applikationsart",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-license",
      "valueCode" : "CC-BY-4.0"
    },
    {
      "extension" : [{
        "url" : "packageId",
        "valueId" : "de.medizininformatikinitiative.kerndatensatz.onkologie"
      },
      {
        "url" : "version",
        "valueString" : "2027.0.0-ballot"
      },
      {
        "url" : "uri",
        "valueUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/package-source"
    }],
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablecodesystem",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablecodesystem",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablecodesystem"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionPolicy",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/artifact-version-policy-codes",
        "code" : "package",
        "display" : "Package"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-approvalDate",
    "valueDate" : "2026-09-15"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-topic",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl",
        "code" : "C3262"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-author",
    "valueContactDetail" : {
      "telecom" : [{
        "system" : "email",
        "value" : "thomas.debertshaeuser@charite.de"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-editor",
    "valueContactDetail" : {
      "name" : "Taskforce Core Data Set"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-reviewer",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "Interoperability Working Group",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/interoperability-working-group"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-endorser",
    "valueContactDetail" : {
      "name" : "National Steering Committee",
      "telecom" : [{
        "system" : "url",
        "value" : "https://www.medizininformatik-initiative.de/en/collaboration/national-steering-committee"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/resource-effectivePeriod",
    "valuePeriod" : {
      "start" : "2027"
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-applikationsart",
  "version" : "2027.0.0-ballot",
  "name" : "MII_CS_Onko_Strahlentherapie_Applikationsart",
  "title" : "MII CS Onkologie Strahlentherapie Applikationsart",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-14T12:10:39+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "oBDS-spezifisches Codesystem für Klassifikation von Intention der OP",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "caseSensitive" : true,
  "valueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-strahlentherapie-applikationsart",
  "content" : "complete",
  "count" : 27,
  "concept" : [{
    "code" : "P",
    "display" : "perkutan (Teletherapie)"
  },
  {
    "code" : "P-ST",
    "display" : "perkutan stereotaktisch"
  },
  {
    "code" : "P-4D",
    "display" : "perkutan, atemgetriggert"
  },
  {
    "code" : "P-ST4D",
    "display" : "perkutan, stereotaktisch, atemgetriggert"
  },
  {
    "code" : "PRCN",
    "display" : "perkutan ohne Chemotherapie/Sensitizer"
  },
  {
    "code" : "PRCN-ST",
    "display" : "perkutan, stereotaktisch ohne Chemotherapie/Sensitizer"
  },
  {
    "code" : "PRCN-4D",
    "display" : "perkutan, atemgetriggert, ohne Chemotherapie/Sensitizer"
  },
  {
    "code" : "PRCN-ST4D",
    "display" : "perkutan, stereotaktisch, atemgetriggert, ohne Chemotherapie/Sensitizer"
  },
  {
    "code" : "PRCJ",
    "display" : "perkutan mit Chemotherapie/Sensitizer"
  },
  {
    "code" : "PRCJ-ST",
    "display" : "perkutan, stereotaktisch mit Chemotherapie/Sensitizer"
  },
  {
    "code" : "PRCJ-4D",
    "display" : "perkutan, atemgetriggert, mit Chemotherapie/Sensitizer"
  },
  {
    "code" : "PRCJ-ST4D",
    "display" : "perkutan, stereotaktisch, atemgetriggert, mit Chemotherapie/Sensitizer"
  },
  {
    "code" : "K",
    "display" : "endokavitäre Kontakttherapie"
  },
  {
    "code" : "KHDR",
    "display" : "endokavitäre Kontakttherapie, high dose rate therapy"
  },
  {
    "code" : "KLDR",
    "display" : "endokavitäre Kontakttherapie, low dose rate therapy"
  },
  {
    "code" : "KPDR",
    "display" : "endokavitäre Kontakttherapie, pulsed dose rate therapy"
  },
  {
    "code" : "I",
    "display" : "intersitielle Kontakttherapie"
  },
  {
    "code" : "IHDR",
    "display" : "intersitielle Kontakttherapie, high dose rate therapy"
  },
  {
    "code" : "ILDR",
    "display" : "intersitielle Kontakttherapie, low dose rate therapy"
  },
  {
    "code" : "IPDR",
    "display" : "intersitielle Kontakttherapie, pulsed dose rate therapy"
  },
  {
    "code" : "MSIRT",
    "display" : "selektive interne Radio-Therapie"
  },
  {
    "code" : "MPRRT",
    "display" : "Peptid-Radio-Rezeptor-Therapie"
  },
  {
    "code" : "MPSMA",
    "display" : "PSMA-Therapie"
  },
  {
    "code" : "MRJT",
    "display" : "Radiojod-Therapie"
  },
  {
    "code" : "MRIT",
    "display" : "Radioimmun-Therapie"
  },
  {
    "code" : "M",
    "display" : "sonstige metabolische Radionuklidtherapie"
  },
  {
    "code" : "S",
    "display" : "Sonstiges"
  }]
}

```
