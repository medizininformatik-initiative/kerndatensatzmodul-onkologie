# Resource MII IG Kerndatensatz-Modul Onkologie



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "mii-ig-onko-de-v2026",
  "language" : "de",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ImplementationGuide/mii-ig-onko-de-v2026",
  "version" : "2026.0.3",
  "name" : "MII_IG_Onko_DE",
  "title" : "MII IG Kerndatensatz-Modul Onkologie",
  "status" : "active",
  "date" : "2026-07-02T12:18:38+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "packageId" : "mii-ig-onko-de-v2026",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.2.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "de_basisprofil_r4",
    "uri" : "http://fhir.org/packages/de.basisprofil.r4/ImplementationGuide/de.basisprofil.r4",
    "packageId" : "de.basisprofil.r4",
    "version" : "1.5.x"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_meta",
    "uri" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/ImplementationGuide/mii-ig-meta",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.meta",
    "version" : "2026.0.x"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_base",
    "uri" : "https://www.medizininformatik-initiative.de/fhir/modul-base/ImplementationGuide/mii-ig-base",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.base",
    "version" : "2026.0.x"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_biobank",
    "uri" : "http://fhir.org/packages/de.medizininformatikinitiative.kerndatensatz.biobank/ImplementationGuide/de.medizininformatikinitiative.kerndatensatz.biobank",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.biobank",
    "version" : "2026.0.x"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_medikation",
    "uri" : "https://www.medizininformatik-initiative.de/fhir/core/modul-medikation/ImplementationGuide/mii-ig-medikation",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.medikation",
    "version" : "2026.0.x"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_molgen",
    "uri" : "http://fhir.org/packages/de.medizininformatikinitiative.kerndatensatz.molgen/ImplementationGuide/de.medizininformatikinitiative.kerndatensatz.molgen",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.molgen",
    "version" : "2026.0.x"
  },
  {
    "id" : "de_medizininformatikinitiative_kerndatensatz_studie",
    "uri" : "http://fhir.org/packages/de.medizininformatikinitiative.kerndatensatz.studie/ImplementationGuide/de.medizininformatikinitiative.kerndatensatz.studie",
    "packageId" : "de.medizininformatikinitiative.kerndatensatz.studie",
    "version" : "2026.0.2"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2022+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "release"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "de"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "translation-sources"
      },
      {
        "url" : "value",
        "valueString" : "input/translations/en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2022+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "release"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "de"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "translation-sources"
      },
      {
        "url" : "value",
        "valueString" : "input/translations/en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-onko-modification-5fu-phase1"
      },
      "name" : "5-FU Phase 1 (Zyklen 1-6)",
      "description" : "Fluorouracil administered during FOLFOX4 phase",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-onko-modification-5fu-phase2"
      },
      "name" : "5-FU Phase 2 (Zyklen 7-12)",
      "description" : "Fluorouracil continued for cycles 7-12 as part of modified LV5FU2 protocol",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-strahlentherapie-2014-mamma-mit-lk"
      },
      "name" : "Beispiel Strahlentherapie oBDS 2014 - Mamma mit Lymphknoten (3.1.+)",
      "description" : "oBDS 2014: Ein Bestrahlungsverfahren für Mamma inklusive Lymphknoten als kombinierter Code",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie-bestrahlung-strahlentherapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-strahlentherapie-2021-mamma-lymphknoten"
      },
      "name" : "Beispiel Strahlentherapie oBDS 2021 - Axilläre Lymphknoten",
      "description" : "oBDS 2021: Bestrahlung der axillären Lymphknoten (entspricht 2014 '3.1.+' Lymphknotenanteil)",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie-bestrahlung-strahlentherapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-strahlentherapie-2021-mamma-primaer"
      },
      "name" : "Beispiel Strahlentherapie oBDS 2021 - Mamma Primärzielgebiet",
      "description" : "oBDS 2021: Bestrahlung der Mamma als Primärzielgebiet (entspricht 2014 '3.1.+' Organanteil)",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie-bestrahlung-strahlentherapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-onko-systemische-therapie-medikation1"
      },
      "name" : "Example chemotherapy 1",
      "description" : "Example for the FHIR profile systemic therapy based on German",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-onko-systemische-therapie-medikation2"
      },
      "name" : "Example chemotherapy 2",
      "description" : "Example for the FHIR profile systemic therapy based on German",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/primaertumor-example"
      },
      "name" : "Example Primaertumor Condition for Extended Examples",
      "description" : "Minimal primaertumor condition for referencing in molecular tumor board examples",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-strahlentherapie-nuklearmedizin-1"
      },
      "name" : "Example radiation therapy",
      "description" : "Example radiation therapy conformant with MII Prozedur as bracket for radiation and nuclear therapy",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-strahlentherapie-strahlentherapie-1"
      },
      "name" : "Example radiation therapy",
      "description" : "Example radiation therapy conformant with MII Prozedur as bracket for radiation and nuclear therapy",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-operation-1"
      },
      "name" : "Example surgical therapy",
      "description" : "Example surgical therapy",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-operation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-systemische-therapie-1"
      },
      "name" : "Example systemic therapy",
      "description" : "Example systemic therapy",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-onko-folfox-5fu-request"
      },
      "name" : "FOLFOX - Fluorouracil MedicationRequest",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-onko-folfox-5fu-statement"
      },
      "name" : "FOLFOX - Fluorouracil tatsächlich verabreicht",
      "description" : "5-Fluorouracil medication statement as part of FOLFOX4 protocol",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-onko-folfox-leucovorin-request"
      },
      "name" : "FOLFOX - Folinsäure MedicationRequest",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-onko-folfox-leucovorin-statement"
      },
      "name" : "FOLFOX - Folinsäure tatsächlich verabreicht",
      "description" : "Folinic acid (Leucovorin) medication statement as part of FOLFOX4 protocol",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-onko-folfox-oxaliplatin-request"
      },
      "name" : "FOLFOX - Oxaliplatin MedicationRequest",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-onko-folfox-oxaliplatin-statement"
      },
      "name" : "FOLFOX - Oxaliplatin tatsächlich verabreicht",
      "description" : "Oxaliplatin medication statement as part of FOLFOX4 protocol",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-onko-folfox-patient"
      },
      "name" : "FOLFOX Patient - 65-jähriger mit Kolonkarzinom",
      "description" : "Patient for FOLFOX colorectal cancer treatment example",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-folfox-procedure"
      },
      "name" : "FOLFOX Systemische Therapie (tatsächlich durchgeführt)",
      "description" : "Actual FOLFOX chemotherapy given, linked back to tumor board recommendation",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RequestGroup"
      }],
      "reference" : {
        "reference" : "RequestGroup/mii-exa-onko-folfox-requestgroup"
      },
      "name" : "FOLFOX Therapieempfehlung (RequestGroup)",
      "description" : "Tumor board recommendation for FOLFOX protocol with therapy type and protocol coding",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-kombinationstherapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-onko-folfox-workflow-bundle"
      },
      "name" : "FOLFOX Workflow Bundle - Komplettes Beispiel von Tumorkonferenz bis Therapie",
      "description" : "Comprehensive Bundle demonstrating complete FOLFOX workflow from tumor board recommendation through actual treatment, with all resources for reference resolution validation",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-folfox-phase1"
      },
      "name" : "FOLFOX4 Therapie - Phase 1 (Zyklen 1-6)",
      "description" : "First phase: Full FOLFOX4 protocol for 6 cycles before dose modification",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RequestGroup"
      }],
      "reference" : {
        "reference" : "RequestGroup/mii-exa-onko-folfox-requestgroup-modification"
      },
      "name" : "FOLFOX4 Therapieempfehlung",
      "description" : "Original tumor board recommendation for FOLFOX4 protocol (later modified due to toxicity)",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-kombinationstherapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-onko-modification-leucovorin-phase1"
      },
      "name" : "Folinsäure Phase 1 (Zyklen 1-6)",
      "description" : "Leucovorin administered during FOLFOX4 phase",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-onko-modification-leucovorin-phase2"
      },
      "name" : "Folinsäure Phase 2 (Zyklen 7-12)",
      "description" : "Leucovorin continued for cycles 7-12 as part of modified LV5FU2 protocol",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-onko-fruehere-tumorerkrankung-cervix"
      },
      "name" : "Frühere Tumorerkrankung Cervix in situ",
      "description" : "Beispiel einer früheren Tumorerkrankung (Carcinoma in situ der Cervix uteri) aus dem Jahr 2013",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-fruehere-tumorerkrankung"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-onko-fruehere-tumorerkrankung-mamma"
      },
      "name" : "Frühere Tumorerkrankung Mamma",
      "description" : "Beispiel einer früheren Tumorerkrankung (Mammakarzinom links) aus dem Jahr 2013",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-fruehere-tumorerkrankung"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-onko-fruehere-tumorerkrankung-freetext"
      },
      "name" : "Frühere Tumorerkrankung nur Freitext",
      "description" : "Beispiel einer früheren Tumorerkrankung mit nur Freitextangabe, ohne ICD-10-GM Kodierung (typisch bei anamnestischen Angaben)",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-fruehere-tumorerkrankung"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-onko-fruehere-tumorerkrankung-prostata"
      },
      "name" : "Frühere Tumorerkrankung Prostata",
      "description" : "Beispiel einer früheren Tumorerkrankung (Prostatakarzinom) aus dem Jahr 2018",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-fruehere-tumorerkrankung"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/PatientKimMusterperson-Procedure-4"
      },
      "name" : "Hauptprocedure: Komplexe abdominale Tumorchirurgie",
      "description" : "30.09.2021 OP Intervalldebulking mittels Längsschnittlaparotomie, Tumorresektion mittels Hysterektomie, bilateraler Adnexektomie, und atpyischer Lebersegmentresektion (Seg. II und V). Postoperativ: R0.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-operation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-right-hemicolectomy"
      },
      "name" : "Hemikolektomie rechts",
      "description" : "Laparoscopic right hemicolectomy with lymph node dissection",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-operation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-onko-colorectal-cancer-diagnosis"
      },
      "name" : "Kolonkarzinom Primärdiagnose",
      "description" : "Stage III sigmoid colon adenocarcinoma, diagnosed January 2024",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-onko-ascending-colon-cancer-diagnosis"
      },
      "name" : "Kolonkarzinom Primärdiagnose - Colon ascendens",
      "description" : "Stage III ascending colon adenocarcinoma, diagnosed January 2024",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "List"
      }],
      "reference" : {
        "reference" : "List/mii-exa-onko-liste-evidenz-erstdiagnose-1"
      },
      "name" : "Liste der Evidenz zum Erstdiagnosezeitpunkt",
      "description" : "Eine Beispielliste, welche Observations zur Diagnosestellung präsent waren",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-liste-evidenz-erstdiagnose"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-lv5fu2-phase2"
      },
      "name" : "LV5FU2 Therapie - Phase 2 (Zyklen 7-12)",
      "description" : "Second phase: Modified protocol with 5-FU + Leucovorin only (no Oxaliplatin) for remaining 6 cycles",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-allgemeiner-leistungszustand-ecog-loinc"
      },
      "name" : "Mapping oBDS ECOG zu LOINC",
      "description" : "Mapping der oBDS-Codes für ECOG Performance Status zu LOINC Answer List LA29179-1",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-allgemeiner-leistungszustand-karnofsky-loinc"
      },
      "name" : "Mapping oBDS Karnofsky zu LOINC",
      "description" : "Mapping der oBDS-Codes für Karnofsky Performance Status zu LOINC Answer List LA29175-9",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-krk-stoma-obds-sct"
      },
      "name" : "Mapping oBDS Stoma-Anzeichnung zu SNOMED CT",
      "description" : "Mapping der oBDS-Codes für präoperative Stoma-Anzeichnung zu SNOMED CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-onko-modification-5fu-request"
      },
      "name" : "MedicationRequest - Fluorouracil (vollständig verabreicht)",
      "description" : "Fluorouracil recommendation - completed for all 12 cycles",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-onko-modification-leucovorin-request"
      },
      "name" : "MedicationRequest - Folinsäure (vollständig verabreicht)",
      "description" : "Leucovorin recommendation - completed for all 12 cycles",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-onko-modification-oxaliplatin-request"
      },
      "name" : "MedicationRequest - Oxaliplatin (abgebrochen wegen Neuropathie)",
      "description" : "Oxaliplatin recommendation - stopped after cycle 6 due to grade 3 peripheral neuropathy",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-onko-medikation-iberdomide-unii"
      },
      "name" : "Medikation Iberdomide (UNII)",
      "description" : "Beispiel einer systemischen Therapie Medikation mit UNII-Code für experimentellen Wirkstoff ohne ATC-Code",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-onko-medikation-imatinib-atc-version-transition"
      },
      "name" : "Medikation Imatinib (ATC Versionsübergang)",
      "description" : "Beispiel einer systemischen Therapie Medikation mit Imatinib, das 2021 von L01XE01 nach L01EA01 umklassifiziert wurde. Zeigt beide ATC-Codes mit ihren jeweiligen Versionen.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-melanom-exzision-oberarm"
      },
      "name" : "Melanom Exzision Oberarm Beispiel",
      "description" : "Beispiel einer Melanom-Exzision am linken Oberarm mit Sicherheitsabstand",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-exzision"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-melanom-exzision-ruecken"
      },
      "name" : "Melanom Exzision Rücken Beispiel",
      "description" : "Beispiel einer Melanom-Nachexzision am oberen Rücken",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-exzision"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-strahlentherapie-2014-prostata-mit-lk"
      },
      "name" : "Migration Beispiel: Prostata mit Lymphknoten (oBDS 2014 → 2021)",
      "description" : "Zeigt Migration von 2014 '5.4.+' zu 2021 separaten Prozeduren",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie-bestrahlung-strahlentherapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-allgemeiner-leistungszustand-sct"
      },
      "name" : "MII CM Onko Allgemeiner Leistungszustand SNOMED Mapping",
      "description" : "Mapping Allgemeiner Leistungszustand Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-atc-transitions-2021"
      },
      "name" : "MII CM Onko ATC Code Changes 2020 to 2021",
      "description" : "Diese ConceptMap dokumentiert ausschließlich die ATC-Code-Änderungen von 2020 zu 2021. Im Jahr 2021 erfolgte eine umfassende Reorganisation der ATC-Klassifikation für onkologische Substanzen mit Umkodierung von über 60 Wirkstoffen.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-atc-transitions-2023"
      },
      "name" : "MII CM Onko ATC Code Changes 2022 to 2023",
      "description" : "Diese ConceptMap dokumentiert die ATC-Code-Änderungen von 2022 zu 2023. In diesem Jahr wurden CAR-T-Zelltherapien und onkolytische Viren in neue spezifische ATC-Kategorien umklassifiziert.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-atc-transitions-2024"
      },
      "name" : "MII CM Onko ATC Code Changes 2023 to 2024",
      "description" : "Diese ConceptMap dokumentiert die ATC-Code-Änderungen von 2023 zu 2024. Mehrere immunmodulatorische Substanzen wurden in neue Kategorien umklassifiziert, und Kombinationspräparate erhielten neue Codes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-atc-transitions-2025"
      },
      "name" : "MII CM Onko ATC Code Changes 2024 to 2025",
      "description" : "Diese ConceptMap dokumentiert die ATC-Code-Änderungen von 2024 zu 2025. IDH-Inhibitoren wurden in eine neue spezifische Kategorie umklassifiziert.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-atc-transitions-2026"
      },
      "name" : "MII CM Onko ATC Code Changes 2025 to 2026",
      "description" : "Diese ConceptMap dokumentiert die ATC-Code-Änderungen von 2025 zu 2026. c-MET-Kinase-Inhibitoren wurden in die neue Untergruppe L01EP umklassifiziert.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-tnm-uicc-sct-clinical"
      },
      "name" : "MII CM Onko Clincal TNM UICC SNOMED",
      "description" : "Mapping clincal TNM UICC Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-fernmetastasen-sct"
      },
      "name" : "MII CM Onko Fernmetastasen SCT Mapping",
      "description" : "Mapping der Fernmetastasen-Codesystems  auf SNOMED",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-genetische-variante-auspraegung-sct"
      },
      "name" : "MII CM Onko Genetische Variante Auspraegung SNOMED Mapping",
      "description" : "Mapping Therapieabweichung Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-grading-sct"
      },
      "name" : "MII CM Onko Grading SNOMED Mapping",
      "description" : "Mapping Grading Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-intention-sct"
      },
      "name" : "MII CM Onko Intention SNOMED Mapping",
      "description" : "Mapping Intention Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-nebenwirkung-sct"
      },
      "name" : "MII CM Onko Nebenwirkung SNOMED Mapping",
      "description" : "Mapping Nebenwirkung CTCAE Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-operation-komplikation-sct"
      },
      "name" : "MII CM Onko Operation Komplikation SNOMED Mapping",
      "description" : "Mapping Operation Komplikation Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-tnm-uicc-sct-pathological"
      },
      "name" : "MII CM Onko Pathological TNM UICC SNOMED",
      "description" : "Mapping pathological TNM UICC Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-primaertumor-diagnosesicherung-sct"
      },
      "name" : "MII CM Onko Primaertumor Diagnosesicherung SNOMED Mapping",
      "description" : "Mapping Primärtumor Diagnosesicherung Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-residualstatus-uicc-sct"
      },
      "name" : "MII CM Onko Residualstatus UICC SNOMED",
      "description" : "Mapping Residualstatus UICC Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-seitenlokalisation-sct"
      },
      "name" : "MII CM Onko Seitenlokalisation SNOMED Mapping",
      "description" : "Mapping Seitenlokalisation Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-strahlentherapie-applikationsart-sct"
      },
      "name" : "MII CM Onko Strahlentherapie Applikationsart SNOMED Mapping",
      "description" : "Mapping Strahlentherapie Applikationsart Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-strahlentherapie-boost-sct"
      },
      "name" : "MII CM Onko Strahlentherapie Boost SNOMED Mapping",
      "description" : "Mapping Strahlentherapie Boost Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-strahlentherapie-strahlenart-sct"
      },
      "name" : "MII CM Onko Strahlentherapie Strahlenart SNOMED Mapping",
      "description" : "Mapping Strahlentherapie Strahlenart Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-strahlentherapie-strahleneinheit-sct"
      },
      "name" : "MII CM Onko Strahlentherapie Strahleneinheit SNOMED Mapping",
      "description" : "Mapping Strahlentherapie Strahleneinheit Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-strahlentherapie-zielgebiet-sct"
      },
      "name" : "MII CM Onko Strahlentherapie Zielgebiet SNOMED Mapping",
      "description" : "Mapping Strahlentherapie Zielgebiet Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-studienteilnahme-sct"
      },
      "name" : "MII CM Onko Studienteilnahme SNOMED Mapping",
      "description" : "Mapping Studienteilnahme Status Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-therapie-ende-sct"
      },
      "name" : "MII CM Onko Therapie Ende SNOMED Mapping",
      "description" : "Mapping Therapie Ende Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-therapie-stellung-sct"
      },
      "name" : "MII CM Onko Therapie Stellung SNOMED Mapping",
      "description" : "Mapping Therapie Stellung Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-therapie-typ-sct"
      },
      "name" : "MII CM Onko Therapie Typ SNOMED Mapping",
      "description" : "Mapping Therapie Typ Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-therapieabweichung-sct"
      },
      "name" : "MII CM Onko Therapieabweichung SNOMED Mapping",
      "description" : "Mapping Therapieabweichung Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-therapieplanung-sct"
      },
      "name" : "MII CM Onko Therapieplanung SNOMED Mapping",
      "description" : "Mapping Therapieplanung Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-tod-sct"
      },
      "name" : "MII CM Onko Tod SNOMED Mapping",
      "description" : "Mapping Tod Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-verlauf-fernmetastasen-sct"
      },
      "name" : "MII CM Onko Verlauf Fernmetastasen SNOMED Mapping",
      "description" : "Mapping Verlauf Fernmetastasen Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-verlauf-gesamtbeurteilung-sct"
      },
      "name" : "MII CM Onko Verlauf Gesamtbeurteilung SNOMED Mapping",
      "description" : "Mapping Gesamtbeurteilung Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-verlauf-lymphknoten-sct"
      },
      "name" : "MII CM Onko Verlauf Lymphknoten SNOMED Mapping",
      "description" : "Mapping Lymphknoten Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-verlauf-primaertumor-sct"
      },
      "name" : "MII CM Onko Verlauf Primaertumor SNOMED Mapping",
      "description" : "Mapping Verlauf-Primaertumor Codes zu SNOMED-CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onko-asa-obds-loinc"
      },
      "name" : "MII CM Onkologie ASA oBDS zu LOINC",
      "description" : "Mapping von oBDS ASA-Klassifikation (ursprünglich KR9, generalisiert für alle onkologischen Indikationen) zu LOINC ASA Physical Status",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-weitere-klassifikationen-obds"
      },
      "name" : "MII CodeSystem Onkologie - Weitere Klassifikationen oBDS",
      "description" : "oBDS-specific classification systems and scoring systems not yet covered by international terminologies (SNOMED CT, NCI Thesaurus). These codes supplement the existing ValueSet for additional classifications. Research required: Check if SNOMED CT or LOINC codes exist for these scoring systems before using oBDS-specific codes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-onkologie-to-mvgenomseq"
      },
      "name" : "MII Concept Map Modellvorhaben Genomsequenzierung Onkologie",
      "description" : "MII LogicalModel Modellvorhaben Genomsequenzierung Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/mii-cps-onko-capabilitystatement"
      },
      "name" : "MII CPS Onkology CapabilityStatement",
      "description" : "Das vorliegende CapabilityStatement beschreibt alle verpflichtenden Interaktionen die ein konformes System unterstützen muss, um das Modul Onkologie der Medizininformatik Initiative zu implementieren.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-nebenwirkung-ctcae-grad"
      },
      "name" : "MII CS Onko Nebenwirkung nach CTCAE-Grad",
      "description" : "Gibt an, zu welchem Schweregrad von Nebenwirkungen es bei der Bestrahlung oder der systemischen Therapie gekommen ist.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-therapie-typ"
      },
      "name" : "MII CS Onko Therapie Typ",
      "description" : "Typ der Therapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-allgemeiner-leistungszustand-ecog"
      },
      "name" : "MII CS Onkologie Allgemeiner Leistungszustand ECOG",
      "description" : "oBDS-spezifisches Codesystem für den Allgemeinen Leistungszustand nach ECOG",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-allgemeiner-leistungszustand-karnofsky"
      },
      "name" : "MII CS Onkologie Allgemeiner Leistungszustand Karnofsky",
      "description" : "oBDS-spezifisches Codesystem für den Allgemeinen Leistungszustand nach Karnofsky",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-asa-obds"
      },
      "name" : "MII CS Onkologie ASA-Klassifikation oBDS",
      "description" : "oBDS-basiertes CodeSystem für ASA-Klassifikation (ursprünglich KR9 aus Kolorektales Karzinom Modul, generalisiert für alle onkologischen Indikationen)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-fernmetastasen"
      },
      "name" : "MII CS Onkologie Fernmetastasen",
      "description" : "oBDS-spezifisches Codesystem für Fernmetastasen, basierend auf Spezifikation durch TNM-Klassifikation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-genetische-variante-auspraegung"
      },
      "name" : "MII CS Onkologie Genetische Variante Ausprägung",
      "description" : "oBDS-spezifisches Codesystem Konsequenz der genetischen Variante Ausprägung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-grading"
      },
      "name" : "MII CS Onkologie Grading",
      "description" : "Codes für Histologie Grading. Gibt den Differenzierungsgrad des Tumors entsprechend der aktuellen TNM-Auflage an.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-intention"
      },
      "name" : "MII CS Onkologie Intention",
      "description" : "oBDS-spezifisches Codesystem für Klassifikation von Intention der OP, der Strahlentherapie und der Systemischen Therapie.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-krk-anastomoseninsuffizienz"
      },
      "name" : "MII CS Onkologie KRK Anastomoseninsuffizienz",
      "description" : "oBDS-spezifisches Codesystem für Anastomoseninsuffizienz beim Kolorektalen Karzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-krk-operationstyp"
      },
      "name" : "MII CS Onkologie KRK Operationstyp",
      "description" : "oBDS-spezifisches Codesystem TME-Präparat, basierend auf der S3-Leitlinie Mammakarzinom v",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-mamma-her2neu-status-leitlinie"
      },
      "name" : "MII CS Onkologie Mamma Her2neu Status Leitlinie",
      "description" : "Codesystem für Her2neu Status basierend auf der S3-Leitlinie Mammakarzinom und ASCO/CAP Guidelines mit erweiterten Klassifikationen (HER2-low, HER2-ultralow)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-mamma-her2neu-status-obds"
      },
      "name" : "MII CS Onkologie Mamma Her2neu Status oBDS",
      "description" : "oBDS-spezifisches Codesystem für Her2neu Status gemäß oBDS Feld M4 (243)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-mamma-rezeptorstatus-leitlinie"
      },
      "name" : "MII CS Onkologie Mamma Rezeptorstatus",
      "description" : "oBDS-spezifisches Codesystem Mamma-Rezeptorstatus, basierend auf der S3-Leitlinie Mammakarzinom v5.02 Abschnitt 4.5.4",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-melanom-ulzeration"
      },
      "name" : "MII CS Onkologie Melanom Ulzeration",
      "description" : "Codes für die Ulzeration beim Malignen Melanom der Haut nach oBDS",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-operation-komplikation"
      },
      "name" : "MII CS Onkologie Operation Komplikationen",
      "description" : "oBDS-spezifisches Codesystem für Klassifikation von Komplikationen während der OP",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-primaertumor-diagnosesicherung"
      },
      "name" : "MII CS Onkologie Primärtumor Diagnosesicherung",
      "description" : "Codes für Primärtumor Diagnosesicherung, d.h. die höchste erreichte Diagnosesicherheit der Diagnose.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-seitenlokalisation"
      },
      "name" : "MII CS Onkologie Primärtumor Seitenlokalisation",
      "description" : "Codes für Seitenlokalisation, d.h. organspezifische Angabe der betroffenen Seite.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-prostata-postsurgical-complications"
      },
      "name" : "MII CS Onkologie Prostata Postoperative Komplikationen",
      "description" : "CodeSystem zur Darstellung des Vorhandenseins von postoperativen Komplikationen nach Prostatektomie in der Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-residualstatus"
      },
      "name" : "MII CS Onkologie Residualstatus",
      "description" : "oBDS-spezifisches Codesystem für R-Klassifikation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-strahlentherapie-applikationsart"
      },
      "name" : "MII CS Onkologie Strahlentherapie Applikationsart",
      "description" : "oBDS-spezifisches Codesystem für Klassifikation von Intention der OP",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-strahlentherapie-boost"
      },
      "name" : "MII CS Onkologie Strahlentherapie Boost",
      "description" : "oBDS-spezifisches Codesystem für Klassifikation von Strahlentherapie-Boosts",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-therapie-ende-grund"
      },
      "name" : "MII CS Onkologie Strahlentherapie Ende Grund",
      "description" : "oBDS-spezifisches Codesystem für Klassifikation des Grundes der Beendigung der Strahlentherapie oder der systemischen Therapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-strahlentherapie-strahlenart"
      },
      "name" : "MII CS Onkologie Strahlentherapie Strahlenart",
      "description" : "oBDS-spezifisches Codesystem für Klassifikation von eingesetzter Strahlenart",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-strahlentherapie-zielgebiet"
      },
      "name" : "MII CS Onkologie Strahlentherapie Zielgebiet",
      "description" : "oBDS-spezifisches Codesystem für Klassifikation von Zielgebiet von Strahlentherapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-strahlentherapie-zielgebiet-2014"
      },
      "name" : "MII CS Onkologie Strahlentherapie Zielgebiet oBDS 2014 (Legacy)",
      "description" : "oBDS 2014 Legacy-Codesystem für Klassifikation von Zielgebiet von Strahlentherapie - nur für Datenimport und Migration",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-studienteilnahme"
      },
      "name" : "MII CS Onkologie Studienteilnahme",
      "description" : "oBDS-spezifisches Codesystem den Status der Studienteilnahme",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-systemische-therapie-protokolle"
      },
      "name" : "MII CS Onkologie Systemische Therapie Protokolle",
      "description" : "oBDS-spezifisches Codesystem für Protokolle systemischer Therapien",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-therapie-stellungzurop"
      },
      "name" : "MII CS Onkologie Therapie Stellung",
      "description" : "oBDS-spezifisches Codesystem für Klassifikation von Stellung zur OP",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-therapieabweichung"
      },
      "name" : "MII CS Onkologie Therapieabweichung",
      "description" : "oBDS-spezifisches Codesystem für die Therapieabweichung auf Wunsch des Patients.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-therapieplanung-typ"
      },
      "name" : "MII CS Onkologie Therapieplanung Typ",
      "description" : "oBDS-spezifisches Codesystem für den Therapieplanungstyp",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-krk-tme-qualitaet"
      },
      "name" : "MII CS Onkologie TME Qualität",
      "description" : "oBDS-spezifisches Codesystem TME-Präparat, basierend auf der S3-Leitlinie Mammakarzinom v",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-tnm-uicc"
      },
      "name" : "MII CS Onkologie TNM UICC",
      "description" : "Codes für TNM UICC Ausprägungen.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-tnm-version"
      },
      "name" : "MII CS Onkologie TNM Version",
      "description" : "Codes für TNM Version/Auflage nach welcher Version des TNM klassifiziert wird.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-tod"
      },
      "name" : "MII CS Onkologie Tod",
      "description" : "oBDS-spezifisches Codesystem tumorbedingter Tod",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-verlauf-fernmetastasen"
      },
      "name" : "MII CS Onkologie Verlauf Fernmetastasen",
      "description" : "oBDS-spezifisches Codesystem für die Beurteilung von Fernmetastasen im Behandlungsverlauf",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-verlauf-gesamtbeurteilung"
      },
      "name" : "MII CS Onkologie Verlauf Gesamtbeurteilung",
      "description" : "oBDS-spezifisches Codesystem für die Gesamtbeurteilung im Behandlungsverlauf",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-verlauf-lymphknoten"
      },
      "name" : "MII CS Onkologie Verlauf Lymphknoten",
      "description" : "oBDS-spezifisches Codesystem für die Beurteilung von Lymphknoten im Behandlungsverlauf",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-verlauf-primaertumor"
      },
      "name" : "MII CS Onkologie Verlauf Primärtumor",
      "description" : "oBDS-spezifisches Codesystem für die Beurteilung des Primärtumors im Behandlungsverlauf",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-histology-morphology-behavior-icdo3"
      },
      "name" : "MII EX Onko Histology Morphology Behavior ICDO3",
      "description" : "Extension zur Erfassung von ICDO3 da Morphology nicht als Condition.code. Orientiert sich an mcode-stu3.0.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-operation-intention"
      },
      "name" : "MII EX Onko Operation Intention",
      "description" : "Intention der Operation im Rahmen des oBDS",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-operation-urgency"
      },
      "name" : "MII EX Onko Operation Urgency",
      "description" : "Modalität der Eingriffsdurchführung (Art des Eingriffs) im Rahmen des oBDS (KR6)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-boost"
      },
      "name" : "MII EX Onko Strahlentherapie Bestrahlung Boost",
      "description" : "Strahlentherapie: Boost einer Bestrahlung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-einzeldosis"
      },
      "name" : "MII EX Onko Strahlentherapie Bestrahlung Einzeldosis",
      "description" : "Strahlentherapie: Einzeldosis einer Bestrahlung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-gesamtdosis"
      },
      "name" : "MII EX Onko Strahlentherapie Bestrahlung Gesamtdosis",
      "description" : "Strahlentherapie: Gesamtdosis einer Bestrahlung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-strahlentherapie-bestrahlung-seitenlokalisation"
      },
      "name" : "MII EX Onko Strahlentherapie Bestrahlung Seitenlokalisation",
      "description" : "Strahlentherapie: Seitenlokalisation einer Bestrahlung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-strahlentherapie-intention"
      },
      "name" : "MII EX Onko Strahlentherapie Intention",
      "description" : "Strahlentherapie Intention",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-strahlentherapie-stellungzurop"
      },
      "name" : "MII EX Onko Strahlentherapie Stellung zur OP",
      "description" : "Strahlentherapie Stellung zur OP",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-systemische-therapie-intention"
      },
      "name" : "MII EX Onko Systemische Therapie Intention",
      "description" : "Systemische Therapie Intention",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-systemische-therapie-stellungzurop"
      },
      "name" : "MII EX Onko Systemische Therapie Stellung zur OP",
      "description" : "Systemische Therapie Stellung zur OP",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-tnm-cp-praefix"
      },
      "name" : "MII EX Onkologie TNM c/p Präfix",
      "description" : "Die Extension verleiht einer TNM T-, N- oder M-Kategorie ein c, p oder u Präfix zur Angabe der Klassifikationsmethode: 'c' = klinische Klassifikation (basierend auf klinischen Angaben), 'p' = pathologische Klassifikation (basierend auf pathohistologischer Untersuchung), 'u' = Ultraschall-basierte Klassifikation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-tnm-itc-suffix"
      },
      "name" : "MII EX Onkologie TNM ITC Suffix",
      "description" : "Die Extension verleiht TNM N- und M-Kategorien isolierte Tumorzellen (ITC) Suffixe.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-ex-onko-tnm-sn-suffix"
      },
      "name" : "MII EX Onkologie TNM SN Suffix",
      "description" : "Die Extension verleiht der TNM N-Kategorie das Schildwächterlymphknoten (Sentinel Lymph Node) Suffix.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-krk-abstand-circumferelle-resektionsebene"
      },
      "name" : "MII EXA Onko KRK Abstand Circumferelle Resektionsebene",
      "description" : "Beispiel für den minimalen Abstand des Tumorrandes zur circumferellen Dissektionslinie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-abstand-circumferelle-resektionsebene"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-krk-abstand-mesorektale-fascie"
      },
      "name" : "MII EXA Onko KRK Abstand Mesorektale Fascie",
      "description" : "Beispiel für den Abstand des Tumors zur mesorektalen Faszie bei MRT-Untersuchung",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-mrt-mesorektale-faszie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-krk-abstand-resektionsrand-aboral"
      },
      "name" : "MII EXA Onko KRK Abstand Resektionsrand Aboral",
      "description" : "Beispiel für den minimalen Abstand des Tumorrandes zur aboralen Dissektionslinie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-abstand-aboral"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-krk-abstand-tumor-anokutanlinie"
      },
      "name" : "MII EXA Onko KRK Abstand Tumor Anokutanlinie",
      "description" : "Beispiel für den Abstand des Tumorunterrandes zur Anokutanlinie beim Rektumkarzinom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-abstand-anokutan"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-krk-anastomoseninsuffizienz"
      },
      "name" : "MII EXA Onko KRK Anastomoseninsuffizienz",
      "description" : "Beispiel für die Bewertung einer Anastomoseninsuffizienz beim Kolorektalen Karzinom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-anastomoseninsuffizienz"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-onko-krk-bundle"
      },
      "name" : "MII EXA Onko KRK Bundle",
      "description" : "Beispiel-Bundle für Kolorektales Karzinom mit allen spezifischen Profilen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-krk-operation"
      },
      "name" : "MII EXA Onko KRK Operation",
      "description" : "Beispiel für eine Operation beim Kolorektalen Karzinom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-operation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-onko-krk-specimen"
      },
      "name" : "MII EXA Onko KRK Specimen",
      "description" : "Beispiel für ein Histologie-Specimen beim Kolorektalen Karzinom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-specimen"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-krk-stoma-markierung"
      },
      "name" : "MII EXA Onko KRK Stoma-Markierung",
      "description" : "Beispiel für eine präoperative Stoma-Markierung beim Kolorektalen Karzinom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-krk-stoma-markierung"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-onko-mamma-example-bundle-1"
      },
      "name" : "MII EXA Onko Mamma Bundle",
      "description" : "Beispiel-Bundle für Mamma-Karzinom mit allen spezifischen Profilen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-mamma-her2neu-status"
      },
      "name" : "MII EXA Onko Mamma Her2neu Status",
      "description" : "Beispiel für Her2neu Status bei Mammakarzinom - HER2-positiv (IHC 3+)",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-her2neu-status"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-melanom-breslow-tiefe"
      },
      "name" : "MII EXA Onko Melanom Breslow Tiefe",
      "description" : "Beispiel für die Messung der Breslow-Tumordicke beim Malignen Melanom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-breslow-tiefe"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-onko-melanom-bundle"
      },
      "name" : "MII EXA Onko Melanom Bundle",
      "description" : "Beispiel-Bundle für Malignes Melanom mit allen spezifischen Profilen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-melanom-ldh"
      },
      "name" : "MII EXA Onko Melanom LDH",
      "description" : "Beispiel für einen LDH Laborwert beim Malignen Melanom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-ldh"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-melanom-sicherheitsabstand"
      },
      "name" : "MII EXA Onko Melanom Sicherheitsabstand",
      "description" : "Beispiel für die Messung des Sicherheitsabstands beim Malignen Melanom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-sicherheitsabstand"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-melanom-ulzeration"
      },
      "name" : "MII EXA Onko Melanom Ulzeration",
      "description" : "Beispiel für die Bestimmung der Ulzeration beim Malignen Melanom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-melanom-ulzeration"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      }],
      "reference" : {
        "reference" : "Bundle/mii-exa-onko-prostata-example-bundle-1"
      },
      "name" : "MII EXA Onko Prostata Bundle",
      "description" : "Beispiel-Bundle für Prostata-Karzinom mit allen spezifischen Profilen",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-prostata-surgery-2"
      },
      "name" : "MII EXA Onko Prostata Operation",
      "description" : "Beispiel für eine Prostatektomie in der Onkologie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-operation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-lm-mvgenomseq-onkologie"
      },
      "name" : "MII LM Modellvorhaben Genomsequenzierung Onkologie",
      "description" : "MII LogicalModel Modellvorhaben Genomsequenzierung Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-lm-onko"
      },
      "name" : "MII LM Onkologie",
      "description" : "MII LogicalModel Modul Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-lm-onko-organspezifische-zusatzmodule"
      },
      "name" : "MII LM Onkologie Organspezifische Zusatzmodule",
      "description" : "Logisches Modell für die organspezifischen Zusatzmodule des oBDS",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-melanom-exzision"
      },
      "name" : "MII PR Onko Melanom Exzision",
      "description" : "Melanom-spezifische Exzision. Dieses Profil spezialisiert die allgemeine onkologische Operation für Melanom-Exzisionen mit einem präferierten ValueSet basierend auf SNOMED CT Codes für Hautexzisionen.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-prostata-operation"
      },
      "name" : "MII PR Onko Prostata Operation",
      "description" : "Prostata-spezifische Operation. Dieses Profil spezialisiert die allgemeine onkologische Operation für Prostata-spezifische Eingriffe mit einem required Binding zu einem ValueSet basierend auf SNOMED CT 118877007 und dessen Kindern.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-krk-abstand-aboral"
      },
      "name" : "MII PR Onkologie Abstand Aboral",
      "description" : "Dieses Profil beschreibt den minimalen Abstand des Tumorrandes zur aboralen Dissektionlinie im Kolorektalen Karzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-krk-abstand-anokutan"
      },
      "name" : "MII PR Onkologie Abstand Anokutan",
      "description" : "Dieses Profil beschreibt den Abstand des Tumorunterrandes zur Anokutanlinie im Kolorektalen Karzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-krk-abstand-circumferelle-resektionsebene"
      },
      "name" : "MII PR Onkologie Abstand Circumferelle Resektionsebene",
      "description" : "Dieses Profil beschreibt den minimalen Abstand des Tumorrandes zur circumferellen Dissektionlinie beim Kolorektalen Karzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-allgemeiner-leistungszustand-ecog"
      },
      "name" : "MII PR Onkologie Allgemeiner Leistungszustand ECOG",
      "description" : "OBDS Beschreibung des allgemeines Leistungszustandes nach ECOG",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-allgemeiner-leistungszustand-karnofsky"
      },
      "name" : "MII PR Onkologie Allgemeiner Leistungszustand nach Karnofsky",
      "description" : "OBDS Beschreibung des allgemeines Leistungszustandes nach Karnofsky",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-anzahl-befallene-lymphknoten"
      },
      "name" : "MII PR Onkologie Anzahl der befallenen Lymphknoten",
      "description" : "Histologie: Anzahl der befallenen Lymphknoten. Gibt an, wie viele Lymphknoten befallen sind (einschließlich Sentinel).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-anzahl-befallene-sentinel-lymphknoten"
      },
      "name" : "MII PR Onkologie Anzahl der befallenen Sentinel-Lymphknoten",
      "description" : "Histologie: Anzahl der befallenen Sentinel-Lymphknoten. Gibt an, wie viele Sentinel-Lymphknoten befallen sind.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-anzahl-untersuchte-lymphknoten"
      },
      "name" : "MII PR Onkologie Anzahl der untersuchten Lymphknoten",
      "description" : "Histologie: Anzahl der untersuchten Lymphknoten. Gibt an, wie viele Lymphknoten untersucht wurden (einschließlich Sentinel).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-anzahl-untersuchte-sentinel-lymphknoten"
      },
      "name" : "MII PR Onkologie Anzahl der untersuchten Sentinel-Lymphknoten",
      "description" : "Histologie: Anzahl der untersuchten Sentinel-Lymphknoten. Gibt an, wie viele Sentinel-Lymphknoten untersucht wurden.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-asa-klassifikation"
      },
      "name" : "MII PR Onkologie ASA-Klassifikation",
      "description" : "Dieses Profil beschreibt die ASA-Klassifikation (American Society of Anesthesiologists Physical Status Classification) in der Onkologie. Die ASA-Klassifikation dient primär der präoperativen Risikobewertung, kann aber auch als Komorbidätsindex für systemische Therapieentscheidungen verwendet werden. Ursprünglich aus oBDS KR9 (Kolorektales Karzinom), nun generalisiert für alle onkologischen Indikationen.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-befund"
      },
      "name" : "MII PR Onkologie Befund",
      "description" : "Histologie: Befund. Vollständiger Befundbericht des Pathologen.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-prostate-ca-befall-stanze"
      },
      "name" : "MII PR Onkologie Ca-Befall Stanze",
      "description" : "Dieses Profil beschreibt den prozentualen Befall der am stärksten befallenen Stanze einer Prostata-Biopsie oder eines Prostata-Exzisionspräparates in der Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-prostate-clavien-dindo"
      },
      "name" : "MII PR Onkologie Clavien Dindo",
      "description" : "Dieses Profil beschreibt den Clavien-Dindo-Score für die Prostatektomie in der Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-diagnose-primaertumor"
      },
      "name" : "MII PR Onkologie Diagnose Primärtumor",
      "description" : "Dieses Profil beschreibt die Diagnose des Primärtumors (bzw. der primären hämatologisch-myeloneoplastischen Erkrankung) und basiert auf dem MII KDS Modul Diagnose.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-liste-evidenz-erstdiagnose"
      },
      "name" : "MII PR Onkologie Evidenz Diagnose Primärtumor",
      "description" : "Dieses Profil beschreibt eine Liste, die alle Observationen und Berichte enthält, die für eine Erstdiagnostik relevant waren.  (synchrone Observationen im Sinne der Krebsregister)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-fernmetastasen"
      },
      "name" : "MII PR Onkologie Fernmetastasen",
      "description" : "OBDS Beschreibung von Fernmetastasen (Lokalisation und Datum)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-fruehere-tumorerkrankung"
      },
      "name" : "MII PR Onkologie Frühere Tumorerkrankung",
      "description" : "Dieses Profil beschreibt frühere Tumorerkrankungen, die in der Anamnese zu einem früheren Zeitpunkt diagnostiziert/behandelt wurden. Basiert auf FHIR Condition, da historische Daten oft nur als Freitext vorliegen.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-genetische-variante"
      },
      "name" : "MII PR Onkologie Genetische Variante",
      "description" : "Genetische Variante wie im oBDS beschrieben",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-grading"
      },
      "name" : "MII PR Onkologie Grading",
      "description" : "Histologie: Tumor Grading. Gibt den Differenzierungsgrad des Tumors entsprechend der aktuellen TNM-Auflage an.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-mamma-her2neu-status"
      },
      "name" : "MII PR Onkologie Her2neu Status",
      "description" : "Dieses Profil beschreibt den Her2neu Status einer pathologisch untersuchten Probe beim Mamma-Karzinom in der Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-histologie-icdo3"
      },
      "name" : "MII PR Onkologie Histologie ICD-O-3",
      "description" : "Histologie-Kodierung nach ICD-0 für die Verwendung von Folgediagnostik. Bei der histologischen Beurteilung des Primärtumors sind die histologischen Informationen direkt über die Condition-Ressource abzubilden.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-krk-anastomoseninsuffizienz"
      },
      "name" : "MII PR Onkologie KRK Anastomoseninsuffizienz",
      "description" : "Dieses Profil beschreibt die Bewertung der Anastomoseninsuffizienz nach einer Operation beim Kolorektalen Karzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-krk-mrt-mesorektale-faszie"
      },
      "name" : "MII PR Onkologie KRK MRT/CT Abstand Mesorektale Faszie",
      "description" : "Dieses Profil beschreibt den Abstand des Tumors zur mesorektalen Faszie bei MRT oder Dünnschicht-CT Untersuchung beim Kolorektalen Karzinom (oBDS KR5)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-krk-stoma-markierung"
      },
      "name" : "MII PR Onkologie KRK Stoma-Markierung",
      "description" : "Dieses Profil beschreibt die präoperative Markierung der geplanten Stoma-Position beim Kolorektalen Karzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-mamma-operation"
      },
      "name" : "MII PR Onkologie Mamma Operation",
      "description" : "Das vorliegende Profil beschreibt operative Eingriffe an der Brust im Rahmen der Mammakarzinom-Behandlung. Es erweitert das allgemeine Operationsprofil um Mamma-spezifische Aspekte und ermöglicht die detaillierte Erfassung von brustchirurgischen Verfahren.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-melanom-breslow-tiefe"
      },
      "name" : "MII PR Onkologie Melanom Breslow Tiefe",
      "description" : "Dieses Profil beschreibt die Breslow-Tumordicke beim Malignen Melanom der Haut",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-melanom-ldh"
      },
      "name" : "MII PR Onkologie Melanom LDH",
      "description" : "Dieses Profil beschreibt die Laktatdehydrogenase (LDH) Laborwerte beim Malignen Melanom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-melanom-sicherheitsabstand"
      },
      "name" : "MII PR Onkologie Melanom Sicherheitsabstand",
      "description" : "Dieses Profil beschreibt den minimalen Sicherheitsabstand zum Primärtumor beim Malignen Melanom basierend auf oBDS Feld MM1. Bei nicht beurteilbaren Fällen (oBDS Wert -1) wird dataAbsentReason verwendet statt valueQuantity.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-melanom-ulzeration"
      },
      "name" : "MII PR Onkologie Melanom Ulzeration",
      "description" : "Dieses Profil beschreibt die Ulzeration beim Malignen Melanom der Haut",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-mamma-menopause-status"
      },
      "name" : "MII PR Onkologie Menopausenstatus Mamma",
      "description" : "Dieses Profil beschreibt den (prätherapeutischen) Menopausenstatus einer Patientin mit Mamma-Karzinom in der Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-nebenwirkung-adverse-event"
      },
      "name" : "MII PR Onkologie Nebenwirkung von Strahlentherapie und systemische Therapie",
      "description" : "Dieses Profil beschreibt die Nebenwirkung von Strahlentherapie und systemische Therapie in der Onkologie.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-operation"
      },
      "name" : "MII PR Onkologie Operation",
      "description" : "Operation nach OPS inklusive Intention, Datum und Komplikationen:",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-prostate-anzahl-positive-stanzen"
      },
      "name" : "MII PR Onkologie Prostata Anzahl positiver Stanzen",
      "description" : "Dieses Profil beschreibt die Anzahl positiver Stanzen einer Prostata-Biopsie in der Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-prostate-anzahl-stanzen"
      },
      "name" : "MII PR Onkologie Prostata Anzahl Stanzen",
      "description" : "Dieses Profil beschreibt die Anzahl Stanzen einer Prostata-Biopsie oder eines Prostata-Exzisionspräparates in der Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-prostate-gleason-grade-group"
      },
      "name" : "MII PR Onkologie Prostata Gleason Grade Group",
      "description" : "Dieses Profil beschreibt einen Gleasonscore in der Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-prostate-gleason-patterns"
      },
      "name" : "MII PR Onkologie Prostata Gleason Primär",
      "description" : "Dieses Profil beschreibt einen primären Gleasonscore in der Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-krk-operation"
      },
      "name" : "MII PR Onkologie Präoperative Drahtmarkierung Mamma",
      "description" : "Das vorliegende Profil beschreibt eine radiologisch durchgeführte Markierung von Tumorgewebe mittels  der Brust. Dabei können verschiedene Methoden gewählt werden. Die",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-mamma-sozialdienst"
      },
      "name" : "MII PR Onkologie Präoperative Drahtmarkierung Mamma",
      "description" : "Das vorliegende Profil beschreibt eine radiologisch durchgeführte Markierung von Tumorgewebe mittels  der Brust. Dabei können verschiedene Methoden gewählt werden. Die",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-mamma-praeoperative-markierung"
      },
      "name" : "MII PR Onkologie Präoperative Markierung Mamma",
      "description" : "Das vorliegende Profil beschreibt eine präoperativ durchgeführte Markierung von Tumorgewebe in der Brust. Dabei können verschiedene Markierungsmodalitäten gewählt werden, wie z.B. Drahtmarkierungen, Seed-Markierungen oder andere Lokalisationstechniken.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-prostate-psa"
      },
      "name" : "MII PR Onkologie PSA-Wert",
      "description" : "Dieses Profil beschreibt den PSA-Wert sowohl beim Monitoring als auch in der Verlaufskontrolle in der Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-residualstatus"
      },
      "name" : "MII PR Onkologie Residualstatus",
      "description" : "Umfang eines Residualtumors nach einer Therapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-mamma-rezeptorstatus-estrogen"
      },
      "name" : "MII PR Onkologie Rezeptorstatus Estrogen",
      "description" : "Dieses Profil beschreibt den diagnostischen Estrogen-Rezeptorstatus eines pathologisch untersuchten Probe beim Mamma-Karzinom in der Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-mamma-rezeptorstatus-progesteron"
      },
      "name" : "MII PR Onkologie Rezeptorstatus Progesteron",
      "description" : "Dieses Profil beschreibt den diagnostischen Progesteron-Rezeptorstatus eines pathologisch untersuchten Probe beim Mamma-Karzinom in der Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-specimen"
      },
      "name" : "MII PR Onkologie Specimen",
      "description" : "Histologie: Dieses Profil beschreibt eine Gewebeprobe in der Onkologie.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-krk-specimen"
      },
      "name" : "MII PR Onkologie Specimen",
      "description" : "Histologie: Dieses Profil beschreibt eine Gewebeprobe in der Onkologie.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-strahlentherapie-bestrahlung-strahlentherapie"
      },
      "name" : "MII PR Onkologie Strahlentherapie",
      "description" : "Strahlentherapie. Dieses Profil beschreibt eine Strahlentherapie in der Onkologie.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-strahlentherapie"
      },
      "name" : "MII PR Onkologie Strahlentherapie",
      "description" : "Strahlentherapie. Dieses Profil beschreibt eine Strahlentherapie in der Onkologie.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-strahlentherapie-bestrahlung-nuklearmedizin"
      },
      "name" : "MII PR Onkologie Strahlentherapie Nuklearmedizin",
      "description" : "Strahlentherapie. Dieses Profil beschreibt eine Nuklearmedizinische  in der Onkologie.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-studienteilnahme"
      },
      "name" : "MII PR Onkologie Studienteilnahme",
      "description" : "Dieses Profil beschreibt Studienteilnahmen in der Onkologie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-systemische-therapie"
      },
      "name" : "MII PR Onkologie Systemische Therapie",
      "description" : "Systemische Therapie. Dieses Profil beschreibt eine Systemische Therapie für den oBDS. Da die Granularität der Anforderungen des oBDS nicht deckungsgleich mit den FHIR-Profilen für Medikation sind, wurde die Systemische Therapie als Prozedur umgesetzt",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
      },
      "name" : "MII PR Onkologie Systemische Therapie Medikation",
      "description" : "Medikation der Systemische Therapie. Dieses Profil beschreibt die konkreten Medikationen, die im Rahmen der systemische Therapie für den oBDS dokumentiert werden.  Da im oBDS systemische und abwartende Therapie in einem Feld gruppiert sind, werden die Daten für die Systemische und abwartende Therapie sowohl über eine FHIR-Prozedur (systemisch und abwartend) als auch als FHIR-Medikation abgedeckt.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-therapieempfehlung-kombinationstherapie"
      },
      "name" : "MII PR Onkologie Therapieempfehlung Kombinationstherapie",
      "description" : "Dieses Profil beschreibt eine Empfehlung für eine Kombinationstherapie im Rahmen der Tumorkonferenz",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"
      },
      "name" : "MII PR Onkologie Therapieempfehlung Medikation",
      "description" : "Dieses Profil beschreibt eine Medikations-Tumorempfehlung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-therapieempfehlung-operation"
      },
      "name" : "MII PR Onkologie Therapieempfehlung Operation",
      "description" : "Dieses Profil beschreibt eine Empfehlung für eine Operation im Rahmen der Tumorkonferenz",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tnm-a-symbol"
      },
      "name" : "MII PR Onkologie TNM a-Symbol",
      "description" : "TNM-Klassifikation: TNM a-Symbol. Gibt an, ob die Klassifikation aus Anlass einer Autopsie erfolgte.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tnm-l-kategorie"
      },
      "name" : "MII PR Onkologie TNM L-Kategorie",
      "description" : "TNM-Klassifikation: TNM L-Kategorie. Lymphgefäßinvasion.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tnm-m-kategorie"
      },
      "name" : "MII PR Onkologie TNM M-Kategorie",
      "description" : "TNM-Klassifikation: TNM M-Kategorie. Fehlen oder Vorhandensein von Fernmetastasen, gemäß Tumorentität nach TNM.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tnm-m-symbol"
      },
      "name" : "MII PR Onkologie TNM m-Symbol",
      "description" : "TNM-Klassifikation: TNM m-Symbol. Kennzeichnet Vorhandensein multipler Primärtumoren in einem anatomischen Bezirk.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tnm-n-kategorie"
      },
      "name" : "MII PR Onkologie TNM N-Kategorie",
      "description" : "TNM-Klassifikation: TNM N-Kategorie. Ausbreitung von regionären Lymphknotenmetastasen, erfolgt gemäß Tumorentität nach TNM.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tnm-pn-kategorie"
      },
      "name" : "MII PR Onkologie TNM Pn-Kategorie",
      "description" : "TNM-Klassifikation: TNM Pn-Kategorie. Perineuralinvasion.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tnm-r-symbol"
      },
      "name" : "MII PR Onkologie TNM r-Symbol",
      "description" : "TNM-Klassifikation: TNM r-Symbol. Gibt an, ob die Klassifikation ein Rezidiv beurteilt.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tnm-s-kategorie"
      },
      "name" : "MII PR Onkologie TNM S-Kategorie",
      "description" : "TNM-Klassifikation: TNM S-Kategorie. Serumtumormarker.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tnm-t-kategorie"
      },
      "name" : "MII PR Onkologie TNM T-Kategorie",
      "description" : "TNM-Klassifikation: TNM T-Kategorie. Ausbreitung des Primärtumors, erfolgt gemäß Tumorentität nach TNM.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tnm-v-kategorie"
      },
      "name" : "MII PR Onkologie TNM V-Kategorie",
      "description" : "TNM-Klassifikation: TNM V-Kategorie. Veneninvasion.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tnm-y-symbol"
      },
      "name" : "MII PR Onkologie TNM y-Symbol",
      "description" : "TNM-Klassifikation: TNM y-Symbol. Gibt an, ob die Klassifikation während oder nach initialer multimodaler Therapie erfolgte.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tnm-klassifikation"
      },
      "name" : "MII PR Onkologie TNM-Klassifikation",
      "description" : "TNM-Klassifikation: Grouper-Profil für Komponenten der TNM-Klassifikation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tod"
      },
      "name" : "MII PR Onkologie Tod",
      "description" : "Tumorbedingter Tod",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tumorgroesse"
      },
      "name" : "MII PR Onkologie Tumorgröße",
      "description" : "Tumorgröße in mm. Gibt die Größe des Tumors in der größten Dimension an. Basierend auf dem oBDS-Modul Mamma.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-tumorkonferenz"
      },
      "name" : "MII PR Onkologie Tumorkonferenz",
      "description" : "Dieses Profil beschreibt die Tumorkonferenz und die Therapieempfehlungen",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-verlauf"
      },
      "name" : "MII PR Onkologie Verlauf",
      "description" : "Dieses Profil beschreibt die Verlaufskontrolle und verweist ggfs. auf andere verlaufsrelevante diagnostische Maßnahmen",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/mii-pr-onko-weitere-klassifikationen"
      },
      "name" : "MII PR Onkologie Weitere Klassifikationen",
      "description" : "Weitere Tumor Staging Klassifikation neben TMN (Hämatoonkologische und sonstige Klassifikationen)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-weitere-klassifikationen"
      },
      "name" : "MII Value Set Onkologie - Weitere Klassifikationen",
      "description" : "Comprehensive collection of cancer staging systems and classification schemes used in oncology beyond TNM classification. This includes AJCC, FIGO, hematological classifications, and specialized organ-specific systems. Based on mCODE STU4 and German oBDS catalogue. Covers entity-specific classifications (e.g., FIGO for gynecological tumors), hematological classifications, and WHO classifications for CNS tumors.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-weitere-klassifikationen-auspraegungen"
      },
      "name" : "MII Value Set Onkologie - Weitere Klassifikationen - Auspraegungen",
      "description" : "Comprehensive collection of cancer staging systems and classification schemes used in oncology beyond TNM classification. This includes AJCC, FIGO, hematological classifications, and specialized organ-specific systems. Based on mCODE STU4 and German oBDS catalogue. Covers entity-specific classifications (e.g., FIGO for gynecological tumors), hematological classifications, and WHO classifications for CNS tumors.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-melanom-exzision-snomedct"
      },
      "name" : "MII VS Onko Melanom Exzision SNOMED CT",
      "description" : "Value Set für Melanom-spezifische Exzisionen basierend auf SNOMED CT. Enthält den Code für Melanom-Exzision. Weitere anatomische Details können über bodySite kodiert werden.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-prostata-operation-snomedct"
      },
      "name" : "MII VS Onko Prostata Operation SNOMED CT",
      "description" : "Value Set für Prostata-spezifische Operationen basierend auf SNOMED CT. Enthält alle Kinder von 118877007 |Procedure on prostate (procedure)|",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-prostata-psa-loinc"
      },
      "name" : "MII VS Onko Prostata PSA LOINC",
      "description" : "Value Set für Prostata-spezifisches Antigen (PSA) LOINC Codes. Enthält LOINC Codes für Total-PSA und freies PSA, exkludiert gebundenes PSA Messungen.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-allgemeiner-leistungszustand-ecog"
      },
      "name" : "MII VS Onkologie Allgemeiner Leistungszustand nach ECOG",
      "description" : "Value Set für oBDS-Codes für den Allgemeinen Leistungszustand nach ECOG",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-allgemeiner-leistungszustand-karnofsky"
      },
      "name" : "MII VS Onkologie Allgemeiner Leistungszustand nach Karnofsky",
      "description" : "Value Set für oBDS-Codes für den Allgemeinen Leistungszustand nach Karnofsky",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-beurteilung-lokaler-residualstatus"
      },
      "name" : "MII VS Onkologie Beurteilung des lokalen Residualstatus",
      "description" : "Value Set für oBDS-Codes für die Beurteilung des lokalen Residualstatus",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-fernmetastasen"
      },
      "name" : "MII VS Onkologie Fernmetastasen",
      "description" : "Value Set für oBDS-Codes für Fernmetastasen",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-gesamtbeurteilung-residualstatus"
      },
      "name" : "MII VS Onkologie Gesamtbeurteilung des Residualstatus",
      "description" : "Value Set für oBDS-Codes für die Gesamtbeurteilung des Residualstatus",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-grading"
      },
      "name" : "MII VS Onkologie Grading",
      "description" : "Codes für Histologie Grading. Gibt den Differenzierungsgrad des Tumors entsprechend der aktuellen TNM-Auflage an.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-icdo3-morphologie"
      },
      "name" : "MII VS Onkologie ICD-O-3 Morphologie",
      "description" : "Codes für histologische Morphologie und Verhalten einer neoplastischen Veränderung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-icdo3-topographie"
      },
      "name" : "MII VS Onkologie ICD-O-3 Topographie",
      "description" : "Codes für Topographie einer neoplastischen Veränderung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-mamma-her2neu-status-leitlinie"
      },
      "name" : "MII VS Onkologie Mamma Her2neu Status Leitlinie",
      "description" : "Value Set für Her2neu Status nach S3-Leitlinie und ASCO/CAP Guidelines",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-mamma-her2neu-status-obds"
      },
      "name" : "MII VS Onkologie Mamma Her2neu Status oBDS",
      "description" : "Value Set für Her2neu Status nach oBDS",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-melanom-ulzeration"
      },
      "name" : "MII VS Onkologie Melanom Ulzeration",
      "description" : "Codes für die Ulzeration beim Malignen Melanom der Haut",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-nebenwirkung-art"
      },
      "name" : "MII VS Onkologie Nebenwirkung nach CTCAE Art",
      "description" : "oBDS-spezifisches ValueSet für Nebenwirkung nach CTCAE oder MedDRA code",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-nebenwirkung-ctcae-grad"
      },
      "name" : "MII VS Onkologie Nebenwirkung nach CTCAE Grad",
      "description" : "oBDS-spezifisches ValueSet für Nebenwirkung nach CTCAE-Grad",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-operation-intention"
      },
      "name" : "MII VS Onkologie Operation Intention",
      "description" : "Value Set für oBDS-Codes für Klassifikation von Intention der OP",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-operation-komplikation"
      },
      "name" : "MII VS Onkologie Operation Komplikationen",
      "description" : "Value Set für oBDS-Codes für Klassifikation von Komplikationen während der OP",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-ops-nuklearmedizin"
      },
      "name" : "MII VS Onkologie OPS Nuklearmedizin",
      "description" : "OPS-Codes für Nuklearmedizinische Therapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-ops-strahlentherapie"
      },
      "name" : "MII VS Onkologie OPS Strahlentherapie",
      "description" : "OPS-Codes für Strahlentherapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-primaertumor-diagnosesicherung"
      },
      "name" : "MII VS Onkologie Primärtumor Diagnosesicherung",
      "description" : "Codes für Primärtumor Diagnosesicherung, d.h. die höchste erreichte Diagnosesicherheit der Diagnose.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-seitenlokalisation"
      },
      "name" : "MII VS Onkologie Primärtumor Seitenlokalisation",
      "description" : "Codes für Seitenlokalisation, d.h. organspezifische Angabe der betroffenen Seite.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-prostata-gleason-patterns"
      },
      "name" : "MII VS Onkologie Prostata Gleason Patterns",
      "description" : "Value Set für die histopathologische Bewertung von Prostata-Adenokarzinomen mittels Gleason-Patterns. Dieser Value Set wird verwendet, um die verschiedenen Gleason-Patterns zu kodieren, die bei der Beurteilung von Prostatakarzinomen auftreten können.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-strahlentherapie-applikationsart"
      },
      "name" : "MII VS Onkologie Strahlentherapie Applikationsart",
      "description" : "oBDS-spezifisches Codesystem für Klassifikation von Applikationsart der Strahlentherapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-strahlentherapie-boost"
      },
      "name" : "MII VS Onkologie Strahlentherapie Boost",
      "description" : "oBDS-spezifisches ValueSet für Klassifikation von Boosts bei Strahlentherapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-strahlentherapie-ende-grund"
      },
      "name" : "MII VS Onkologie Strahlentherapie Ende Grund",
      "description" : "oBDS-spezifisches ValueSet für Klassifikation des Grundes der Beendigung der Strahlentherapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-strahlentherapie-intention"
      },
      "name" : "MII VS Onkologie Strahlentherapie Intention",
      "description" : "Value Set für oBDS-Codes für Klassifikation von Intention der Strahlentherapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-strahlentherapie-stellungzurop"
      },
      "name" : "MII VS Onkologie Strahlentherapie Stellung zur OP",
      "description" : "oBDS-spezifisches ValueSet für Klassifikation von Stellung zur OP",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-strahlentherapie-strahlenart"
      },
      "name" : "MII VS Onkologie Strahlentherapie Strahlenart",
      "description" : "oBDS-spezifisches ValueSet für Klassifikation von Strahlenart bei Strahlentherapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-strahlentherapie-strahlungseinheit"
      },
      "name" : "MII VS Onkologie Strahlentherapie Strahlungseinheit",
      "description" : "oBDS-spezifisches ValueSet für Strahlungseinheit en für Strahlen- und Nuklearmedizinische Therapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-strahlentherapie-zielgebiet"
      },
      "name" : "MII VS Onkologie Strahlentherapie Zielgebiet",
      "description" : "oBDS-spezifisches ValueSet für Klassifikation von Zielgebiet bei Strahlentherapie - unterstützt sowohl oBDS 2021 als auch oBDS 2014 Legacy-Codes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-studienteilnahme"
      },
      "name" : "MII VS Onkologie Studienteilnahme",
      "description" : "Value Set für oBDS-Codes des Studienteilnahme Status",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-art"
      },
      "name" : "MII VS Onkologie Systemische Therapie Art",
      "description" : "oBDS-spezifisches ValueSet für Klassifikation der Art der systemischen oder abwartenden Therapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-ende-grund"
      },
      "name" : "MII VS Onkologie Systemische Therapie Ende Grund",
      "description" : "oBDS-spezifisches ValueSet für Klassifikation des Grundes der Beendigung der Systemischen Therapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-intention"
      },
      "name" : "MII VS Onkologie Systemische Therapie Intention",
      "description" : "Value Set für oBDS-Codes für Klassifikation von Intention der Systemischen Therapie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-protokolle"
      },
      "name" : "MII VS Onkologie Systemische Therapie Protokolle",
      "description" : "oBDS-spezifisches ValueSet für Protokolle systemischer Therapien",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-stellungzurop"
      },
      "name" : "MII VS Onkologie Systemische Therapie Stellung",
      "description" : "oBDS-spezifisches ValueSet für Klassifikation von Stellung zur OP",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-substanzen"
      },
      "name" : "MII VS Onkologie Systemische Therapie Substanzen",
      "description" : "Validierte ATC-Codes für Substanzen der systemischen Therapie basierend auf oBDS Umsetzungsleitfaden. Automatisch generiert und gegen MII-Terminologieserver validiert.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-substanzen-unii"
      },
      "name" : "MII VS Onkologie Systemische Therapie Substanzen (UNII)",
      "description" : "UNII-Codes für Substanzen der systemischen Therapie ohne ATC-Code. Ergänzung zum ATC-basierten Haupt-ValueSet für neuere und experimentelle onkologische Wirkstoffe.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-substanzen-2018"
      },
      "name" : "MII VS Onkologie Systemische Therapie Substanzen ATC 2018",
      "description" : "ATC-Codes für Substanzen der systemischen Therapie, validiert gegen ATC-DE Version 2018. Für historische Datenvalidierung.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-substanzen-2019"
      },
      "name" : "MII VS Onkologie Systemische Therapie Substanzen ATC 2019",
      "description" : "ATC-Codes für Substanzen der systemischen Therapie, validiert gegen ATC-DE Version 2019. Für historische Datenvalidierung.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-substanzen-2020"
      },
      "name" : "MII VS Onkologie Systemische Therapie Substanzen ATC 2020",
      "description" : "ATC-Codes für Substanzen der systemischen Therapie, validiert gegen ATC-DE Version 2020. Für historische Datenvalidierung.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-substanzen-2021"
      },
      "name" : "MII VS Onkologie Systemische Therapie Substanzen ATC 2021",
      "description" : "ATC-Codes für Substanzen der systemischen Therapie, validiert gegen ATC-DE Version 2021. Für historische Datenvalidierung.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-substanzen-2022"
      },
      "name" : "MII VS Onkologie Systemische Therapie Substanzen ATC 2022",
      "description" : "ATC-Codes für Substanzen der systemischen Therapie, validiert gegen ATC-DE Version 2022. Für historische Datenvalidierung.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-substanzen-2023"
      },
      "name" : "MII VS Onkologie Systemische Therapie Substanzen ATC 2023",
      "description" : "ATC-Codes für Substanzen der systemischen Therapie, validiert gegen ATC-DE Version 2023. Für historische Datenvalidierung.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-substanzen-2024"
      },
      "name" : "MII VS Onkologie Systemische Therapie Substanzen ATC 2024",
      "description" : "ATC-Codes für Substanzen der systemischen Therapie, validiert gegen ATC-DE Version 2024. Für historische Datenvalidierung.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-substanzen-2025"
      },
      "name" : "MII VS Onkologie Systemische Therapie Substanzen ATC 2025",
      "description" : "ATC-Codes für Substanzen der systemischen Therapie, validiert gegen ATC-DE Version 2025. Für historische Datenvalidierung.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-systemische-therapie-substanzen-2026"
      },
      "name" : "MII VS Onkologie Systemische Therapie Substanzen ATC 2026",
      "description" : "ATC-Codes für Substanzen der systemischen Therapie, validiert gegen ATC-DE Version 2026. Für historische Datenvalidierung.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-therapieabweichung"
      },
      "name" : "MII VS Onkologie Therapieabweichung",
      "description" : "oBDS-spezifisches ValueSet für die Therapieabweichung auf Wunsch des Patients.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-therapieempfehlung-typ"
      },
      "name" : "MII VS Onkologie Therapieempfehlung Typ",
      "description" : "oBDS-spezifisches ValueSet für den Therapieempfehlungstyp",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-therapieplanung-typ"
      },
      "name" : "MII VS Onkologie Therapieplanung Typ",
      "description" : "oBDS-spezifisches ValueSet für den Therapieplanungstyp",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-cp-praefix"
      },
      "name" : "MII VS Onkologie TNM c/p/u Praefix",
      "description" : "Codes für TNM c/p/u-Präfix. Gibt an, ob die Klassifikation klinisch (c), pathologisch (p) oder mittels Ultraschall (u) erfolgte.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-itc-suffix"
      },
      "name" : "MII VS Onkologie TNM ITC Suffix",
      "description" : "Das ValueSet enthält die isolierten Tumorzellen (ITC) Suffixe für die N- und M-Kategorien aus der UICC TNM - Klassifikation maligner Tumoren Achte Auflage.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-klassifikation-typ"
      },
      "name" : "MII VS Onkologie TNM Klassifikation Typ",
      "description" : "Codes für TNM-Klassifikation Typ. Gibt an, ob die Klassifikation klinisch oder pathologisch erfolgte.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-l-kategorie-werte"
      },
      "name" : "MII VS Onkologie TNM L Kategorie Werte",
      "description" : "Das ValueSet enthält die TNM Codes für die Beurteilung der Lymphgefäßinvasion aus der UICC TNM - Klassifikation maligner Tumoren Achte Auflage.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-m-kategorie"
      },
      "name" : "MII VS Onkologie TNM M Kategorie",
      "description" : "Codes für Codes zur Differenzierung der TNM M-Kategorie als entweder klinisch (cN) oder pathologisch (pN)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-m-kategorie-werte"
      },
      "name" : "MII VS Onkologie TNM M Kategorie Werte",
      "description" : "Das ValueSet enthält die TNM M-Kategorie Codes aus der UICC TNM - Klassifikation maligner Tumoren Achte Auflage.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-m-symbol"
      },
      "name" : "MII VS Onkologie TNM m-Symbol",
      "description" : "Kennzeichnet Vorhandensein multipler Primärtumoren in einem anatomischen Bezirk.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-n-kategorie"
      },
      "name" : "MII VS Onkologie TNM N Kategorie",
      "description" : "Codes für Codes zur Differenzierung der TNM N-Kategorie als entweder klinisch (cN) oder pathologisch (pN)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-n-kategorie-werte"
      },
      "name" : "MII VS Onkologie TNM N Kategorie Werte",
      "description" : "Das ValueSet enthält die TNM N-Kategorie Codes aus der UICC TNM - Klassifikation maligner Tumoren Achte Auflage.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-pn-kategorie-werte"
      },
      "name" : "MII VS Onkologie TNM Pn Kategorie Werte",
      "description" : "Das ValueSet enthält die TNM Codes für den Grad der perineuralen Invasion aus der UICC TNM - Klassifikation maligner Tumoren Achte Auflage.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-s-kategorie-werte"
      },
      "name" : "MII VS Onkologie TNM S Kategorie Werte",
      "description" : "Das ValueSet enthält die TNM Codes für Serumtumormarker aus der UICC TNM - Klassifikation maligner Tumoren Achte Auflage.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-sn-suffix"
      },
      "name" : "MII VS Onkologie TNM SN Suffix",
      "description" : "Das ValueSet enthält das Schildwächterlymphknoten (Sentinel Lymph Node) Suffix für die N-Kategorie aus der UICC TNM - Klassifikation maligner Tumoren Achte Auflage.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-t-kategorie"
      },
      "name" : "MII VS Onkologie TNM T Kategorie",
      "description" : "Codes für Codes zur Differenzierung der TNM T-Kategorie als entweder klinisch (cT) oder pathologisch (pT)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-t-kategorie-werte"
      },
      "name" : "MII VS Onkologie TNM T Kategorie Werte",
      "description" : "Das ValueSet enthält die TNM T-Kategorie Codes aus der UICC TNM - Klassifikation maligner Tumoren Achte Auflage.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-uicc-stadium"
      },
      "name" : "MII VS Onkologie TNM UICC Stadium",
      "description" : "The ValueSet enthält Codes für die TNM-Stadien zur prognostischen Gruppeneinteilung von Patienten.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-v-kategorie-werte"
      },
      "name" : "MII VS Onkologie TNM V Kategorie Werte",
      "description" : "Das ValueSet enthält die TNM Codes für die Beurteilung der Veneninvasion aus der UICC TNM - Klassifikation maligner Tumoren Achte Auflage.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tnm-version"
      },
      "name" : "MII VS Onkologie TNM Version",
      "description" : "Codes für TNM Version/Auflage nach welcher Version des TNM klassifiziert wird.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-tod"
      },
      "name" : "MII VS Onkologie Tod",
      "description" : "Value Set für oBDS-Codes turmorbedingter Tod",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-verlauf-fernmetastasen"
      },
      "name" : "MII VS Onkologie Verlauf Fernmetastasen",
      "description" : "oBDS-spezifisches ValueSet für die Beurteilung der Fernmetastasen im Behandlungsverlauf",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-verlauf-gesamtbeurteilung"
      },
      "name" : "MII VS Onkologie Verlauf Gesamtbeurteilung",
      "description" : "oBDS-spezifisches ValueSet für die Gesamtbeurteilung im Behandlungsverlauf",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-verlauf-lymphknoten"
      },
      "name" : "MII VS Onkologie Verlauf Lymphknoten",
      "description" : "oBDS-spezifisches ValueSet für die Beurteilung der Lymphknoten im Behandlungsverlauf",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-verlauf-primaertumor"
      },
      "name" : "MII VS Onkologie Verlauf Primärtumor",
      "description" : "oBDS-spezifisches ValueSet für die Beurteilung des Primärtumors im Behandlungsverlauf",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/mii-cm-mii-to-mvgenomseq-condition-diagnose-primaertumor"
      },
      "name" : "mii-cm-mii-to-mvgenomseq-condition-diagnose-primaertumor",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-allgemeiner-leistungszustand-ecog"
      },
      "name" : "mii-exa-onko-allgemeiner-leistungszustand-ecog",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-allgemeiner-leistungszustand-ecog"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-allgemeiner-leistungszustand-karnofsky"
      },
      "name" : "mii-exa-onko-allgemeiner-leistungszustand-karnofsky",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-allgemeiner-leistungszustand-karnofsky"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-anzahl-befallene-lymphknoten-0"
      },
      "name" : "mii-exa-onko-anzahl-befallene-lymphknoten-0",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-befallene-lymphknoten"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-anzahl-befallene-sentinel-lymphknoten-0"
      },
      "name" : "mii-exa-onko-anzahl-befallene-sentinel-lymphknoten-0",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-befallene-sentinel-lymphknoten"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-anzahl-untersuchte-lymphknoten-23"
      },
      "name" : "mii-exa-onko-anzahl-untersuchte-lymphknoten-23",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-untersuchte-lymphknoten"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-anzahl-untersuchte-sentinel-lymphknoten-0"
      },
      "name" : "mii-exa-onko-anzahl-untersuchte-sentinel-lymphknoten-0",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-anzahl-untersuchte-sentinel-lymphknoten"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-asa-klassifikation"
      },
      "name" : "mii-exa-onko-asa-klassifikation",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-asa-klassifikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/mii-exa-onko-befund-1"
      },
      "name" : "mii-exa-onko-befund-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-befund"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-onko-cdk46-class-medication"
      },
      "name" : "mii-exa-onko-cdk46-class-medication",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-onko-diagnose"
      },
      "name" : "mii-exa-onko-diagnose",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-fernmetastasen-1"
      },
      "name" : "mii-exa-onko-fernmetastasen-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-fernmetastasen"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-genetische-variante-braf"
      },
      "name" : "mii-exa-onko-genetische-variante-braf",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-genetische-variante"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-grading-1"
      },
      "name" : "mii-exa-onko-grading-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-grading"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-histologie-icdo3"
      },
      "name" : "mii-exa-onko-histologie-icdo3",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-histologie-icdo3"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-onko-krk-bundle-encounter"
      },
      "name" : "mii-exa-onko-krk-bundle-encounter",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-onko-krk-bundle-patient"
      },
      "name" : "mii-exa-onko-krk-bundle-patient",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-onko-krk-diagnose"
      },
      "name" : "mii-exa-onko-krk-diagnose",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-onko-mamma-bundle-encounter"
      },
      "name" : "mii-exa-onko-mamma-bundle-encounter",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-onko-mamma-bundle-patient"
      },
      "name" : "mii-exa-onko-mamma-bundle-patient",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-onko-mamma-diagnose"
      },
      "name" : "mii-exa-onko-mamma-diagnose",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-mamma-menopause-status-1"
      },
      "name" : "mii-exa-onko-mamma-menopause-status-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-menopause-status"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-mamma-praeoperative-markierung-1"
      },
      "name" : "mii-exa-onko-mamma-praeoperative-markierung-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-praeoperative-markierung"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-mamma-rezeptorstatus-estrogen-1"
      },
      "name" : "mii-exa-onko-mamma-rezeptorstatus-estrogen-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-rezeptorstatus-estrogen"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-mamma-rezeptorstatus-progesteron-1"
      },
      "name" : "mii-exa-onko-mamma-rezeptorstatus-progesteron-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-mamma-rezeptorstatus-progesteron"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-mamma-tumorgroesse-1"
      },
      "name" : "mii-exa-onko-mamma-tumorgroesse-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorgroesse"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-onko-melanom-bundle-encounter"
      },
      "name" : "mii-exa-onko-melanom-bundle-encounter",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-onko-melanom-bundle-patient"
      },
      "name" : "mii-exa-onko-melanom-bundle-patient",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-onko-melanom-diagnose"
      },
      "name" : "mii-exa-onko-melanom-diagnose",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RequestGroup"
      }],
      "reference" : {
        "reference" : "RequestGroup/mii-exa-onko-molecular-cdk46-protocol"
      },
      "name" : "mii-exa-onko-molecular-cdk46-protocol",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-kombinationstherapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "RequestGroup"
      }],
      "reference" : {
        "reference" : "RequestGroup/mii-exa-onko-molecular-her2-alternatives"
      },
      "name" : "mii-exa-onko-molecular-her2-alternatives",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-kombinationstherapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      }],
      "reference" : {
        "reference" : "ServiceRequest/mii-exa-onko-molecular-surgery-request"
      },
      "name" : "mii-exa-onko-molecular-surgery-request",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-palbociclib-therapie"
      },
      "name" : "mii-exa-onko-palbociclib-therapie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-pertuzumab-therapie"
      },
      "name" : "mii-exa-onko-pertuzumab-therapie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-prostata-anzahl-positiver-stanzen-1"
      },
      "name" : "mii-exa-onko-prostata-anzahl-positiver-stanzen-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-anzahl-positive-stanzen"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-prostata-anzahl-stanzen-1"
      },
      "name" : "mii-exa-onko-prostata-anzahl-stanzen-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-anzahl-stanzen"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      }],
      "reference" : {
        "reference" : "Encounter/mii-exa-onko-prostata-bundle-encounter"
      },
      "name" : "mii-exa-onko-prostata-bundle-encounter",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-onko-prostata-bundle-patient"
      },
      "name" : "mii-exa-onko-prostata-bundle-patient",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-prostata-ca-befall-stanze-1"
      },
      "name" : "mii-exa-onko-prostata-ca-befall-stanze-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-ca-befall-stanze"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/mii-exa-onko-prostata-diagnose"
      },
      "name" : "mii-exa-onko-prostata-diagnose",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-prostata-gleason-pattern-grade-group-1"
      },
      "name" : "mii-exa-onko-prostata-gleason-pattern-grade-group-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-gleason-grade-group"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-prostata-gleason-pattern-primary-1"
      },
      "name" : "mii-exa-onko-prostata-gleason-pattern-primary-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-gleason-patterns"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-prostata-gleason-pattern-secondary-1"
      },
      "name" : "mii-exa-onko-prostata-gleason-pattern-secondary-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-gleason-patterns"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-prostata-psa-diagnose-1"
      },
      "name" : "mii-exa-onko-prostata-psa-diagnose-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-psa"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-prostata-psa-verlauf-1"
      },
      "name" : "mii-exa-onko-prostata-psa-verlauf-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-psa"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-prostata-surgery-1"
      },
      "name" : "mii-exa-onko-prostata-surgery-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-operation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-prostata-surgical-complication-1"
      },
      "name" : "mii-exa-onko-prostata-surgical-complication-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostate-clavien-dindo"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-residualstatus-1"
      },
      "name" : "mii-exa-onko-residualstatus-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-residualstatus"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      }],
      "reference" : {
        "reference" : "Specimen/mii-exa-onko-specimen-1"
      },
      "name" : "mii-exa-onko-specimen-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-specimen"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-studienteilnahme"
      },
      "name" : "mii-exa-onko-studienteilnahme",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-studienteilnahme"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-onko-tdm1-option"
      },
      "name" : "mii-exa-onko-tdm1-option",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tnm-klassifikation-TisN0M0"
      },
      "name" : "mii-exa-onko-tnm-klassifikation-TisN0M0",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-klassifikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tnm-klassifikation-uT2a2pN0023i-sncM1"
      },
      "name" : "mii-exa-onko-tnm-klassifikation-uT2a2pN0023i-sncM1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-klassifikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tnm-l-kategorie-L"
      },
      "name" : "mii-exa-onko-tnm-l-kategorie-L",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-l-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tnm-l-kategorie-L1"
      },
      "name" : "mii-exa-onko-tnm-l-kategorie-L1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-l-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tnm-m-kategorie-cM1"
      },
      "name" : "mii-exa-onko-tnm-m-kategorie-cM1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-m-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tnm-m-kategorie-M0"
      },
      "name" : "mii-exa-onko-tnm-m-kategorie-M0",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-m-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tnm-n-kategorie-N0"
      },
      "name" : "mii-exa-onko-tnm-n-kategorie-N0",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tnm-n-kategorie-pN0i-sn"
      },
      "name" : "mii-exa-onko-tnm-n-kategorie-pN0i-sn",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tnm-pn-kategorie-Pn1"
      },
      "name" : "mii-exa-onko-tnm-pn-kategorie-Pn1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-pn-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tnm-s-kategorie-S1"
      },
      "name" : "mii-exa-onko-tnm-s-kategorie-S1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-s-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tnm-t-kategorie-Tis"
      },
      "name" : "mii-exa-onko-tnm-t-kategorie-Tis",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-t-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tnm-t-kategorie-uT2a2"
      },
      "name" : "mii-exa-onko-tnm-t-kategorie-uT2a2",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-t-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tnm-v-kategorie-V1"
      },
      "name" : "mii-exa-onko-tnm-v-kategorie-V1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-v-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tod-j"
      },
      "name" : "mii-exa-onko-tod-j",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tod"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tod-n"
      },
      "name" : "mii-exa-onko-tod-n",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tod"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tod-u"
      },
      "name" : "mii-exa-onko-tod-u",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tod"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-trastuzumab-therapie"
      },
      "name" : "mii-exa-onko-trastuzumab-therapie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationRequest"
      }],
      "reference" : {
        "reference" : "MedicationRequest/mii-exa-onko-tucatinib-option"
      },
      "name" : "mii-exa-onko-tucatinib-option",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-tumorgroesse"
      },
      "name" : "mii-exa-onko-tumorgroesse",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorgroesse"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-onko-tumorkonferenz-01"
      },
      "name" : "mii-exa-onko-tumorkonferenz-01",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-onko-tumorkonferenz-02"
      },
      "name" : "mii-exa-onko-tumorkonferenz-02",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-onko-tumorkonferenz-mixed-approach"
      },
      "name" : "mii-exa-onko-tumorkonferenz-mixed-approach",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-onko-tumorkonferenz-molekular"
      },
      "name" : "mii-exa-onko-tumorkonferenz-molekular",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-onko-tumorkonferenz-pure-molecular"
      },
      "name" : "mii-exa-onko-tumorkonferenz-pure-molecular",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-verlauf-tumor"
      },
      "name" : "mii-exa-onko-verlauf-tumor",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-verlauf"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-weitere-klassifikationen-1"
      },
      "name" : "mii-exa-onko-weitere-klassifikationen-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-weitere-klassifikationen"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-weitere-klassifikationen-2"
      },
      "name" : "mii-exa-onko-weitere-klassifikationen-2",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-weitere-klassifikationen"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-weitere-klassifikationen-3"
      },
      "name" : "mii-exa-onko-weitere-klassifikationen-3",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-weitere-klassifikationen"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-weitere-klassifikationen-4"
      },
      "name" : "mii-exa-onko-weitere-klassifikationen-4",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-weitere-klassifikationen"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AdverseEvent"
      }],
      "reference" : {
        "reference" : "AdverseEvent/mii-pr-onko-nebenwirkung-0"
      },
      "name" : "mii-pr-onko-nebenwirkung-0",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-nebenwirkung-adverse-event"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AdverseEvent"
      }],
      "reference" : {
        "reference" : "AdverseEvent/mii-pr-onko-nebenwirkung-text"
      },
      "name" : "mii-pr-onko-nebenwirkung-text",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-nebenwirkung-adverse-event"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-condition-ext-morphology-behavior-icdo3"
      },
      "name" : "mii-sp-onko-condition-ext-morphology-behavior-icdo3",
      "description" : "SearchParameter for Condition.extension[morphology-behaviour-icdo3]",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-ext-strahlentherapie-stellungzurop"
      },
      "name" : "mii-sp-onko-ext-strahlentherapie-stellungzurop",
      "description" : "SearchParameter for Procedure.extension[StellungZurOp]",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-ext-systemischetherapie-stellungzurop"
      },
      "name" : "mii-sp-onko-ext-systemischetherapie-stellungzurop",
      "description" : "SearchParameter for Procedure.extension[StellungZurOp]",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-observation-ext-tnm-m-cppraefix"
      },
      "name" : "mii-sp-onko-observation-ext-tnm-m-cppraefix",
      "description" : "SearchParameter for Observation.extension[cppraefix]",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-observation-ext-tnm-n-cppraefix"
      },
      "name" : "mii-sp-onko-observation-ext-tnm-n-cppraefix",
      "description" : "SearchParameter for Observation.extension[cppraefix]",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-observation-ext-tnm-n-itc"
      },
      "name" : "mii-sp-onko-observation-ext-tnm-n-itc",
      "description" : "SearchParameter for Observation.extension[itc]",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-observation-ext-tnm-n-sn-suffix"
      },
      "name" : "mii-sp-onko-observation-ext-tnm-n-sn-suffix",
      "description" : "SearchParameter for Observation.extension[sn-suffix]",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-observation-ext-tnm-t-cppraefix"
      },
      "name" : "mii-sp-onko-observation-ext-tnm-t-cppraefix",
      "description" : "SearchParameter for Observation.extension[cppraefix]",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-procedure-ext-operation-intention"
      },
      "name" : "mii-sp-onko-procedure-ext-operation-intention",
      "description" : "SearchParameter for Procedure.extension[intention]",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-procedure-ext-strahlentherapie-bs-boost"
      },
      "name" : "mii-sp-onko-procedure-ext-strahlentherapie-bs-boost",
      "description" : "SearchParameter for Procedure.extension:boost",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-procedure-ext-strahlentherapie-bs-einzeldosis"
      },
      "name" : "mii-sp-onko-procedure-ext-strahlentherapie-bs-einzeldosis",
      "description" : "SearchParameter for Procedure.extension:einzeldosis",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-procedure-ext-strahlentherapie-bs-gesamtdosis"
      },
      "name" : "mii-sp-onko-procedure-ext-strahlentherapie-bs-gesamtdosis",
      "description" : "SearchParameter for Procedure.extension:gesamtdosis",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-procedure-ext-strahlentherapie-intention"
      },
      "name" : "mii-sp-onko-procedure-ext-strahlentherapie-intention",
      "description" : "SearchParameter for Procedure.extension[intention]",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-procedure-ext-systemischetherapie-intention"
      },
      "name" : "mii-sp-onko-procedure-ext-systemischetherapie-intention",
      "description" : "SearchParameter for Procedure.extension[intention]",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-procedure-strahlentherapie-applikationsart"
      },
      "name" : "mii-sp-onko-procedure-strahlentherapie-applikationsart",
      "description" : "SearchParameter for Procedure.usedCode:Applikationsart",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-procedure-strahlentherapie-lateralitaet"
      },
      "name" : "mii-sp-onko-procedure-strahlentherapie-lateralitaet",
      "description" : "SearchParameter for Procedure.bodySite.extension:Seitenlokalisation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      }],
      "reference" : {
        "reference" : "SearchParameter/mii-sp-onko-procedure-strahlentherapie-strahlenart"
      },
      "name" : "mii-sp-onko-procedure-strahlentherapie-strahlenart",
      "description" : "SearchParameter for Procedure.usedCode:Strahlenart",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-krk-mrt-mesorektale-faszie-status"
      },
      "name" : "MII_CS_Onko_KRK_MRT_Mesorektale_Faszie_Status",
      "description" : "oBDS-basiertes Codesystem für den Status der MRT/CT Untersuchung zur mesorektalen Faszie beim Kolorektalen Karzinom (KR5)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-krk-stoma-anzeichnung"
      },
      "name" : "MII_CS_Onko_KRK_Stoma_Anzeichnung",
      "description" : "oBDS-basiertes Codesystem für die präoperative Anzeichnung der Stoma-Position beim Rektumkarzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/mii-cs-onko-operation-urgency"
      },
      "name" : "MII_CS_Onko_Operation_Urgency",
      "description" : "oBDS-basiertes Codesystem für die Modalität der Eingriffsdurchführung (Art des Eingriffs KR6)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-genetische-variante-auspraegung"
      },
      "name" : "MII_VS Onkologie Genetische Variante Ausprägung",
      "description" : "Value Set für oBDS-Codes für Ausprägung der Genetischen Variante",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-asa-loinc"
      },
      "name" : "MII_VS_Onko_ASA_LOINC",
      "description" : "Value Set für LOINC ASA Physical Status Classification (generalisiert für alle onkologischen Indikationen)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-asa-obds"
      },
      "name" : "MII_VS_Onko_ASA_oBDS",
      "description" : "Value Set für oBDS ASA-Klassifikation (ursprünglich KR9 aus Kolorektales Karzinom Modul, generalisiert für alle onkologischen Indikationen)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-krk-abstand-circumferelle-resektionsrand"
      },
      "name" : "MII_VS_Onko_KRK_Abstand_Circumferelle_Resektionsrand",
      "description" : "Value Set für semantische Kodierung des oBDS-Abstand des Tumorrandes zur circumferellen Resektionsrand im Kolorektalen Karzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-krk-abstand-resektionslinie-aboral"
      },
      "name" : "MII_VS_Onko_KRK_Abstand_Resektionslinie_Aboral",
      "description" : "Value Set für semantische Kodierung des oBDS-Abstand des Tumorrandes zur aboralen Resektionslinie im Kolorektalen Karzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-krk-anastomoseninsuffizienz"
      },
      "name" : "MII_VS_Onko_KRK_Anastomoseninsuffizienz",
      "description" : "Value Set für die Bewertung der Anastomoseninsuffizienz beim Kolorektalen Karzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-krk-mrt-mesorektale-faszie-status"
      },
      "name" : "MII_VS_Onko_KRK_MRT_Mesorektale_Faszie_Status",
      "description" : "Value Set für semantische Kodierung des oBDS-Status der MRT/CT Untersuchung zur mesorektalen Faszie beim Kolorektalen Karzinom (KR5)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-krk-stoma-anzeichnung"
      },
      "name" : "MII_VS_Onko_KRK_Stoma_Anzeichnung",
      "description" : "Value Set für semantische Kodierung der oBDS-präoperativen Stoma-Anzeichnung beim Rektumkarzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-krk-stoma-status-reason"
      },
      "name" : "MII_VS_Onko_KRK_Stoma_Status_Reason",
      "description" : "Value Set für SNOMED CT Codes zur Begründung des Status der präoperativen Stoma-Anzeichnung",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-krk-tme-qualitaet"
      },
      "name" : "MII_VS_Onko_KRK_TME_Qualitaet",
      "description" : "Value Set für semantische Kodierung des oBDS-Abstand des Tumorrandes zur aboralen Resektionslinie im Kolorektalen Karzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-mamma-intraoperatives-imaging-praeparat"
      },
      "name" : "MII_VS_Onko_Mamma_Intraoperatives_Imaging_Praeparat",
      "description" : "Value Set für intraoperatives Imaging des Präparats nach Exzision bei Mamma-Karzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-mamma-menopause-status"
      },
      "name" : "MII_VS_Onko_Mamma_Menopause_Status",
      "description" : "Value Set für (prätherapeutischen) Status der Menopause Score",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-mamma-operation-ops"
      },
      "name" : "MII_VS_Onko_Mamma_Operation_OPS",
      "description" : "Value Set für Mamma-Operationen basierend auf OPS",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-mamma-operation-sct"
      },
      "name" : "MII_VS_Onko_Mamma_Operation_SCT",
      "description" : "Value Set für Mamma-Operationen basierend auf SNOMED CT",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-mamma-praeoperative-markierung-modalitaet"
      },
      "name" : "MII_VS_Onko_Mamma_Praeoperative_Markierung_Modalitaet",
      "description" : "Value Set für Imagingmodalität der präoperativen Markierung bei Mamma-Karzinom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-mamma-rezeptorstatus-leitlinie"
      },
      "name" : "MII_VS_Onko_Mamma_Rezeptorstatus_Leitlinie",
      "description" : "Value Set für oBDS-Rezeptorstatus Mamma",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-mamma-rezeptorstatus-obds"
      },
      "name" : "MII_VS_Onko_Mamma_Rezeptorstatus_oBDS",
      "description" : "Value Set für oBDS-Rezeptorstatus Mamma",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-melanom-ldh"
      },
      "name" : "MII_VS_Onko_Melanom_LDH",
      "description" : "Value Set für Laktatdehydrogenase (LDH) Laborwerte beim Malignen Melanom",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-operation-urgency"
      },
      "name" : "MII_VS_Onko_Operation_Urgency",
      "description" : "Value Set für semantische Kodierung der oBDS-Modalität der Eingriffsdurchführung (Art des Eingriffs KR6)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-prostata-clavien-dindo"
      },
      "name" : "MII_VS_Onko_Prostata_Clavien_Dindo",
      "description" : "Value Set für Gleason Score",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-prostata-gleason-primary-secondary-tertiary"
      },
      "name" : "MII_VS_Onko_Prostata_Gleason_PrimarySecondaryTertiary",
      "description" : "Value Set für Primär-, Sekundär- und Tertiär-Gleason Patterns in der Onkologie Prostata. Der häufigste Gleason Pattern wird als primär, der zweithäufigste als sekundär und (seltener, meistens bei Gleason Pattern 5) der dritthäufigste als tertiär bezeichnet. Diese Value Set wird verwendet, um die verschiedenen Gleason Patterns zu kodieren, die bei der Beurteilung von Prostatakarzinomen auftreten können.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-prostata-gleason-score"
      },
      "name" : "MII_VS_Onko_Prostata_Gleason_Score",
      "description" : "Value Set für Gleason Score",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/mii-vs-onko-prostata-postsurgical-complications"
      },
      "name" : "MII_VS_Onko_Prostata_Postsurgical_Complications",
      "description" : "Value Set für Clavien-Dindo Klassifikation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/mii-exa-onko-molecular-board-patient"
      },
      "name" : "Molecular Tumor Board Patient",
      "description" : "Patient for molecular tumor board examples",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/mii-exa-onko-modification-oxaliplatin-phase1"
      },
      "name" : "Oxaliplatin Phase 1 (Zyklen 1-6, dann abgebrochen)",
      "description" : "Oxaliplatin administered for 6 cycles, then discontinued due to neuropathy",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/PatientKimMusterperson"
      },
      "name" : "PatientKimMusterperson",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/PatientKimMusterperson-Diagnosis-1"
      },
      "name" : "PatientKimMusterperson-Diagnosis-1",
      "description" : "Diagnose Primärtumor",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/PatientKimMusterperson-PathoReport-1"
      },
      "name" : "PatientKimMusterperson-PathoReport-1",
      "description" : "Pathoreport incl. Immunhistochemie",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Condition"
      }],
      "reference" : {
        "reference" : "Condition/PatientKimMusterperson-PrimaryDiagnosis-2"
      },
      "name" : "PatientKimMusterperson-PrimaryDiagnosis-2",
      "description" : "bestätigte Primärdiagnose",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/PatientKimMusterperson-Procedure-1"
      },
      "name" : "PatientKimMusterperson-Procedure-1",
      "description" : "10.06.2021 CT Abdomen mit KM",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/PatientKimMusterperson-Procedure-2"
      },
      "name" : "PatientKimMusterperson-Procedure-2",
      "description" : "15.06.2021 Aszitespunktion",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/PatientKimMusterperson-Procedure-3"
      },
      "name" : "PatientKimMusterperson-Procedure-3",
      "description" : "22.06.2021 CT Thorax: kein Hinweis auf Metastasen.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/PatientKimMusterperson-Procedure-4a"
      },
      "name" : "PatientKimMusterperson-Procedure-4a",
      "description" : "30.09.2021 OP Intervalldebulking mittels Längsschnittlaparotomie, Tumorresektion mittels Hysterektomie, bilateraler Adnexektomie, und atpyischer Lebersegmentresektion (Seg. II und V). Postoperativ: R0.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/PatientKimMusterperson-Procedure-4b"
      },
      "name" : "PatientKimMusterperson-Procedure-4b",
      "description" : "30.09.2021 OP Intervalldebulking mittels Längsschnittlaparotomie, Tumorresektion mittels Hysterektomie, bilateraler Adnexektomie, und atpyischer Lebersegmentresektion (Seg. II und V). Postoperativ: R0.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/PatientKimMusterperson-Procedure-4c"
      },
      "name" : "PatientKimMusterperson-Procedure-4c",
      "description" : "30.09.2021 OP Intervalldebulking mittels Längsschnittlaparotomie, Tumorresektion mittels Hysterektomie, bilateraler Adnexektomie, und atpyischer Lebersegmentresektion (Seg. II und V). Postoperativ: R0.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/PatientKimMusterperson-Procedure-4d"
      },
      "name" : "PatientKimMusterperson-Procedure-4d",
      "description" : "30.09.2021 OP Intervalldebulking mittels Längsschnittlaparotomie, Tumorresektion mittels Hysterektomie, bilateraler Adnexektomie, und atpyischer Lebersegmentresektion (Seg. II und V). Postoperativ: R0.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      }],
      "reference" : {
        "reference" : "Specimen/PatientKimMusterperson-Specimen-1"
      },
      "name" : "PatientKimMusterperson-Specimen-1",
      "description" : "Tumorresektat Primärtumor",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/PatientKimMusterperson-SystemicTherapy-1"
      },
      "name" : "PatientKimMusterperson-SystemicTherapy-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/PatientKimMusterperson-SystemicTherapy-2"
      },
      "name" : "PatientKimMusterperson-SystemicTherapy-2",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/PatientKimMusterperson-SystemicTherapy-3"
      },
      "name" : "PatientKimMusterperson-SystemicTherapy-3",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/PatientKimMusterperson-SystemicTherapyMedication-1a"
      },
      "name" : "PatientKimMusterperson-SystemicTherapyMedication-1a",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/PatientKimMusterperson-SystemicTherapyMedication-1b"
      },
      "name" : "PatientKimMusterperson-SystemicTherapyMedication-1b",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/PatientKimMusterperson-SystemicTherapyMedication-2a"
      },
      "name" : "PatientKimMusterperson-SystemicTherapyMedication-2a",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/PatientKimMusterperson-SystemicTherapyMedication-2b"
      },
      "name" : "PatientKimMusterperson-SystemicTherapyMedication-2b",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "MedicationStatement"
      }],
      "reference" : {
        "reference" : "MedicationStatement/PatientKimMusterperson-SystemicTherapyMedication-3"
      },
      "name" : "PatientKimMusterperson-SystemicTherapyMedication-3",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-systemische-therapie-medikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      }],
      "reference" : {
        "reference" : "CarePlan/PatientKimMusterperson-Tumorkonferenz-1"
      },
      "name" : "PatientKimMusterperson-Tumorkonferenz-1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      }],
      "reference" : {
        "reference" : "CarePlan/PatientKimMusterperson-Tumorkonferenz-2"
      },
      "name" : "PatientKimMusterperson-Tumorkonferenz-2",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      }],
      "reference" : {
        "reference" : "CarePlan/PatientKimMusterperson-Tumorkonferenz-3"
      },
      "name" : "PatientKimMusterperson-Tumorkonferenz-3",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      }],
      "reference" : {
        "reference" : "CarePlan/PatientKimMusterperson-Tumorkonferenz-4"
      },
      "name" : "PatientKimMusterperson-Tumorkonferenz-4",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/PatientKimMusterperson-Verlauf-2022-01-22"
      },
      "name" : "PatientKimMusterperson-Verlauf-2022-01-22",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-verlauf"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-prostata-operation-prostatektomie"
      },
      "name" : "Prostata Operation Prostatektomie Beispiel",
      "description" : "Beispiel einer radikalen Prostatektomie",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostata-operation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-prostata-operation-turp"
      },
      "name" : "Prostata Operation TURP Beispiel",
      "description" : "Beispiel einer transurethralen Resektion der Prostata",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-prostata-operation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-sigmoid-resection"
      },
      "name" : "Sigmaresektion - Haupteingriff",
      "description" : "Main surgical procedure: Laparoscopic sigmoid resection with lymph node dissection - using SNOMED code",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-operation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-sigmoid-resection-part1"
      },
      "name" : "Sigmaresektion Teil 1 - Resektion und Anastomose",
      "description" : "Component procedure 1: Sigmoid resection with anastomosis",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-operation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-sigmoid-resection-part2"
      },
      "name" : "Sigmaresektion Teil 2 - Lymphknotendissektion",
      "description" : "Component procedure 2: Regional lymph node dissection",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-operation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-sigmoid-resection-part3"
      },
      "name" : "Sigmaresektion Teil 3 - Port-Anlage",
      "description" : "Component procedure 3: Laparoscopic port placement",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-operation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-strahlentherapie-bestrahlung-nuklearmedizin-1"
      },
      "name" : "Strahlentherapie: Beispiel einer Nuklearmedizinischen Bestrahlungstherapie",
      "description" : "Example radiation therapy conformant with MII Prozedur as bracket for radiation and nuclear therapy",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie-bestrahlung-nuklearmedizin"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Procedure"
      }],
      "reference" : {
        "reference" : "Procedure/mii-exa-onko-strahlentherapie-bestrahlung-strahlentherapie-1"
      },
      "name" : "Strahlentherapie: Beispiel einer Strahlentherapie mit allgemeinem OPS-Code 8-52",
      "description" : "Example radiation therapy conformant with MII Prozedur as bracket for radiation and nuclear therapy",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-strahlentherapie-bestrahlung-strahlentherapie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ResearchStudy"
      }],
      "reference" : {
        "reference" : "ResearchStudy/mii-exa-onko-studie-prob"
      },
      "name" : "Studie PRO-B",
      "description" : "PRO-B: Alarm-basiertes Patient-Reported Outcome Monitoring bei Patientinnen mit metastasiertem Mammakarzinom (Innovationsfonds 01NVF19013)",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-studienteilnahme-prob"
      },
      "name" : "Studienteilnahme PRO-B",
      "description" : "Beispiel einer Studienteilnahme an der PRO-B Studie für eine Patientin mit metastasiertem Mammakarzinom",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-studienteilnahme"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-colorectal-tnm"
      },
      "name" : "TNM Klassifikation - pT3 pN1 cM0, UICC Stage IIIB",
      "description" : "Postoperative pathological TNM staging with UICC stage group IIIB",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-klassifikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-ascending-colon-tnm"
      },
      "name" : "TNM Klassifikation - Stadium IIIB",
      "description" : "Postoperative pathological TNM staging for ascending colon cancer (pT3 pN1 cM0 = Stage IIIB)",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-klassifikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-colorectal-tnm-m"
      },
      "name" : "TNM M-Kategorie - cM0",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-m-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-ascending-colon-tnm-m"
      },
      "name" : "TNM M-Kategorie - cM0",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-m-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-colorectal-tnm-n"
      },
      "name" : "TNM N-Kategorie - pN1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-ascending-colon-tnm-n"
      },
      "name" : "TNM N-Kategorie - pN1",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-n-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-colorectal-tnm-t"
      },
      "name" : "TNM T-Kategorie - pT3",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-t-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-ascending-colon-tnm-t"
      },
      "name" : "TNM T-Kategorie - pT3",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-t-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/TNM-Klassifikation-Observation-2"
      },
      "name" : "TNM-Klassifikation-Observation-2",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-klassifikation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/TNM-L-Observation-2"
      },
      "name" : "TNM-L-Observation-2",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-l-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/TNM-M-Observation-2"
      },
      "name" : "TNM-M-Observation-2",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-m-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/TNM-Pn-Observation-2"
      },
      "name" : "TNM-Pn-Observation-2",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-pn-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/TNM-T-Observation-2"
      },
      "name" : "TNM-T-Observation-2",
      "description" : "Lokale Tumorausbreitung: Ovartumor links mit einer max. Größe von 2,2 cm und tumorinfiltrierter Kapsel mit Nachweis von Tumorzellen auf der Ovaroberfläche, Anteil vitaler Tumorzellen von ca. 80 %.",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-t-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/TNM-V-Observation-2"
      },
      "name" : "TNM-V-Observation-2",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-v-kategorie"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/TNM-y-Symbol-Observation-2"
      },
      "name" : "TNM-y-Symbol-Observation-2",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tnm-y-symbol"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-onko-tumorkonferenz-folfox-modification"
      },
      "name" : "Tumorkonferenz - FOLFOX Empfehlung",
      "description" : "Tumor board recommends FOLFOX4 protocol for adjuvant treatment",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CarePlan"
      }],
      "reference" : {
        "reference" : "CarePlan/mii-exa-onko-tumorkonferenz-folfox"
      },
      "name" : "Tumorkonferenz - FOLFOX Empfehlung bei Kolorektalkarzinom",
      "description" : "Tumor board recommends FOLFOX protocol for colorectal cancer patient",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-tumorkonferenz"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "AdverseEvent"
      }],
      "reference" : {
        "reference" : "AdverseEvent/mii-exa-onko-oxaliplatin-neuropathy"
      },
      "name" : "Unerwünschtes Ereignis - Oxaliplatin-induzierte Neuropathie",
      "description" : "Grade 3 peripheral neuropathy caused by oxaliplatin, leading to treatment modification",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-folfox-verlauf-6months"
      },
      "name" : "Verlauf - 6 Monate nach FOLFOX",
      "description" : "6-month follow-up examination showing no evidence of disease",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-verlauf"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/mii-exa-onko-modification-verlauf-6months"
      },
      "name" : "Verlauf - 6 Monate nach modifizierter Therapie",
      "description" : "6-month follow-up showing complete response despite protocol modification",
      "exampleCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-verlauf"
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Start",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "use-cases.html"
        }],
        "nameUrl" : "use-cases.html",
        "title" : "Anwendungsfälle / Szenarien",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "data-sets.html"
        }],
        "nameUrl" : "data-sets.html",
        "title" : "Datensätze und Beschreibungen",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "uml.html"
        }],
        "nameUrl" : "uml.html",
        "title" : "Informationsmodell (UML)",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "conformance.html"
        }],
        "nameUrl" : "conformance.html",
        "title" : "Konformität (Technische Implementierung)",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "abweichungen-obds.html"
        }],
        "nameUrl" : "abweichungen-obds.html",
        "title" : "Abweichungen zum oBDS",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "context.html"
        }],
        "nameUrl" : "context.html",
        "title" : "Kontext / Bezüge zu anderen Modulen",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "bezug-nationale-standards.html"
        }],
        "nameUrl" : "bezug-nationale-standards.html",
        "title" : "Bezug zu nationalen Standards",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "bezug-internationale-standards.html"
        }],
        "nameUrl" : "bezug-internationale-standards.html",
        "title" : "Bezug zu internationalen Standards",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "security-privacy.html"
        }],
        "nameUrl" : "security-privacy.html",
        "title" : "Sicherheit und Datenschutz",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "references.html"
        }],
        "nameUrl" : "references.html",
        "title" : "Referenzen",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "downloads.html"
        }],
        "nameUrl" : "downloads.html",
        "title" : "Downloads",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "changes.html"
        }],
        "nameUrl" : "changes.html",
        "title" : "Release Notes / Änderungen",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "translationinfo.html"
        }],
        "nameUrl" : "translationinfo.html",
        "title" : "Hinweise zur Mehrsprachigkeit",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/assets"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
