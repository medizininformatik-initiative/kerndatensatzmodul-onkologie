# MII_VS Onkologie Genetische Variante Ausprägung - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

## ValueSet: MII_VS Onkologie Genetische Variante Ausprägung 

 
Value Set für oBDS-Codes für Ausprägung der Genetischen Variante 

 **References** 

* [MII PR Onkologie Genetische Variante](StructureDefinition-mii-pr-onko-genetische-variante.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-onko-genetische-variante-auspraegung",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-genetische-variante-auspraegung",
  "version" : "2026.0.3",
  "name" : "MII_VS_Onko_Genetische_Variante_Auspraegung",
  "title" : "MII_VS Onkologie Genetische Variante Ausprägung",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-02T12:18:38+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Value Set für oBDS-Codes für Ausprägung der Genetischen Variante",
  "compose" : {
    "include" : [{
      "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-genetische-variante-auspraegung"
    }]
  }
}

```
