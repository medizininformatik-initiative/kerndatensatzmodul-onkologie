# MII PR Onkologie Therapieempfehlung Kombinationstherapie - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

## Resource Profile: MII PR Onkologie Therapieempfehlung Kombinationstherapie 

 
Dieses Profil beschreibt eine Empfehlung für eine Kombinationstherapie im Rahmen der Tumorkonferenz 

Dieses Profil beschreibt strukturierte **Therapieempfehlungen für Kombinationstherapien** mittels RequestGroup. Es ermöglicht die detaillierte Abbildung von Multi-Agent-Protokollen und alternativen Therapieoptionen für molekulare Tumorboards.

### Inhalt

Das RequestGroup-Profil dient als "Protokoll-Koordinator" zwischen **CarePlan-Empfehlungen** und **spezifischen Therapieressourcen** (SystemischeTherapie, MedicationRequest, etc.).

### Anwendungsfälle

#### Multi-Agent-Therapieprotokolle

* **Anti-HER2-Kombination**: Trastuzumab + Pertuzumab
* **CDK4/6 + Hormontherapie**: Palbociclib + Letrozol
* **Triplet-Therapien**: Tucatinib + Trastuzumab + Capecitabine

#### Alternative Therapieoptionen

* **Linientherapie**: Erste-, zweite-, drittlinienoptionen basierend auf Resistenz
* **Biomarker-basiert**: Verschiedene Optionen je nach Mutationsstatus
* **Klassen-basiert**: "Beliebiger CDK4/6 Inhibitor" vs. spezifische Auswahl

### Technische Architektur

#### RequestGroup als Protokoll-Koordinator

```
CarePlan.activity.reference → RequestGroup
├── code: oBDS-Therapietyp (ZS, CZ, IM, etc.)
├── basedOn: Reference(CarePlan) [Rückverfolgbarkeit]
└── action[].resource: Reference(SystemischeTherapie)

```

#### Therapietyp-Klassifikation

Das **RequestGroup.code** Element enthält die **oBDS-Therapietyp-Klassifikation**:

* **ZS**: Zielgerichtete Substanzen
* **CZ**: Chemotherapie + zielgerichtete Substanzen
* **IM**: Immun-/Antikörpertherapie
* **CI**: Chemo- + Immun-/Antikörpertherapie
* **CIZ**: Chemo- + Immun-/Antikörpertherapie + zielgerichtete Substanzen

**Wichtig**: Diese Klassifikation war ursprünglich in `CarePlan.activity.detail.code` (oBDS 19.1), wird aber aufgrund von FHIR-Invarianten in das RequestGroup verlagert.

### Implementierungsoptionen

#### Option 1: Pharmazeutische Klassen

Für **Klassen-basierte Empfehlungen** (z.B. "beliebiger CDK4/6 Inhibitor"):

```
RequestGroup
├── code: "CZ" (Chemotherapie + zielgerichtete Substanzen)
└── action[0].resource: Reference(SystemischeTherapie)
    └── code.text: "CDK4/6 Inhibitor (Klasse L01XE) - Palbociclib, Ribociclib oder Abemaciclib"

```

**Anwendung**: Wenn molekulares Tumorboard eine **Medikamentenklasse** empfiehlt und die finale Auswahl dem behandelnden Arzt überlässt.

#### Option 2: Spezifische Medikamentenauswahl

Für **spezifische Optionen** mit Auswahllogik:

```
RequestGroup
├── code: "ZS" (Zielgerichtete Substanzen)
├── action[0].selectionBehavior: #any
├── action[0].requiredBehavior: #must
├── action[0].action[0]: Reference(Trastuzumab) [priority: routine]
├── action[0].action[1]: Reference(T-DM1) [priority: asap]  
└── action[0].action[2]: Reference(Tucatinib) [priority: stat]

```

**Anwendung**: Wenn molekulares Tumorboard **spezifische Alternativen** mit klaren Präferenzen basierend auf Resistenzmustern oder klinischer Situation empfiehlt.

### FHIR-Invarianten-Konformität

**Problem**: FHIR R4 Invariant verhindert gleichzeitige Nutzung von `code` und `action.resource`
 **Lösung**: Dieses Profil **akzeptiert beide Ansätze** je nach Anwendungsfall:

* **Option 1**: Verwendet `code` für Therapietyp, `action.resource` für Klassen-Level-Therapie
* **Option 2**: Verwendet `code` für Therapietyp, verschachtelte `action.action.resource` für spezifische Optionen mit `selectionBehavior`

### oBDS-Kontext

#### Mapping zu oBDS 19.1

```
RequestGroup.code → "19.1" "Tumorkonferenz Therapieempfehlung Typ"

```

**Datenfelder**:

* **CH**: Chemotherapie
* **HO**: Hormontherapie
* **IM**: Immun-/Antikörpertherapie
* **ZS**: Zielgerichtete Substanzen
* **SZ**: Stammzelltransplantation
* **Kombinationen**: CI, CZ, CIZ, IZ
* **Andere**: OP, ST, WW, AS, SO

#### Erweiterte Strukturierung

Während oBDS nur den **Therapietyp** erfasst, ermöglicht RequestGroup zusätzlich:

* **Spezifische Medikamente** pro Empfehlung
* **Alternative Optionen** mit Prioritäten
* **Kombinationslogik** für Multi-Agent-Protokolle

### Terminologie-Binding

**RequestGroup.code**:

* **ValueSet**: `mii-vs-onko-therapieempfehlung-typ`
* **Binding**: Preferred
* **Quelle**: oBDS-Therapietypen aus `mii-cs-onko-therapie-typ`

-------

Mapping [Einheitlicher onkologischer Basisdatensatz (oBDS)](https://basisdatensatz.de/basisdatensatz) zu FHIR

-------

**Suchparameter**

1. Der Suchparameter `_id` MUSS unterstützt werden: `GET [base]/RequestGroup?_id=1234`
1. Der Suchparameter "_profile" MUSS unterstützt werden: `GET [base]/RequestGroup?_profile=https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-kombinationstherapie`
1. Der Suchparameter "subject" MUSS unterstützt werden: `GET [base]/RequestGroup?subject=Patient/example`
1. Der Suchparameter "code" SOLLTE unterstützt werden: `GET [base]/RequestGroup?code=ZS`
1. Der Suchparameter "based-on" SOLLTE unterstützt werden: `GET [base]/RequestGroup?based-on=CarePlan/tumorkonferenz-example`

**Beispiele**

`mii-exa-onko-cdk46-class-recommendation` 

`mii-exa-onko-her2-specific-choices` 

**Usages:**

* Refer to this Profile: [MII PR Onkologie Tumorkonferenz](StructureDefinition-mii-pr-onko-tumorkonferenz.md)
* Examples for this Profile: [RequestGroup/mii-exa-onko-folfox-requestgroup-modification](RequestGroup-mii-exa-onko-folfox-requestgroup-modification.md), [RequestGroup/mii-exa-onko-folfox-requestgroup](RequestGroup-mii-exa-onko-folfox-requestgroup.md), [RequestGroup/mii-exa-onko-molecular-cdk46-protocol](RequestGroup-mii-exa-onko-molecular-cdk46-protocol.md) and [RequestGroup/mii-exa-onko-molecular-her2-alternatives](RequestGroup-mii-exa-onko-molecular-her2-alternatives.md)
* CapabilityStatements using this Profile: [MII CPS Onkology CapabilityStatement](CapabilityStatement-mii-cps-onko-capabilitystatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/mii-ig-onko-de-v2026|current/StructureDefinition/StructureDefinition-mii-pr-onko-therapieempfehlung-kombinationstherapie.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-mii-pr-onko-therapieempfehlung-kombinationstherapie.csv), [Excel](../StructureDefinition-mii-pr-onko-therapieempfehlung-kombinationstherapie.xlsx), [Schematron](../StructureDefinition-mii-pr-onko-therapieempfehlung-kombinationstherapie.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "mii-pr-onko-therapieempfehlung-kombinationstherapie",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-kombinationstherapie",
  "version" : "2026.0.3",
  "name" : "MII_PR_Onko_Therapieempfehlung_Kombinationstherapie",
  "title" : "MII PR Onkologie Therapieempfehlung Kombinationstherapie",
  "status" : "active",
  "date" : "2026-07-02T11:24:18+00:00",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Dieses Profil beschreibt eine Empfehlung für eine Kombinationstherapie im Rahmen der Tumorkonferenz",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "oBDS",
    "name" : "Mapping FHIR zu oBDS"
  },
  {
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "RequestGroup",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/RequestGroup",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "RequestGroup",
      "path" : "RequestGroup"
    },
    {
      "id" : "RequestGroup.meta.profile",
      "path" : "RequestGroup.meta.profile",
      "mustSupport" : true
    },
    {
      "id" : "RequestGroup.identifier",
      "path" : "RequestGroup.identifier",
      "mustSupport" : true
    },
    {
      "id" : "RequestGroup.status",
      "path" : "RequestGroup.status",
      "mustSupport" : true
    },
    {
      "id" : "RequestGroup.intent",
      "path" : "RequestGroup.intent",
      "patternCode" : "proposal",
      "mustSupport" : true
    },
    {
      "id" : "RequestGroup.code",
      "path" : "RequestGroup.code",
      "short" : "Type of therapy recommendation",
      "definition" : "Classification of the therapy recommendation using oBDS therapy types (CH, HO, IM, ZS, etc.) to specify the kind of therapy being recommended.",
      "mustSupport" : true,
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-therapieempfehlung-typ"
      }
    },
    {
      "id" : "RequestGroup.subject",
      "path" : "RequestGroup.subject",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "RequestGroup.encounter",
      "path" : "RequestGroup.encounter",
      "mustSupport" : true
    },
    {
      "id" : "RequestGroup.authoredOn",
      "path" : "RequestGroup.authoredOn",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "RequestGroup.reasonReference",
      "path" : "RequestGroup.reasonReference",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-diagnose-primaertumor"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "RequestGroup.action",
      "path" : "RequestGroup.action",
      "mustSupport" : true
    },
    {
      "id" : "RequestGroup.action.code",
      "path" : "RequestGroup.action.code",
      "short" : "Empfohlenes Therapieprotokoll",
      "_short" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de-DE"
          },
          {
            "url" : "content",
            "valueString" : "Empfohlenes Therapieprotokoll"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "definition" : "Empfohlenes Therapieprotokoll gemäß Tumorkonferenz",
      "_definition" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de-DE"
          },
          {
            "url" : "content",
            "valueString" : "Spezifisches Therapieprotokoll empfohlen durch Tumorkonferenz. Bei Kombinationstherapien repräsentiert dies das Gesamtprotokoll mit einzelnen Medikamenten als Sub-Actions."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "mustSupport" : true,
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ValueSet/mii-vs-onko-systemische-therapie-protokolle"
      }
    },
    {
      "id" : "RequestGroup.action.action",
      "path" : "RequestGroup.action.action",
      "short" : "Individual medications in protocol",
      "definition" : "For combination therapy protocols, each sub-action references an individual MedicationRequest with ATC/UNII coding",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mustSupport" : true
    },
    {
      "id" : "RequestGroup.action.action.resource",
      "path" : "RequestGroup.action.action.resource",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/StructureDefinition/mii-pr-onko-therapieempfehlung-medikation"]
      }],
      "mustSupport" : true
    }]
  }
}

```
