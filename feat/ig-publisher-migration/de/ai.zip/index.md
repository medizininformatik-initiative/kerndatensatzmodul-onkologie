# Start - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

## Start

Die vorliegende Spezifikation beschreibt die FHIR-Repräsentation des Kerndatensatz-Moduls Onkologie der Medizininformatik-Initiative. Im Folgenden werden die Use Cases des Moduls, sowie die dazugehörigen FHIR-Profile und Terminologie-Ressourcen in ihrer verbindlichen Form beschrieben.

| | |
| :--- | :--- |
| Datum | 19.12.2025 |
| Version | 2026.0.0 |
| Status | active |
| Realm | DE |

## Impressum

Dieser Leitfaden ist im Rahmen der Medizininformatik Initative erstellt wurden und unterliegt per Governance Prozess dem Abstimmungsverfahren des Interoperabilitätsforums und der Technischen Komitees von HL7 Deutschland e. V..

## Ansprechpartner

* Thomas Debertshäuser, Berlin Institute of Health (Charité)
* Martin Boeker (DIFUTURE)
* Sylvia Thun, Berlin Institute of Health (Charité)
* Karoline Buckow, TMF – Technologie- und Methodenplattform für die vernetzte medizinische Forschung e.V.
* Franziska Klepka, TMF – Technologie- und Methodenplattform für die vernetzte medizinische Forschung e.V.

Fragen zu der vorliegenden Publikation können jederzeit unter [chat.fhir.org](https://chat.fhir.org) im Stream 'german/mi-initiative' gestellt werden.

Anmerkungen und Kritik wird in Form von 'Issues' im [GitHub-Projekt](https://github.com/medizininformatik-initiative/kerndatensatzmodul-onkologie/issues) stets gern entgegengenommen: .

## Autoren (in alphabetischer Reihenfolge)

* Christian Gulden (BZKF / Erlangen)
* Jori Kern (DKFZ Heidelberg)
* Julian Saß, Berlin Institute of Health (Charité)
* Margaux Gatrio, Berlin Institute of Health (Charité)
* Lotte Schwiening, Berlin Institute of Health (Charité)
* Paul Müller, Berlin Institute of Health (Charité)
* Nina Haffer, Berlin Institute of Health (Charité)
* Sophie Klopfenstein, Berlin Institute of Health (Charité)
* Thomas Debertshäuser, Berlin Institute of Health (Charité)
* Yuan Peng, Institut für Medizinische Informatik und Biometrie (TU Dresden)

## Copyright-Hinweis, Nutzungshinweise

Copyright © 2019+: TMF e. V., Charlottenstraße 42, 10117 Berlin

Der Inhalt dieser Spezifikation ist öffentlich. Die Nachnutzungs- bzw. Veröffentlichungsansprüche sind nicht beschränkt.

Zu den Nutzungsrechten der zugrunde liegenden FHIR-Technologie siehe die FHIR-Basis-Spezifikation.

Einige verwendete Codesysteme werden von anderen Organisationen herausgegeben und gepflegt. Es gilt das Copyright der dort jeweils aufgeführten Herausgeber (Publisher).

## Disclaimer

Der Inhalt dieses Dokuments ist öffentlich. Zu beachten ist, dass Teile dieses Dokuments auf FHIR Version R4 beruhen, für die Copyright HL7 International gilt.

